SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspUpdateLobDetails]

@UPDATE_TYPE char(1),
--@STATUS_ID_PREV varchar(4),
--@STATUS_ID_NEXT varchar(4),
@LOB_CODE As varchar(3),
@LOB_CODE_NM As varchar(30),
@PREPARER_ID Varchar(30),
@REJECT_RES Varchar(MAX)

AS
BEGIN Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	DECLARE @Uniq_LOB varchar(3)
	
	--SET @Rpt_Id = (SELECT LTRIM(RTRIM([RPT_ID])) FROM @DATA_DETAILS)
	--SET @Row_Num = (SELECT LTRIM(RTRIM([ROW_NUM])) FROM @DATA_DETAILS)
	
	--create new rec if update on fresh or final status, else update on same record:	
	

	
		--SET @Uniq_LOB = (SELECT TOP 1 LOB_CODE FROM [dbo].[RRF_GUI_LOB_CODE] ORDER BY CAST(LOB_CODE AS NUMERIC) DESC)
		--SET @Uniq_LOB = @Uniq_LOB + 1
		--SET @Uniq_LOB = REPLICATE('0',3-LEN(@Uniq_LOB)) + CAST(@Uniq_LOB AS VARCHAR)
	
	IF @UPDATE_TYPE = 'I'

	BEGIN
		
	    SET @Uniq_LOB = (SELECT TOP 1 LOB_CODE FROM [dbo].[RRF_GUI_LOB_CODE] ORDER BY CAST(LOB_CODE AS NUMERIC) DESC)
		SET @Uniq_LOB = @Uniq_LOB + 1
		SET @Uniq_LOB = REPLICATE('0',3-LEN(@Uniq_LOB)) + CAST(@Uniq_LOB AS VARCHAR)

			INSERT INTO [dbo].[RRF_GUI_LOB_CODE]
				(LOB_CODE,LOB_CODE_NM,LOG_UPDT_USER_ID,LOG_UPDT_DT,[STATUS],CHECKER_ID,CHECKER_UPDT_DT,REJECT_REASON)
				VALUES
				(@Uniq_LOB,@LOB_CODE_NM,@PREPARER_ID,GETDATE(),'N','INITIAL',GETDATE(),NUll)
					
			SET @AfterImage = (SELECT TOP 1 LOB_CODE + ' | ' + LOB_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [LOB_CODE]=@LOB_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_LOB_CODE','',@AfterImage,'I';			
		
	END
	
	IF @UPDATE_TYPE = 'U' or @UPDATE_TYPE = 'R'or @UPDATE_TYPE = 'A'

		SET @BeforeImage = (SELECT TOP 1 LOB_CODE + ' | ' + LOB_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [LOB_CODE]=@LOB_CODE);
			
		EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_LOB_CODE','',@BeforeImage,@UPDATE_TYPE;	

		
		BEGIN	

		--INSERT INTO dbo.RRF_GUI_LOB_CODE 
		--(LOB_CODE,LOB_CODE_NM,LOG_UPDT_USER_ID,LOG_UPDT_DT,[STATUS],CHECKER_ID,CHECKER_UPDT_DT)
  --      SELECT LOB_CODE,LOB_CODE_NM,LOG_UPDT_USER_ID,GETDATE(),'U',CHECKER_ID,CHECKER_UPDT_DT from RRF_GUI_LOB_CODE WHERE [LOB_CODE]=@LOB_CODE

			UPDATE [dbo].[RRF_GUI_LOB_CODE] SET
				[LOB_CODE_NM]=@LOB_CODE_NM,[CHECKER_ID]=@PREPARER_ID,[STATUS]=@UPDATE_TYPE,[CHECKER_UPDT_DT]=GETDATE(),REJECT_REASON=@REJECT_RES
				WHERE [LOB_CODE]=@LOB_CODE
					
			SET @AfterImage = (SELECT TOP 1 LOB_CODE + ' | ' + LOB_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [LOB_CODE]=@LOB_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_LOB_CODE','',@AfterImage,@UPDATE_TYPE;			
		END
				
COMMIT

GO
