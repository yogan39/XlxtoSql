SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGenESubmissionsHalfYearly]

@ROW_NUM varchar(50),
@RPT_ID varchar(9),
@NO_OF_SET NUMERIC,
@EFF_POSITION_DATE varchar(10),
@EXP_POSITION_DATE varchar(10),
@HALFYEARLY_TYPE CHAR(1)

AS
Begin Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	DECLARE @dEFF_POSITION_DATE DATE
	DECLARE @dEXP_POSITION_DATE DATE
	DECLARE @X NUMERIC
	DECLARE @SUBMISSION_ID NUMERIC
	DECLARE @BIZ_DAY_ONLY CHAR(1)
	DECLARE @dSUBMISSION_DATE DATE
	DECLARE @iT_PLUS_SUBMISSION_DATE NUMERIC
	DECLARE @Row_Num_Ind NUMERIC
	DECLARE @idaysAdded numeric
	DECLARE @idaysToAdd numeric
	DECLARE @HalfYearlyType NUMERIC

	SET @dEFF_POSITION_DATE = @EFF_POSITION_DATE
	SET @dEXP_POSITION_DATE = @EXP_POSITION_DATE
	
	--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
	--SET @BIZ_DAY_ONLY = (SELECT TOP 1 [BIZ_DAY_ONLY] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='6')
	--SET @iT_PLUS_SUBMISSION_DATE = (SELECT TOP 1 [T_PLUS_SUBMISSION_DATE] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='6')
	
	--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
	IF @HALFYEARLY_TYPE = '1'	--Half Yearly_Calendar Year End
	begin
		SET @BIZ_DAY_ONLY = (SELECT TOP 1 [BIZ_DAY_ONLY] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='6')
		SET @iT_PLUS_SUBMISSION_DATE = (SELECT TOP 1 [T_PLUS_SUBMISSION_DATE] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='6')
	end
	
	--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
	IF @HALFYEARLY_TYPE = '2'	--Half Yearly_Financial Year End
	begin
		SET @BIZ_DAY_ONLY = (SELECT TOP 1 [BIZ_DAY_ONLY] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='11')
		SET @iT_PLUS_SUBMISSION_DATE = (SELECT TOP 1 [T_PLUS_SUBMISSION_DATE] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='11')
	end
	
	IF @BIZ_DAY_ONLY IS NOT NULL AND @iT_PLUS_SUBMISSION_DATE IS NOT NULL
	begin

		--Half Yearly_Calendar Year End � 30th June and 31st Dec
		--Half Yearly_Financial Year End � 31st Mac and 30th Sept
		
		IF @HALFYEARLY_TYPE = '1'	--Half Yearly_Calendar Year End
		begin
			IF @dEFF_POSITION_DATE > CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/06/30'
			begin
				SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/12/31'
				SET @HalfYearlyType = 2
			end
			ELSE
			begin
				SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/06/30'
				SET @HalfYearlyType = 1
			end
		end
		
		IF @HALFYEARLY_TYPE = '2'	--Half Yearly_Financial Year End
		begin
			IF @dEFF_POSITION_DATE > CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/03/31'
			begin
				SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/09/30'
				SET @HalfYearlyType = 2
			end
			ELSE
			begin
				SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/03/31'
				SET @HalfYearlyType = 1
			end
		end
		
		SET @X = 1

		WHILE @X <= @NO_OF_SET	--loop within no of set
		begin
			
			IF @dEFF_POSITION_DATE < @dEXP_POSITION_DATE
			begin
			
				IF @BIZ_DAY_ONLY = 'N'	--regardless of day types
					SET @dSUBMISSION_DATE = DATEADD(day,@iT_PLUS_SUBMISSION_DATE,@dEFF_POSITION_DATE)
				ELSE
				begin
				
					--KL's weekend + KL's public holiday
					
					SET @dSUBMISSION_DATE = @dEFF_POSITION_DATE
					SET @idaysToAdd = @iT_PLUS_SUBMISSION_DATE
					SET @idaysAdded = 1
					
					WHILE @idaysAdded <= @idaysToAdd
					begin
					
						SET @dSUBMISSION_DATE = DATEADD(day,1,@dSUBMISSION_DATE)
					
						IF UPPER(DATENAME(dw,@dSUBMISSION_DATE))='SATURDAY' OR  UPPER(DATENAME(dw,@dSUBMISSION_DATE))='SUNDAY'
							SET @idaysAdded = @idaysAdded
						ELSE
						begin
						
							IF EXISTS (SELECT [HOLIDAY_DATE] FROM [dbo].[RRF_GUI_PUBLIC_HOLIDAYS] WHERE [STATE_ID]='03' AND [HOLIDAY_DATE]=@dSUBMISSION_DATE)
								SET @idaysAdded = @idaysAdded
							ELSE
								SET @idaysAdded = @idaysAdded + 1
								
						end
						
					end
					
				end
				
				--check if rec already exists
				IF NOT EXISTS (SELECT [ROW_NUM] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE [RPT_ID]=@RPT_ID AND POSITION_DATE=@dEFF_POSITION_DATE AND TARGET_SUBMISSION_DATE=@dSUBMISSION_DATE AND STATUS_ID NOT IN ('Z'))
				begin
				
					SET @SUBMISSION_ID = (SELECT TOP 1 [SUBMISSION_ID] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] ORDER BY [SUBMISSION_ID] DESC)
					
					IF LEN(@SUBMISSION_ID) = 0 OR @SUBMISSION_ID IS NULL
						SET @SUBMISSION_ID = 1
					ELSE
						SET @SUBMISSION_ID = @SUBMISSION_ID + 1
				
					INSERT INTO [dbo].[RRF_GUI_ESUBMISSION_DATA] ([SUBMISSION_ID],[RPT_ID],[POSITION_DATE],[TARGET_SUBMISSION_DATE],[STATUS_ID],[CREATE_DATE],
						[PREPARER_ID],[PREPARER_DATE])
						SELECT @SUBMISSION_ID,@RPT_ID,@dEFF_POSITION_DATE,@dSUBMISSION_DATE,'D1',GETDATE(),'SYSTEM',GETDATE();
				
					SET @Row_Num_Ind = @@IDENTITY
					
					SET @AfterImage = (SELECT TOP 1 CAST(SUBMISSION_ID AS VARCHAR) + ' | ' + RPT_ID + ' | ' + CAST(POSITION_DATE AS VARCHAR) + ' | ' 
						+ CAST(TARGET_SUBMISSION_DATE AS VARCHAR) + ' | ' + isnull(CAST(APPROVED_EXTENDED_DATE AS VARCHAR),'') + ' | ' + isnull(CAST(RESUBMISSION_NO AS VARCHAR),'') + ' | '
						+ ISNULL(EXTENDED_ATTACHMENT_NAME,'') + ' | ' +
						+ isnull(EXTENDED_REASON,'') + ' | ' + isnull(COMPLIANCE,'') + ' | ' + isnull(COMPLIANCE_REMARK,'') + ' | ' + isnull(RRF_JUSTIFICATION,'') + ' | ' 
						+ isnull(CATEGORY_ISSUE_ID,'') + ' | ' + isnull(DESCRIPTION_ISSUE,'') + ' | ' + isnull(IMPACT_ISSUE,'') + ' | ' + isnull(CAUSAL,'') + ' | ' 
						+ isnull(ACTION_PLAN,'') + ' | ' + isnull(STATUS_UPDATE,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
						+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
						+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'')
						FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE ROW_NUM=@Row_Num_Ind);
					
					EXEC [dbo].[uspAuditTrail] 'SYSTEM','RRF_GUI_ESUBMISSION_DATA','',@AfterImage,'I';
			
				end
				
				IF @HalfYearlyType = 2
				begin
				
					SET @dEFF_POSITION_DATE = DATEADD(month, 6, @dEFF_POSITION_DATE)	--next 6 months
					
					--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
					IF @HALFYEARLY_TYPE = '1'	--Half Yearly_Calendar Year End
						SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/06/30'
					
					--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
					IF @HALFYEARLY_TYPE = '2'	--Half Yearly_Financial Year End
						SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/03/31'
						
					SET @HalfYearlyType = 1
					
				end 
				ELSE
				begin
				
					IF @HalfYearlyType = 1
					begin

						--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
						IF @HALFYEARLY_TYPE = '1'	--Half Yearly_Calendar Year End
							SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/12/31'
							
						--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
						IF @HALFYEARLY_TYPE = '2'	--Half Yearly_Financial Year End
							SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/09/30'

						SET @HalfYearlyType = 2

					end
					
				end
				
			end
			
			SET @X = @X + 1

		end
	
	end

Commit

RETURN 1

GO
