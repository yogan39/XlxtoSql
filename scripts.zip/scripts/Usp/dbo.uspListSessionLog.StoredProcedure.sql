SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListSessionLog]

@LOG_DATE varchar(50),
@USER_ID varchar(30),
@ACTION_CODE varchar(5)

AS

	declare @strSQL varchar(1000)
	declare @strSQLCondition varchar(1000)
	declare @strSQLOrderBy varchar(1000)
	declare @strDate varchar(10)
	
	set @strSQLOrderBy = ' ORDER BY a.[TS_LOG]'
	
	set @strSQL = 'SELECT a.[SESN_SEQ_NO] AS [SESSION_SEQ_NO],CONVERT(VARCHAR,a.[TS_LOG],103) + '' '' + CONVERT(VARCHAR,a.[TS_LOG],114) AS [LOG_DATE],'
	set @strSQL = @strSQL + 'CASE a.[ACTN_CODE] WHEN ''LI'' THEN ''Log In'' WHEN ''LO'' THEN ''Log Out'' END AS [ACTION_CODE],'
	set @strSQL = @strSQL + 'a.[WNDWS_USER_ID] AS [USER_ID],a.[WNDWS_IP_ADR] AS [IP_ADDRESS],'
	set @strSQL = @strSQL + 'a.[SESN_STAT_CODE] AS [STATUS_CODE],a.[SESN_NOTE] AS [STATUS_DESC] '
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_SESN_LOG] a'
	set @strSQLCondition = ''
	
	IF @LOG_DATE <> ''
	begin
		set @strDate = substring(@LOG_DATE,7,4) + '/' + substring(@LOG_DATE,4,2) + '/' + substring(@LOG_DATE,1,2)
		set @strSQLCondition = ' WHERE a.[TS_LOG] BETWEEN ''' + @strDate + ' 00:00:00'' AND ''' + @strDate + ' 23:59:59'''
	end

	IF @USER_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[WNDWS_USER_ID]=''' + @USER_ID + ''''
		else
			set @strSQLCondition = ' WHERE a.[WNDWS_USER_ID]=''' + @USER_ID + ''''		
	end
	
	IF @ACTION_CODE <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[ACTN_CODE]=''' + @ACTION_CODE + ''''
		else
			set @strSQLCondition = ' WHERE a.[ACTN_CODE]=''' + @ACTION_CODE + ''''		
	end
	
	set @strSQL = @strSQL + @strSQLCondition + @strSQLOrderBy
	
	EXECUTE(@strSQL)

GO
