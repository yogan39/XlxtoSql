SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGetETemplateStatus]

@ROW_NUM varchar(50),
@RPT_ID varchar(9)

AS

	DECLARE @strSQL varchar(3000)

	SET @strSQL = 'SELECT STATUS_ID FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE [ROW_NUM]=''' + @ROW_NUM + ''' AND RPT_ID=''' + @RPT_ID + ''''
		
	EXECUTE(@strSQL)
	


GO
