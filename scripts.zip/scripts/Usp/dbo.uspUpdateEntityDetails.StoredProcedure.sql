SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspUpdateEntityDetails]

@UPDATE_TYPE char(1),
@STATUS_ID_PREV varchar(4),
@STATUS_ID_NEXT varchar(4),
@ENTITY_CODE As varchar(3),
@ENTITY_CODE_NM As varchar(30),
@PREPARER_ID Varchar(30)

AS
BEGIN Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	
	--SET @Rpt_Id = (SELECT LTRIM(RTRIM([RPT_ID])) FROM @DATA_DETAILS)
	--SET @Row_Num = (SELECT LTRIM(RTRIM([ROW_NUM])) FROM @DATA_DETAILS)
	
	--create new rec if update on fresh or final status, else update on same record:	
	
	IF @UPDATE_TYPE = 'I'
	BEGIN
		BEGIN
			INSERT INTO [dbo].[RRF_GUI_ENTITY_CODE]
				(ENTITY_CODE,ENTITY_CODE_NM,LOG_UPDT_USER_ID,LOG_UPDT_DT,[STATUS],CHECKER_ID,CHECKER_UPDT_DT)
				VALUES
				(@ENTITY_CODE,@ENTITY_CODE_NM,@PREPARER_ID,GETDATE(),@STATUS_ID_NEXT,'100257371A',GETDATE())
					
			SET @AfterImage = (SELECT TOP 1 ENTITY_CODE + ' | ' + ENTITY_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_ENTITY_CODE] WHERE [ENTITY_CODE]=@ENTITY_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_ENTITY_CODE','',@AfterImage,'I';			
		END
	END
	
	IF @UPDATE_TYPE = 'U'
	BEGIN
		SET @BeforeImage = (SELECT TOP 1 ENTITY_CODE + ' | ' + ENTITY_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_ENTITY_CODE] WHERE [ENTITY_CODE]=@ENTITY_CODE);
			
		EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_ENTITY_CODE','',@BeforeImage,'U';	
		
		BEGIN	
			UPDATE [dbo].[RRF_GUI_ENTITY_CODE] SET
				[ENTITY_CODE_NM]=@ENTITY_CODE_NM,[LOG_UPDT_USER_ID]=@PREPARER_ID,[STATUS]='N',LOG_UPDT_DT=GETDATE()
				WHERE [ENTITY_CODE]=@ENTITY_CODE
					
			SET @AfterImage = (SELECT TOP 1 ENTITY_CODE + ' | ' + ENTITY_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_ENTITY_CODE] WHERE [ENTITY_CODE]=@ENTITY_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_ENTITY_CODE','',@AfterImage,'U';			
		END
	END
	
	

COMMIT

GO
