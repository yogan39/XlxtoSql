SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[ZuspListDEPTListing]

	 ( @ROLE_ID varchar (10),
	  @DeptName varchar(30),
	  @STATUS VARCHAR(1))

AS
BEGIN
		IF(@ROLE_ID='AdminAA')
		BEGIN
		
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			WHEN dept.[STATUS] =  'N' THEN 'Pending New Approval'
			WHEN dept.[STATUS] =  'U' THEN 'Pending Updated Approval'
			WHEN dept.[STATUS] =  'R' THEN 'Rejected'
			WHEN dept.[STATUS] =  'A' THEN 'Approved'
			 
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE] WHERE lob.STATUS ='A'
		ORDER BY dept.[DEPT_CODE]

		END
	ELSE
		BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			WHEN dept.[STATUS] =  'R' THEN 'Rejected'
			WHEN dept.[STATUS] =  'A' THEN 'Approved'
			 
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE] WHERE depT.STATUS IN ('A','R') AND lob.STATUS = 'A'
		ORDER BY dept.[DEPT_CODE]
		END
END

GO
