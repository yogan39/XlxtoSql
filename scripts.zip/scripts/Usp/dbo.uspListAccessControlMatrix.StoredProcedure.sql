SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListAccessControlMatrix]

@UNIT_ID varchar(3)

AS

	declare @strSQL varchar(3000)
	
	set @strSQL = 'SELECT a.[UNIT_ID] AS [UNIT ID],c.[UNIT_CODE_NM] AS [UNIT NAME],a.[USER_NAME] AS [USER NAME],a.[USER_ID] AS [USER ID],'
	set @strSQL = @strSQL + 'a.[IP_ADDRESS] AS [IP ADDRESS],a.[USER_ROLE_ID] AS [ROLE ID],b.[PAGE_DSC] AS [MODULE NAME],'
	set @strSQL = @strSQL + 'd.[USER_STAT_CODE_DSC] as [STATUS],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGIN],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGIN],114) AS [LAST LOGIN],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGOT],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGOT],114) AS [LAST LOGOUT] '
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_USERS] a, [dbo].[RRF_GUI_PAGE_CODES] b, [dbo].[RRF_GUI_UNIT_CODE] c, [dbo].[RRF_GUI_REF_USERSTAT] d '
	set @strSQL = @strSQL + 'WHERE a.[USER_ROLE_ID]=''Admin'' AND b.[PAGE_CODE] IN (''SEC001'',''SEC002'',''SEC003'',''SEC004'') '
	set @strSQL = @strSQL + 'AND a.[UNIT_ID]=c.[UNIT_CODE] AND a.[STATUS_ID]=d.[USER_STAT_CODE] '
	
	IF @UNIT_ID <> ''
	begin
		set @strSQL = @strSQL + ' AND a.[UNIT_ID]=''' + @UNIT_ID + ''''
	end
	
	set @strSQL = @strSQL + ' UNION ALL '
	
	set @strSQL = @strSQL + 'SELECT a.[UNIT_ID],c.[UNIT_CODE_NM],a.[USER_NAME],a.[USER_ID],a.[IP_ADDRESS],a.[USER_ROLE_ID],b.[PAGE_DSC] AS [MODULE_DESC],'
	set @strSQL = @strSQL + 'd.[USER_STAT_CODE_DSC] as [STATUS_DESC],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGIN],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGIN],114) AS [TS_LAST_LGIN],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGOT],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGOT],114) AS [TS_LAST_LGOT] '
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_USERS] a, [dbo].[RRF_GUI_PAGE_CODES] b, [dbo].[RRF_GUI_UNIT_CODE] c, [dbo].[RRF_GUI_REF_USERSTAT] d '
	set @strSQL = @strSQL + 'WHERE a.[USER_ROLE_ID]<>''Admin'' AND b.[PAGE_CODE] IN (''CON001'',''CON002'') '
	set @strSQL = @strSQL + 'AND a.[UNIT_ID]=c.[UNIT_CODE] AND a.[STATUS_ID]=d.[USER_STAT_CODE] '
	
	IF @UNIT_ID <> ''
	begin
		set @strSQL = @strSQL + ' AND a.[UNIT_ID]=''' + @UNIT_ID + ''''
	end

	set @strSQL = @strSQL + ' ORDER BY a.[UNIT_ID],a.[USER_ID],b.[PAGE_DSC]'
	
	print @strSQL
	
	EXECUTE(@strSQL)

GO
