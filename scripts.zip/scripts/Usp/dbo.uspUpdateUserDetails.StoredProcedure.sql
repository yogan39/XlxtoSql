SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspUpdateUserDetails]

@UPDATE_TYPE char(1),
@DATA_DETAILS As [dbo].[DataTypeUpdateUser] Readonly,
@MAKER_ID Varchar(30)

AS
Begin Tran

	declare @BeforeImage varchar(max)
	declare @AfterImage varchar(max)
	declare @User_Id varchar(30)
	
	SET @USER_ID = (SELECT [USER_ID] FROM @DATA_DETAILS)
		
	IF @UPDATE_TYPE = 'I'
	begin	
	
		INSERT INTO [dbo].[RRF_GUI_USERS]
			([USER_ID],[USER_DOMAIN_ID],[USER_NAME],[UNIT_ID],[USER_ROLE_ID],[STATUS_ID],[USER_STAT_REASON],[CRETN_DT],[TS_LAST_LGIN],[TS_LAST_LGOT],
			[IS_CURRLY_LOGGED_IN],[LAST_LGIN_IP_ADR],[LOG_UPDT_USER_ID],[LOG_UPDT_DT],[EMP_ID],[USER_EMAIL],[IP_ADDRESS])
		SELECT [USER_ID],[USER_DOMAIN_ID],[USER_NAME],[UNIT_ID],[USER_ROLE_ID],[STATUS_ID],[USER_STAT_REASON],GETDATE(),NULL,NULL,
			[IS_CURRLY_LOGGED_IN],NULL,@USER_ID,GETDATE(),[EMP_ID],[USER_EMAIL],[IP_ADDRESS] FROM @DATA_DETAILS;
		
		SET @AfterImage = (SELECT [USER_ID] + ' | ' + [USER_DOMAIN_ID] + ' | ' + [USER_NAME] + ' | ' + [UNIT_ID] + ' | ' + [USER_ROLE_ID] + ' | ' + [STATUS_ID] +  ' | ' + isnull([USER_STAT_REASON],'') +  ' | ' + CAST([CRETN_DT] AS VARCHAR) + ' | ' + isnull(CAST([TS_LAST_LGIN] AS VARCHAR),'') + ' | ' + isnull(CAST([TS_LAST_LGOT] AS VARCHAR),'') + ' | ' + [IS_CURRLY_LOGGED_IN] + ' | ' + isnull([LAST_LGIN_IP_ADR],'') + ' | ' + [LOG_UPDT_USER_ID] + ' | ' + CAST([LOG_UPDT_DT] AS VARCHAR) + ' | ' + isnull([EMP_ID],'') + ' | ' + isnull([USER_EMAIL],'')  + ' | ' + isnull([IP_ADDRESS],'') FROM [dbo].[RRF_GUI_USERS] WHERE [USER_ID]=@USER_ID);
		
		EXEC [dbo].[uspAuditTrail] @MAKER_ID,'RRF_GUI_USERS','',@AfterImage,'I';
		
	end
	
	IF @UPDATE_TYPE = 'U'
	begin
		
		SET @BeforeImage = (SELECT [USER_ID] + ' | ' + [USER_DOMAIN_ID] + ' | ' + [USER_NAME] + ' | ' + [UNIT_ID] + ' | ' + [USER_ROLE_ID] + ' | ' + [STATUS_ID] +  ' | ' + isnull([USER_STAT_REASON],'') +  ' | ' + CAST([CRETN_DT] AS VARCHAR) + ' | ' + isnull(CAST([TS_LAST_LGIN] AS VARCHAR),'') + ' | ' + isnull(CAST([TS_LAST_LGOT] AS VARCHAR),'') + ' | ' + [IS_CURRLY_LOGGED_IN] + ' | ' + isnull([LAST_LGIN_IP_ADR],'') + ' | ' + [LOG_UPDT_USER_ID] + ' | ' + CAST([LOG_UPDT_DT] AS VARCHAR) + ' | ' + isnull([EMP_ID],'') + ' | ' + isnull([USER_EMAIL],'')  + ' | ' + isnull([IP_ADDRESS],'') FROM [dbo].[RRF_GUI_USERS] WHERE [USER_ID]=@USER_ID);
		
		UPDATE a
		SET a.[USER_DOMAIN_ID]=b.[USER_DOMAIN_ID],a.[USER_NAME]=b.[USER_NAME],a.[UNIT_ID]=b.[UNIT_ID],a.[USER_ROLE_ID]=b.[USER_ROLE_ID],
			a.[STATUS_ID]=b.[STATUS_ID],a.[USER_STAT_REASON]=b.[USER_STAT_REASON],a.[IS_CURRLY_LOGGED_IN]=b.[IS_CURRLY_LOGGED_IN],
			a.[EMP_ID]=b.[EMP_ID],a.[USER_EMAIL]=b.[USER_EMAIL],a.[IP_ADDRESS]=b.[IP_ADDRESS],
			a.[LOG_UPDT_USER_ID]=@MAKER_ID,a.[LOG_UPDT_DT]=GETDATE()
		FROM [dbo].[RRF_GUI_USERS] a INNER JOIN @DATA_DETAILS b on a.[USER_ID]=b.[USER_ID];
			
		SET @AfterImage = (SELECT [USER_ID] + ' | ' + [USER_DOMAIN_ID] + ' | ' + [USER_NAME] + ' | ' + [UNIT_ID] + ' | ' + [USER_ROLE_ID] + ' | ' + [STATUS_ID] +  ' | ' + isnull([USER_STAT_REASON],'') +  ' | ' + CAST([CRETN_DT] AS VARCHAR) + ' | ' + isnull(CAST([TS_LAST_LGIN] AS VARCHAR),'') + ' | ' + isnull(CAST([TS_LAST_LGOT] AS VARCHAR),'') + ' | ' + [IS_CURRLY_LOGGED_IN] + ' | ' + isnull([LAST_LGIN_IP_ADR],'') + ' | ' + [LOG_UPDT_USER_ID] + ' | ' + CAST([LOG_UPDT_DT] AS VARCHAR) + ' | ' + isnull([EMP_ID],'') + ' | ' + isnull([USER_EMAIL],'')  + ' | ' + isnull([IP_ADDRESS],'') FROM [dbo].[RRF_GUI_USERS] WHERE [USER_ID]=@USER_ID);
		
		EXEC [dbo].[uspAuditTrail] @MAKER_ID,'RRF_GUI_USERS',@BeforeImage,@AfterImage,'U';
		
	end	

	IF @UPDATE_TYPE = 'D'

	begin
		
		SET @BeforeImage = (SELECT [USER_ID] + ' | ' + [USER_DOMAIN_ID] + ' | ' + [USER_NAME] + ' | ' + [UNIT_ID] + ' | ' + [USER_ROLE_ID] + ' | ' + [STATUS_ID] +  ' | ' + isnull([USER_STAT_REASON],'') +  ' | ' + CAST([CRETN_DT] AS VARCHAR) + ' | ' + isnull(CAST([TS_LAST_LGIN] AS VARCHAR),'') + ' | ' + isnull(CAST([TS_LAST_LGOT] AS VARCHAR),'') + ' | ' + [IS_CURRLY_LOGGED_IN] + ' | ' + isnull([LAST_LGIN_IP_ADR],'') + ' | ' + [LOG_UPDT_USER_ID] + ' | ' + CAST([LOG_UPDT_DT] AS VARCHAR) + ' | ' + isnull([EMP_ID],'') + ' | ' + isnull([USER_EMAIL],'')  + ' | ' + isnull([IP_ADDRESS],'') FROM [dbo].[RRF_GUI_USERS] WHERE [USER_ID]=@USER_ID);
		
		UPDATE [dbo].[RRF_GUI_USERS] SET [STATUS_ID]='X',[LOG_UPDT_USER_ID]=@MAKER_ID,[LOG_UPDT_DT]=GETDATE() WHERE [USER_ID]=@USER_ID;

		SET @AfterImage = (SELECT [USER_ID] + ' | ' + [USER_DOMAIN_ID] + ' | ' + [USER_NAME] + ' | ' + [UNIT_ID] + ' | ' + [USER_ROLE_ID] + ' | ' + [STATUS_ID] +  ' | ' + isnull([USER_STAT_REASON],'') +  ' | ' + CAST([CRETN_DT] AS VARCHAR) + ' | ' + isnull(CAST([TS_LAST_LGIN] AS VARCHAR),'') + ' | ' + isnull(CAST([TS_LAST_LGOT] AS VARCHAR),'') + ' | ' + [IS_CURRLY_LOGGED_IN] + ' | ' + isnull([LAST_LGIN_IP_ADR],'') + ' | ' + [LOG_UPDT_USER_ID] + ' | ' + CAST([LOG_UPDT_DT] AS VARCHAR) + ' | ' + isnull([EMP_ID],'') + ' | ' + isnull([USER_EMAIL],'')  + ' | ' + isnull([IP_ADDRESS],'') FROM [dbo].[RRF_GUI_USERS] WHERE [USER_ID]=@USER_ID);
		
		EXEC [dbo].[uspAuditTrail] @MAKER_ID,'RRF_GUI_USERS', @BeforeImage,@AfterImage,'D';

		
		
	end	
	
Commit

GO
