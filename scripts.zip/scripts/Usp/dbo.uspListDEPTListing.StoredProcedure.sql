SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListDEPTListing]

@UNIT_ID varchar(10),
@LOB_CD varchar(10),
@ROLE_ID varchar (10),
@DEPT_CD varchar (10)

AS	 
	IF (@LOB_CD = 'All' AND @DEPT_CD = 'All')
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			 WHEN dept.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		ORDER BY dept.[DEPT_CODE]		
	END
	
	IF (@LOB_CD = 'All2' AND @DEPT_CD = 'All')
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			 WHEN dept.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		ORDER BY dept.[DEPT_CODE]		
	END
	
	ELSE
	IF (@LOB_CD = 'All' AND @DEPT_CD != 'All')
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			 WHEN dept.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		WHERE dept.[DEPT_CODE] = @DEPT_CD
		ORDER BY dept.[DEPT_CODE]		
	END
	
	ELSE
	IF (@LOB_CD != 'All' AND @DEPT_CD = 'All')
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			 WHEN dept.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		WHERE dept.[LOB_CODE] = @LOB_CD
		ORDER BY dept.[DEPT_CODE]		
	END
	
	ELSE	
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],[STATUS]=
		CASE 
			 WHEN dept.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		dept.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		WHERE dept.[LOB_CODE] = @LOB_CD AND dept.[DEPT_CODE] = @DEPT_CD
		ORDER BY dept.[DEPT_CODE]		
	END
	
	
	
GO
