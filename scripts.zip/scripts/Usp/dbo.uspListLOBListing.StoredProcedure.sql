SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListLOBListing]

@UNIT_ID varchar(10),
@LOB_CD varchar(10),
@ROLE_ID varchar (10)

AS	 
	IF (@LOB_CD = 'All')
	BEGIN
		SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  'N' THEN 'Pending Approval'
			 WHEN [STATUS] =  'R' THEN 'Rejected'
			 ELSE 'Approved'
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_LOB_CODE]
		ORDER BY [LOB_CODE]
	END
	ELSE
	BEGIN
		SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  'N' THEN 'Pending Approval'
			 WHEN [STATUS] =  'R' THEN 'Rejected'
			 ELSE 'Approved'
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_LOB_CODE] lob 
		WHERE lob.LOB_CODE = @LOB_CD
		ORDER BY [LOB_CODE]
	END
	
	
GO
