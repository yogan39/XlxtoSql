SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspAuditTrail]

@UserId varchar(30),
@TableName varchar(100),
@BeforeImage varchar(8000),
@AfterImage varchar(8000),
@Action char(10)

as

IF @Action='U' 
begin

	CREATE TABLE #temp
	(
		before_image varchar(8000),
		after_image varchar(8000),
		Diff_Image varchar(8000)
	)

	INSERT INTO #temp (before_image,after_image,Diff_Image)
		Select A.value as before_image,B.value  as after_image,
		CASE
		WHEN (A.value = B.Value)
		THEN
		'NC'
		ELSE
		B.Value 
		END as Diff_Image
		from
		(
		select *  from dbo.split (@BeforeImage,'|')
		) A,
		(
		select * from dbo.split (@AfterImage,'|')
		) B
		Where A.id = B.id

	--select * from #temp

	declare @retstr varchar(8000)
	  
	SELECT @retstr =  COALESCE(@retstr + ' | ','') + Diff_Image from #temp  
	
	INSERT INTO [dbo].[RRF_GUI_AUDT_TRL] (UPDT_USER_ID, LOG_UPDT_DT, TBL_NM, BEFORE_IMG, AFTER_IMG, DIFF, ACTN)
		select @UserId ,GetDate(),@TableName ,@BeforeImage ,@AfterImage,@retstr ,@Action
	
	DROP TABLE #temp

end

IF @Action='A' 
begin

	CREATE TABLE #tempApprv
	(
		before_image varchar(8000),
		after_image varchar(8000),
		Diff_Image varchar(8000)
	)

	INSERT INTO #tempApprv (before_image,after_image,Diff_Image)
		Select A.value as before_image,B.value  as after_image,
		CASE
		WHEN (A.value = B.Value)
		THEN
		'NC'
		ELSE
		B.Value 
		END as Diff_Image
		from
		(
		select *  from dbo.split (@BeforeImage,'|')
		) A,
		(
		select * from dbo.split (@AfterImage,'|')
		) B
		Where A.id = B.id

	--select * from #temp

	declare @retstrApprv varchar(8000)  
	
	SELECT @retstrApprv =  COALESCE(@retstrApprv + ' | ','') + Diff_Image from #tempApprv  
	
	INSERT INTO [dbo].[RRF_GUI_AUDT_TRL] (UPDT_USER_ID, LOG_UPDT_DT, TBL_NM, BEFORE_IMG, AFTER_IMG, DIFF, ACTN)
		select @UserId ,GetDate(),@TableName ,@BeforeImage ,@AfterImage,@retstrApprv ,@Action
		
	DROP TABLE #tempApprv

end

IF @Action='I' 
begin 

	begin tran

		INSERT INTO [dbo].[RRF_GUI_AUDT_TRL] (UPDT_USER_ID, LOG_UPDT_DT, TBL_NM, BEFORE_IMG, AFTER_IMG, DIFF, ACTN)
			values (@UserId,getdate(),@TableName,@BeforeImage,@AfterImage,@AfterImage,@Action)

	commit

end

IF @Action='D' 
begin 

	begin tran

		INSERT INTO [dbo].[RRF_GUI_AUDT_TRL] (UPDT_USER_ID, LOG_UPDT_DT, TBL_NM, BEFORE_IMG, AFTER_IMG, DIFF, ACTN)
			values (@UserId,getdate(),@TableName,@BeforeImage,@AfterImage,@BeforeImage,@Action)

	commit

end

GO
