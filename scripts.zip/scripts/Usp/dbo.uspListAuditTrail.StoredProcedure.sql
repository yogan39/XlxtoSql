SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListAuditTrail]

@LIST_TYPE char(1),
@UPDT_USER_ID varchar(30),
@LOG_UPDT_DT_FROM varchar(50),
@LOG_UPDT_DT_TO varchar(50),
@TBL_NM varchar(50),
@ACTN char(1)

AS

	declare @strSQL varchar(1000)
	declare @strSQLCondition varchar(1000)
	declare @strDateFrom varchar(50)
	declare @strDateTo varchar(50)
	
	set @strSQLCondition = ''
	
	IF @UPDT_USER_ID <> ''
		set @strSQLCondition = ' WHERE UPDT_USER_ID=''' + @UPDT_USER_ID + ''''
	
	IF @LOG_UPDT_DT_FROM <> '' AND @LOG_UPDT_DT_TO <> '' 
	begin
		set @strDateFrom = substring(@LOG_UPDT_DT_FROM,7,4) + '/' + substring(@LOG_UPDT_DT_FROM,4,2) + '/' + substring(@LOG_UPDT_DT_FROM,1,2) + ' 00:00:00'
		set @strDateTo = substring(@LOG_UPDT_DT_TO,7,4) + '/' + substring(@LOG_UPDT_DT_TO,4,2) + '/' + substring(@LOG_UPDT_DT_TO,1,2) + ' 23:59:59'
		
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND LOG_UPDT_DT BETWEEN ''' + @strDateFrom + ''' AND ''' + @strDateTo + ''''
		else
			set @strSQLCondition = ' WHERE LOG_UPDT_DT BETWEEN ''' + @strDateFrom + ''' AND ''' + @strDateTo + ''''
	end
	
	IF @TBL_NM <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND TBL_NM=''' + @TBL_NM + ''''
		else
			set @strSQLCondition = ' WHERE TBL_NM=''' + @TBL_NM + ''''
	end
	
	IF @ACTN <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND ACTN=''' + @ACTN + ''''
		else
			set @strSQLCondition = ' WHERE ACTN=''' + @ACTN + ''''
	end
	
	set @strSQL = 'SELECT [ID],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,[LOG_UPDT_DT],103) + '' '' + CONVERT(VARCHAR,[LOG_UPDT_DT],114) AS [LOG_UPDT_DT]'
	set @strSQL = @strSQL + ',[TBL_NM],[UPDT_USER_ID]'
	set @strSQL = @strSQL + ',CASE [ACTN] WHEN ''D'' THEN ''DELETE'' WHEN ''I'' THEN ''INSERT'' WHEN ''U'' THEN ''UPDATE'' END AS [ACTN]'
	
	IF @LIST_TYPE = 'P' 
	begin
		set @strSQL = @strSQL + ',[BEFORE_IMG],[AFTER_IMG],[DIFF]'
	end
	
	set @strSQL = @strSQL + ' FROM [dbo].[RRF_GUI_AUDT_TRL]' + @strSQLCondition
	set @strSQL = @strSQL + ' ORDER BY [ID],[LOG_UPDT_DT],[TBL_NM],[UPDT_USER_ID],[ACTN]'
	
	EXECUTE(@strSQL)
GO
