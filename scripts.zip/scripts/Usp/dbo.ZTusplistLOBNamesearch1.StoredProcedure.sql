SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE  [dbo].[ZTusplistLOBNamesearch1]

	  @ROLE_ID varchar (10),
	  @Lobname varchar(30)
AS

DECLARE @SQLQUERY NVARCHAR(500)


IF(@ROLE_ID='AdminAA')

		BEGIN
		SET @SQLQUERY = 'SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],
		[STATUS]= CASE
		WHEN [STATUS] =  ''N'' THEN ''Pending New Approval''
		WHEN [STATUS] =  ''U'' THEN ''Pending Updated Approval''
		WHEN [STATUS] =  ''R'' THEN ''Rejected''
		WHEN [STATUS] =  ''A'' THEN ''ApprovedAA''
		END,[REJECT_REASON]	FROM [dbo].[RRF_GUI_LOB_CODE] ORDER BY [LOB_CODE_NM] WHERE LOB_CODE_NM LIKE ''%'+ @Lobname +'%'' ORDER BY [LOB_CODE_NM]'

		EXECUTE(@SQLQUERY)
		END
	ELSE

	BEGIN
	SET @SQLQUERY = 'SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  ''A'' THEN ''ApprovedADMN''
			 WHEN [STATUS] =  ''R'' THEN ''Rejected''
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_LOB_CODE] where STATUS in (''A'',''R'') AND LOB_CODE_NM LIKE ''%'+ @Lobname +'%'' ORDER BY [LOB_CODE_NM]'

		EXECUTE(@SQLQUERY)
	END

GO
