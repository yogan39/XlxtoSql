SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListESubmissions]

@UNIT_ID varchar(3),
@RPT_ID varchar(9),
@RPT_NAME varchar(255),
@REGULATOR_ID varchar(3),
@SREF char(1),
@FREQUENCY_ID varchar(3),
@STATUS_ALL char(1),
@STATUS_DRAFT char(1),
@STATUS_NEW char(1),
@STATUS_APP char(1),
@STATUS_REJ char(1),
@STATUS_PA char(1),
@FROM_DATE varchar(10),
@TO_DATE varchar(10),
@IF_REJECT char(1),
@ROLE_ID varchar(10),
@STATUS_DUE char(1),
@STATUS_PASTDUE char(1)

AS

	declare @strSQL varchar(3000)
	declare @strSQLCondition varchar(1000)
	declare @strSQLCondition_Status varchar(1000)
	declare @strSQLCondition_DateRange varchar(1000)
	declare @strSQLOrderBy varchar(1000)
	declare @strFromDate varchar(50)
	declare @strToDate varchar(50)
	
	set @strSQLOrderBy = ' ORDER BY a.[CREATE_DATE]'

	set @strSQL = 'SELECT a.[SUBMISSION_ID] AS [SUBMISSION ID],a.[RPT_ID] AS [RPT ID],b.[RPT_NAME] AS [RPT NAME],CONVERT(VARCHAR,a.[POSITION_DATE],103) AS [POSITION DATE],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TARGET_SUBMISSION_DATE],103) AS [TARGET SUBMISSION DATE],'
	set @strSQL = @strSQL + 'c.[REGULATOR_DESC] AS [REGULATOR],'
	set @strSQL = @strSQL + 'CASE b.[SREF] WHEN ''1'' THEN ''Yes(Monetary Penalty)'' WHEN ''2'' THEN ''Yes(Non-Monetary Penalty)'' WHEN ''N'' THEN ''No'' ELSE b.[SREF] END AS [SREF],'
	
	--megatshamsul - 20170322 - SR1363674 - set status 'AP2' as APPROVED if compliance, else status quo
	--set @strSQL = @strSQL + 'd.[FREQUENCY_DESC] AS [FREQUENCY],e.[STATUS_DESC] AS [STATUS],CONVERT(VARCHAR,a.[PREPARER_DATE],103) + '' '' + CONVERT(VARCHAR,a.[PREPARER_DATE],114) AS [DATE PREPARED],'
	set @strSQL = @strSQL + 'd.[FREQUENCY_DESC] AS [FREQUENCY],'
	set @strSQL = @strSQL + 'CASE WHEN a.[STATUS_ID]=''AP2'' AND a.[COMPLIANCE]=''Y'' THEN ''Approved By Approver'' ELSE e.[STATUS_DESC] END AS [STATUS],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[PREPARER_DATE],103) + '' '' + CONVERT(VARCHAR,a.[PREPARER_DATE],114) AS [DATE PREPARED],'
	
	set @strSQL = @strSQL + 'a.[STATUS_ID],a.[ROW_NUM] '
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] a '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_ETEMPLATE_DATA] b on a.[RPT_ID]=b.[RPT_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_REGULATOR_CODE] c on b.[REGULATOR_ID]=c.[REGULATOR_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_FREQUENCY_CODE] d on b.[FREQUENCY_ID]=d.[FREQUENCY_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_STATUS_CODE] e on a.[STATUS_ID]=e.[STATUS_ID]'
	
	set @strSQLCondition = ' WHERE b.[STATUS_ID] IN (''AP2'',''X'')'	--report final status only
	set @strSQLCondition = @strSQLCondition + ' AND a.[STATUS_ID] NOT IN (''Z'')'	--ignore Removed eSubmission
	
	if @ROLE_ID <> 'FGTAppvr'	--FGTAppvr has access to all reports
		set @strSQLCondition = @strSQLCondition + ' AND b.[UNIT_ID]=''' + @UNIT_ID + ''''
	
	IF @RPT_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[RPT_ID]=''' + @RPT_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE a.[RPT_ID]=''' + @RPT_ID + ''''
	end
	
	IF @RPT_NAME <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND b.[RPT_NAME] LIKE ''%' + @RPT_NAME + '%'''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE b.[RPT_NAME] LIKE ''%' + @RPT_NAME + '%'''
	end

	IF @REGULATOR_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND b.[REGULATOR_ID]=''' + @REGULATOR_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE b.[REGULATOR_ID]=''' + @REGULATOR_ID + ''''
	end
	
	IF @SREF <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND b.[SREF]=''' + @SREF + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE b.[SREF]=''' + @SREF + ''''
	end
	
	IF @FREQUENCY_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND b.[FREQUENCY_ID]=''' + @FREQUENCY_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' AND b.[FREQUENCY_ID]=''' + @FREQUENCY_ID + ''''
	end
	
	IF @STATUS_ALL = '0'
	begin
	
		set @strSQLCondition_Status = ''
		
		if @STATUS_DRAFT = '1'
			set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''D1'',''D2'',''D3'')'
		
		if @STATUS_NEW = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'')'
		end
		
		if @STATUS_APP = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''AP1'',''AP2'',''APX1'',''X'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''AP1'',''AP2'',''APX1'',''X'')'
		end
		
		if @STATUS_REJ = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''RJ1'',''RJ2'',''RJX1'',''RJX2'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''RJ1'',''RJ2'',''RJX1'',''RJX2'')'
		end
		
		if @STATUS_PA = '1'
		begin
			if @ROLE_ID = 'Approver'
			begin
				if @strSQLCondition_Status <> ''
					set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'')'
				else
					set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'')'
			end
			else
			begin
				if @ROLE_ID = 'FGTAppvr'
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''AP1'',''APX1'')'
					else
						set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''AP1'',''APX1'')'
				end
				else
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'',''AP1'',''APX1'')'
					else
						set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'',''AP1'',''APX1'')'
				end
			end
		end

		DECLARE @T_date VARCHAR(10)
		SET @T_date = CAST(CONVERT(DATE, GETDATE()) AS VARCHAR(10))
				
		if @STATUS_DUE = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[POSITION_DATE]=''' + @T_date + ''''
			else
				set @strSQLCondition_Status = 'a.[POSITION_DATE]=''' + @T_date + ''''
		end
		
		if @STATUS_PASTDUE = '1'
		begin
			if @ROLE_ID = 'Approver'
			begin
				if @strSQLCondition_Status <> ''
					set @strSQLCondition_Status = @strSQLCondition_Status + ' OR (a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] IN (''N'',''U'',''XR''))'
				else
					set @strSQLCondition_Status = '(a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] IN (''N'',''U'',''XR''))'
			end
			else
			begin
				if @ROLE_ID = 'FGTAppvr'
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR (a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] IN (''AP1'',''APX1''))'
					else
						set @strSQLCondition_Status = '(a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] IN (''AP1'',''APX1''))'
				end
				else
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR (a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] NOT IN (''AP2'',''X'',''Z'',''O''))'
					else
						set @strSQLCondition_Status = '(a.[POSITION_DATE]<''' + @T_date + ''' AND a.[STATUS_ID] NOT IN (''AP2'',''X'',''Z'',''O''))'
				end
			end
		end
		
		if @strSQLCondition_Status <> ''
			set @strSQLCondition = @strSQLCondition + ' AND (' + @strSQLCondition_Status + ')'
		
	end

	IF @FROM_DATE <> '' AND @TO_DATE <> ''
	begin

		set @strFromDate = substring(@FROM_DATE,7,4) + '/' + substring(@FROM_DATE,4,2) + '/' + substring(@FROM_DATE,1,2) + ' 00:00:00'
		set @strToDate = substring(@TO_DATE,7,4) + '/' + substring(@TO_DATE,4,2) + '/' + substring(@TO_DATE,1,2) + ' 23:59:59'
		set @strSQLCondition_DateRange = ''
		
		IF @STATUS_ALL = '1'
		begin
			set @strSQLCondition_DateRange = '(a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
		end
		ELSE
		begin
		
			if @STATUS_DRAFT = '1' OR @STATUS_NEW = '1'
			begin
				if @strSQLCondition_DateRange <> ''
					set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				else
					set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			end
			
			if @STATUS_APP = '1' OR @STATUS_REJ = '1'
			begin
				if @strSQLCondition_DateRange <> ''
					set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_FGT_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				else
					set @strSQLCondition_DateRange = '(a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_FGT_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			end
			
			if @STATUS_PA = '1'
			begin
				if @ROLE_ID = 'Approver'
				begin
					if @strSQLCondition_DateRange <> ''
						set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					else
						set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				end
				else
				begin
					if @ROLE_ID = 'FGTAppvr'
					begin
					if @strSQLCondition_DateRange <> ''
						set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					else
						set @strSQLCondition_DateRange = '(a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					end
					else
					begin
						if @strSQLCondition_DateRange <> ''
							set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
						else
							set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					end
				end
			end		
		
		end
	
		if @STATUS_DUE = '1'
		begin
			if @strSQLCondition_DateRange <> ''
				set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			else
				set @strSQLCondition_DateRange = '(a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'		
		end
		
		if @STATUS_PASTDUE = '1'
		begin
			if @strSQLCondition_DateRange <> ''
				set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[POSITION_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			else
				set @strSQLCondition_DateRange = '(a.[POSITION_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'		
		end
		
		if @strSQLCondition_DateRange = ''
			set @strSQLCondition_DateRange = '(a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'

		set @strSQLCondition = @strSQLCondition + ' AND (' + @strSQLCondition_DateRange + ')'
		
	end

	IF @IF_REJECT = '1'
		set @strSQLCondition = @strSQLCondition + ' AND a.[STATUS_ID] IN (''RJ1'',''RJ2'',''RJX1'',''RJX2'')'
	
	set @strSQL = @strSQL + @strSQLCondition + @strSQLOrderBy

	EXECUTE(@strSQL)

GO
