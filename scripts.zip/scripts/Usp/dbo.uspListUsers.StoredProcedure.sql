SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListUsers]

@USER_ID varchar(30),
@UNIT_ID varchar(3),
@ROLE_ID varchar(10),
@USER_Name varchar(30)--Yogan Added Search by Name according to SR''

AS

	declare @strSQL varchar(3000)
	declare @strSQLCondition varchar(1000)
	declare @strSQLOrderBy varchar(1000)
	
	set @strSQLOrderBy = ' ORDER BY a.[USER_ID]'
	
	set @strSQL = 'SELECT a.[USER_ID],a.[USER_NAME],a.[EMP_ID],b.[UNIT_CODE_NM] AS [UNIT_DESC],c.[GUI_ROLE_DSC] AS [ROLE_DESC],'
	set @strSQL = @strSQL + 'd.[USER_STAT_CODE_DSC] as [STATUS_DESC],a.[LOG_UPDT_USER_ID] AS [UPDT_USER_ID],a.[DAYS_TO_DORMANT] AS [DRMT_DAYS],'---added dorman days
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[LOG_UPDT_DT],103) + '' '' + CONVERT(VARCHAR,a.[LOG_UPDT_DT],114) AS [UPDT_DATE] '
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_USERS] a '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_UNIT_CODE] b on a.[UNIT_ID]=b.[UNIT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_USER_ROLE] c on a.[USER_ROLE_ID]=c.[GUI_RULE_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_REF_USERSTAT] d on a.[STATUS_ID]=d.[USER_STAT_CODE] '
	
	set @strSQLCondition = ' WHERE a.[STATUS_ID]<>''X'''	--ignore DELETED

		IF @USER_Name <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND a.[USER_NAME] LIKE ''%' + @USER_Name + '%'''--Yogan Added Search by Name according to SR''
	end
	
	IF @USER_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND a.[USER_ID] LIKE ''%' + @USER_ID + '%'''
	end
	
	IF @UNIT_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND a.[UNIT_ID] = ''' + @UNIT_ID + ''''
	end
	
	IF @ROLE_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND [GUI_RULE_CODE]=''' + @ROLE_ID + ''''
	end		
	
	set @strSQL = @strSQL + @strSQLCondition + @strSQLOrderBy
	
	EXECUTE(@strSQL)

GO
