SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[ZTuspListLOBListing]
    @ROLE_ID varchar (10),
	@Lobname varchar(30),
	@STATUS VARCHAR (1)
AS

    IF(@ROLE_ID='AdminAA')

		BEGIN
		  
		SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],
		[STATUS]= CASE
		WHEN [STATUS] =  'N' THEN 'Pending New Approval'
		WHEN [STATUS] =  'U' THEN 'Pending Updated Approval'
		WHEN [STATUS] =  'R' THEN 'Rejected'
		WHEN [STATUS] =  'A' THEN 'Approved'
		END,[REJECT_REASON]	FROM [dbo].[RRF_GUI_LOB_CODE] ORDER BY [LOB_CODE_NM]

		END
	ELSE

	BEGIN


	SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  'A' THEN 'Approved'
			 WHEN [STATUS] =  'R' THEN 'Rejected'
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_LOB_CODE] where STATUS in ('A','R') ORDER BY [LOB_CODE_NM]

	END

GO
