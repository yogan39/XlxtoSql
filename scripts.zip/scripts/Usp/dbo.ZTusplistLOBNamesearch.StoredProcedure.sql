SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[ZTusplistLOBNamesearch]
	 ( @ROLE_ID varchar (10),
	  @Lobname varchar(30),
	  @STATUS VARCHAR(1))
AS

    IF(@ROLE_ID='AdminAA')

		BEGIN
	
		  IF @Lobname<>''
			   BEGIN
					SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],
					[STATUS]= CASE
					WHEN [STATUS] =  'N' THEN 'Pending For Approval'
					WHEN [STATUS] =  'U' THEN 'Pending For Approval'
					WHEN [STATUS] =  'R' THEN 'Rejected'
					WHEN [STATUS] =  'A' THEN 'Approved'
					END,[REJECT_REASON]	FROM [dbo].[RRF_GUI_LOB_CODE] WHERE LOB_CODE_NM LIKE '%'+ @Lobname +'%' ORDER BY [LOB_CODE_NM]
			   END
		   ELSE IF @STATUS='P'
			   BEGIN
		   			SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],
					[STATUS]= CASE
					WHEN [STATUS] =  'N' THEN 'Pending For Approval'
					WHEN [STATUS] =  'U' THEN 'Pending For Approval'
					WHEN [STATUS] =  'R' THEN 'Rejected'
					WHEN [STATUS] =  'A' THEN 'Approved'
					END,[REJECT_REASON]	FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [STATUS] IN ('N','U') ORDER BY [LOB_CODE_NM]
			   END
			ELSE
			  BEGIN
		   			SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],
					[STATUS]= CASE
					WHEN [STATUS] =  'N' THEN 'Pending For Approval'
					WHEN [STATUS] =  'U' THEN 'Pending For Approval'
					WHEN [STATUS] =  'R' THEN 'Rejected'
					WHEN [STATUS] =  'A' THEN 'Approved'
					END,[REJECT_REASON]	FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [STATUS] = @STATUS  ORDER BY [LOB_CODE_NM]
			   END
		END
	ELSE

	BEGIN

	IF @Lobname<>''
		BEGIN
			SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
			CASE 
					WHEN [STATUS] =  'A' THEN 'Approved'
					WHEN [STATUS] =  'R' THEN 'Rejected'
			END,
			[REJECT_REASON]
			FROM [dbo].[RRF_GUI_LOB_CODE] where STATUS in ('A','R') AND LOB_CODE_NM LIKE '%'+@Lobname+'%' ORDER BY [LOB_CODE_NM]
		END
	ELSE
		BEGIN
			SELECT [LOB_CODE],[LOB_CODE_NM],[CHECKER_ID],[STATUS]=
			CASE 
					WHEN [STATUS] =  'A' THEN 'Approved'
					WHEN [STATUS] =  'R' THEN 'Rejected'
			END,
			[REJECT_REASON]
			FROM [dbo].[RRF_GUI_LOB_CODE] where STATUS = @STATUS ORDER BY [LOB_CODE_NM]
		END
	END

GO
