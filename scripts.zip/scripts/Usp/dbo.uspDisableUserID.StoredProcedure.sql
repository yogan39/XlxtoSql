SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[uspDisableUserID]

@USER_ID varchar(30),
@USER_LAN_DMN_ID varchar(50)

as

begin tran

Update dbo.RRF_GUI_USERS set STATUS_ID = 'D',[USER_STAT_REASON]='Locked for 3 wrong passwords.'
	where [USER_ID] = @USER_ID and [USER_DOMAIN_ID] = @USER_LAN_DMN_ID

commit

GO
