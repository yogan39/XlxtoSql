SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspLoadETemplateListing]

@DATA_DETAILS As [dbo].DataTypeLoadETEMPLATE Readonly

AS
Begin Tran

	DECLARE @SREF VARCHAR(30)
	DECLARE @SREF_code VARCHAR(1)
	DECLARE @ENTITY_ID VARCHAR(30)
    DECLARE @RPT_NAME VARCHAR(255)
	DECLARE @REGULATORY_DEPT VARCHAR(600)    --REGULATOR_DEPT
    DECLARE @UNIT_ID VARCHAR(50)
    DECLARE @UNIT_code VARCHAR(3)
    DECLARE @REPORT_CONSOLIDATER VARCHAR(50)
    DECLARE @REPORT_CONTRIBUTOR1 VARCHAR(50)
    DECLARE @REPORT_CONTRIBUTOR2 VARCHAR(50)
    DECLARE @REPORT_CONTRIBUTOR3 VARCHAR(50)
    DECLARE @REPORT_CONTRIBUTOR4 VARCHAR(50)
    DECLARE @REMARKS VARCHAR(50)
    DECLARE @REGULATOR_ID VARCHAR(3)
    DECLARE @SUBMISSION_MODE_ID VARCHAR(3)
    DECLARE @FREQUENCY_ID VARCHAR(30)
    DECLARE @FREQUENCY_code VARCHAR(2)
	DECLARE @T_PLUS_SUBMISSION_DATE VARCHAR(5)
    DECLARE @BIZ_DAYS_ONLY VARCHAR(15)
    DECLARE @date1 VARCHAR(30)
    DECLARE @date1_SD VARCHAR(30)
    DECLARE @date2 VARCHAR(30)
    DECLARE @date2_SD VARCHAR(30)
    DECLARE @date3 VARCHAR(30)
    DECLARE @date3_SD VARCHAR(30)
    DECLARE @date4 VARCHAR(30)
    DECLARE @date4_SD VARCHAR(30)
    DECLARE @date5 VARCHAR(30)
    DECLARE @date5_SD VARCHAR(30)
    DECLARE @date6 VARCHAR(30)
    DECLARE @date6_SD VARCHAR(30)
    DECLARE @date7 VARCHAR(30)
    DECLARE @date7_SD VARCHAR(30)
    DECLARE @date8 VARCHAR(30)
    DECLARE @date8_SD VARCHAR(30)
    DECLARE @date9 VARCHAR(30)
    DECLARE @date9_SD VARCHAR(30)
    DECLARE @date10 VARCHAR(30)
    DECLARE @date10_SD VARCHAR(30)
    DECLARE @date11 VARCHAR(30)
    DECLARE @date11_SD VARCHAR(30)
    DECLARE @date12 VARCHAR(30)
    DECLARE @date12_SD VARCHAR(30)
    DECLARE @Rpt_Id varchar(9)
    DECLARE @iRpt_Id numeric
    DECLARE @ifOK CHAR(1)
    DECLARE @Row_Num_Ind NUMERIC
    DECLARE @Rec_No NUMERIC
    DECLARE @dSUBMISSION_DATE DATE
    DECLARE @LINE_NO NUMERIC
    
    DELETE from [dbo].[RRF_GUI_LOADING_TRACE_DATA]
    SET @LINE_NO = 0
	
	DECLARE Cur_Listing CURSOR FOR SELECT SREF,ENTITY_ID,RPT_NAME,REGULATORY_DEPT,UNIT_ID,REPORT_CONSOLIDATER,REPORT_CONTRIBUTOR1,REPORT_CONTRIBUTOR2,REPORT_CONTRIBUTOR3,
		REPORT_CONTRIBUTOR4,REMARKS,
		--SUBSTRING(REGULATOR_ID,2,3) AS REGULATOR_ID,SUBSTRING(SUBMISSION_MODE_ID,2,3) AS SUBMISSION_MODE_ID,
		REGULATOR_ID,SUBMISSION_MODE_ID,
		FREQUENCY_ID,T_PLUS_SUBMISSION_DATE,BIZ_DAYS_ONLY,
		date1,date1_SD,date2,date2_SD,date3,date3_SD,date4,date4_SD,date5,date5_SD,date6,date6_SD,
		date7,date7_SD,date8,date8_SD,date9,date9_SD,date10,date10_SD,date11,date11_SD,date12,date12_SD 
		FROM @DATA_DETAILS
	OPEN Cur_Listing 
	FETCH NEXT FROM Cur_Listing INTO @SREF,@ENTITY_ID,@RPT_NAME,@REGULATORY_DEPT,@UNIT_ID,@REPORT_CONSOLIDATER,@REPORT_CONTRIBUTOR1,@REPORT_CONTRIBUTOR2,@REPORT_CONTRIBUTOR3,
		@REPORT_CONTRIBUTOR4,@REMARKS,@REGULATOR_ID,@SUBMISSION_MODE_ID,@FREQUENCY_ID,@T_PLUS_SUBMISSION_DATE,@BIZ_DAYS_ONLY,
		@date1,@date1_SD,@date2,@date2_SD,@date3,@date3_SD,@date4,@date4_SD,@date5,@date5_SD,@date6,@date6_SD,
		@date7,@date7_SD,@date8,@date8_SD,@date9,@date9_SD,@date10,@date10_SD,@date11,@date11_SD,@date12,@date12_SD 
	WHILE @@FETCH_STATUS = 0
	BEGIN 
	
		SET @LINE_NO = @LINE_NO + 1
		
		--handle SREF:
		IF @SREF = 'Yes(Monetary Penalty)'
			SET @SREF_code = '1';
		ELSE
		begin
			IF @SREF = 'Yes(Non-Monetary Penalty)'
				SET @SREF_code = '2';
			ELSE
			begin
				IF @SREF = 'No'
					SET @SREF_code = 'N';
				ELSE
					SET @SREF_code = '';
			end
		end
		
		IF LEN(@SREF_code) = 0
		begin
			INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@SREF',@SREF,LEN(@SREF),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING!')
			SET @ifOK = '0'
		end
		ELSE
		begin
			--INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@SREF_code',@SREF_code,LEN(@SREF_code),@SREF)
			SET @ifOK = '1'
		end
		
		IF @ifOK = '1'
		begin
			SET @UNIT_code = NULL
			SELECT @UNIT_code=[UNIT_CODE] FROM [dbo].[RRF_GUI_UNIT_CODE_LOADING] WHERE [UNIT_CODE_NM]=@UNIT_ID
		
			IF @UNIT_code IS NULL
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@UNIT_ID',@UNIT_ID,LEN(@UNIT_ID),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' CANNOT RESOLVE!')
				SET @ifOK = '0'
			end
			ELSE
			begin
				--INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@UNIT_code',@UNIT_code,LEN(@UNIT_code),@UNIT_ID)
				SET @ifOK = '1'
			end
		end
		
		IF @ifOK = '1'
		begin
			SET @FREQUENCY_code = NULL
			SELECT @FREQUENCY_code=FREQUENCY_ID FROM [dbo].[RRF_GUI_FREQUENCY_CODE] WHERE FREQUENCY_DESC=@FREQUENCY_ID
		
			IF @FREQUENCY_code IS NULL
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@FREQUENCY_ID',@FREQUENCY_ID,LEN(@FREQUENCY_ID),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' CANNOT RESOLVE!')
				SET @ifOK = '0'
			end
			ELSE
			begin
				--INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@FREQUENCY_code',@FREQUENCY_code,LEN(@FREQUENCY_code),@FREQUENCY_ID)
				SET @ifOK = '1'
			end
		end
		
		IF @ifOK = '1'
		begin
		
			--T_PLUS_SUBMISSION_DATE
			IF LEN(@T_PLUS_SUBMISSION_DATE) = 0 OR @T_PLUS_SUBMISSION_DATE = 'NULL'
				SET @T_PLUS_SUBMISSION_DATE = NULL
			
			--BIZ_DAYS_ONLY
			IF @BIZ_DAYS_ONLY = 'working days'
				SET @BIZ_DAYS_ONLY = 'Y'
			ELSE
			begin
				IF @BIZ_DAYS_ONLY = 'days'
					SET @BIZ_DAYS_ONLY = 'N'
				ELSE
					SET @BIZ_DAYS_ONLY = NULL
			end
			
			--date1	"31/01/2016 12:00:00 AM"
			IF LEN(@date1) > 0
				SET @date1 = substring(@date1,7,4) + '/' + substring(@date1,4,2) + '/' + substring(@date1,1,2) 
				
			IF LEN(@date2) > 0
				SET @date2 = substring(@date2,7,4) + '/' + substring(@date2,4,2) + '/' + substring(@date2,1,2) 

			IF LEN(@date3) > 0
				SET @date3 = substring(@date3,7,4) + '/' + substring(@date3,4,2) + '/' + substring(@date3,1,2) 

			IF LEN(@date4) > 0
				SET @date4 = substring(@date4,7,4) + '/' + substring(@date4,4,2) + '/' + substring(@date4,1,2) 

			IF LEN(@date5) > 0
				SET @date5 = substring(@date5,7,4) + '/' + substring(@date5,4,2) + '/' + substring(@date5,1,2) 

			IF LEN(@date6) > 0
				SET @date6 = substring(@date6,7,4) + '/' + substring(@date6,4,2) + '/' + substring(@date6,1,2) 

			IF LEN(@date7) > 0
				SET @date7 = substring(@date7,7,4) + '/' + substring(@date7,4,2) + '/' + substring(@date7,1,2) 

			IF LEN(@date8) > 0
				SET @date8 = substring(@date8,7,4) + '/' + substring(@date8,4,2) + '/' + substring(@date8,1,2) 

			IF LEN(@date9) > 0
				SET @date9 = substring(@date9,7,4) + '/' + substring(@date9,4,2) + '/' + substring(@date9,1,2) 

			IF LEN(@date10) > 0
				SET @date10 = substring(@date10,7,4) + '/' + substring(@date10,4,2) + '/' + substring(@date10,1,2) 

			IF LEN(@date11) > 0
				SET @date11 = substring(@date11,7,4) + '/' + substring(@date11,4,2) + '/' + substring(@date11,1,2) 

			IF LEN(@date12) > 0
				SET @date12 = substring(@date12,7,4) + '/' + substring(@date12,4,2) + '/' + substring(@date12,1,2) 
			
			--date1	"31/01/2016 12:00:00 AM"
			IF LEN(@date1_SD) > 0
				SET @date1_SD = substring(@date1_SD,7,4) + '/' + substring(@date1_SD,4,2) + '/' + substring(@date1_SD,1,2) 
				
			IF LEN(@date2_SD) > 0
				SET @date2_SD = substring(@date2_SD,7,4) + '/' + substring(@date2_SD,4,2) + '/' + substring(@date2_SD,1,2) 

			IF LEN(@date3_SD) > 0
				SET @date3_SD = substring(@date3_SD,7,4) + '/' + substring(@date3_SD,4,2) + '/' + substring(@date3_SD,1,2) 

			IF LEN(@date4_SD) > 0
				SET @date4_SD = substring(@date4_SD,7,4) + '/' + substring(@date4_SD,4,2) + '/' + substring(@date4_SD,1,2) 

			IF LEN(@date5_SD) > 0
				SET @date5_SD = substring(@date5_SD,7,4) + '/' + substring(@date5_SD,4,2) + '/' + substring(@date5_SD,1,2) 

			IF LEN(@date6_SD) > 0
				SET @date6_SD = substring(@date6_SD,7,4) + '/' + substring(@date6_SD,4,2) + '/' + substring(@date6_SD,1,2) 

			IF LEN(@date7_SD) > 0
				SET @date7_SD = substring(@date7_SD,7,4) + '/' + substring(@date7_SD,4,2) + '/' + substring(@date7_SD,1,2) 

			IF LEN(@date8_SD) > 0
				SET @date8_SD = substring(@date8_SD,7,4) + '/' + substring(@date8_SD,4,2) + '/' + substring(@date8_SD,1,2) 

			IF LEN(@date9_SD) > 0
				SET @date9_SD = substring(@date9_SD,7,4) + '/' + substring(@date9_SD,4,2) + '/' + substring(@date9_SD,1,2) 

			IF LEN(@date10_SD) > 0
				SET @date10_SD = substring(@date10_SD,7,4) + '/' + substring(@date10_SD,4,2) + '/' + substring(@date10_SD,1,2) 

			IF LEN(@date11_SD) > 0
				SET @date11_SD = substring(@date11_SD,7,4) + '/' + substring(@date11_SD,4,2) + '/' + substring(@date11_SD,1,2) 

			IF LEN(@date12_SD) > 0
				SET @date12_SD = substring(@date12_SD,7,4) + '/' + substring(@date12_SD,4,2) + '/' + substring(@date12_SD,1,2) 
			
			--[RPT_ID]
			SET @Rpt_Id = (SELECT TOP 1 [RPT_ID] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA_LOADING] ORDER BY CAST([RPT_ID] AS NUMERIC) DESC)
			IF @RPT_ID <> ''
				SET @iRpt_Id = CAST(@Rpt_Id AS NUMERIC)
			ELSE
				SET @iRpt_Id = 0
			SET @iRpt_Id = @iRpt_Id + 1
			SET @Rpt_Id = REPLICATE('0',9-LEN(@iRpt_Id)) + CAST(@iRpt_Id AS VARCHAR)
		
		end
		
		IF @ifOK = '1'
		begin
			IF LEN(@Rpt_Id) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@Rpt_Id',@Rpt_Id,LEN(@Rpt_Id),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@RPT_NAME) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@RPT_NAME',@Rpt_Id,LEN(@RPT_NAME),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@UNIT_code) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@UNIT_code',@Rpt_Id,LEN(@UNIT_code),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@ENTITY_ID) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@ENTITY_ID',@Rpt_Id,LEN(@ENTITY_ID),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@REGULATOR_ID) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@REGULATOR_ID',@Rpt_Id,LEN(@REGULATOR_ID),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@REGULATORY_DEPT) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@REGULATORY_DEPT',@Rpt_Id,LEN(@REGULATORY_DEPT),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@SREF_code) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@SREF_code',@Rpt_Id,LEN(@SREF_code),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@FREQUENCY_code) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@FREQUENCY_code',@Rpt_Id,LEN(@FREQUENCY_code),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
			IF LEN(@SUBMISSION_MODE_ID) = 0
			begin
				INSERT INTO [dbo].[RRF_GUI_LOADING_TRACE_DATA] VALUES ('@SUBMISSION_MODE_ID',@Rpt_Id,LEN(@SUBMISSION_MODE_ID),'LINE_NO ' + CAST(@LINE_NO AS VARCHAR) + ' MISSING OR NIL!')
				SET @ifOK = '0'
			end
		end
		
		IF @ifOK = '1'
		begin
		
			/*
			1.	REMINDER_ID = 'Y' as yes
			2.	REMINDER_DAYS = '5'
			3.	EFF_POSITION_DATE = current date time
			4.	EXP_POSITION_DATE = '9999/12/31'
			5.	STATUS_ID = 'AP' as approved by FGT
			6.	CREATE_DATE  = current date time
			7.	REJECT_REASON = �� <blank>
			8.	PREPARER_ID = �INITIAL�
			9.	PREPARER_DATE = current date time
			10.	APPROVER_ID = �INITIAL�
			11.	APPROVER_DATE = current date time
			12.	APPROVER_FGT_ID = �INITIAL�
			13.	APPROVER_FGT_DATE = current date time
			*/
			
			INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_DATA_LOADING](RPT_ID,RPT_NAME,UNIT_ID,ENTITY_ID,REGULATOR_ID,REGULATOR_DEPT,SREF,REMINDER_ID,REMINDER_DAYS,
				FREQUENCY_ID,T_PLUS_SUBMISSION_DATE,BIZ_DAY_ONLY,SUBMISSION_MODE_ID,EFF_POSITION_DATE,EXP_POSITION_DATE,REPORT_CONSOLIDATER,REPORT_CONTRIBUTOR1,
				REPORT_CONTRIBUTOR2,REPORT_CONTRIBUTOR3,REPORT_CONTRIBUTOR4,REMARKS,STATUS_ID,CREATE_DATE,PREPARER_ID,PREPARER_DATE,APPROVER_ID,APPROVER_DATE,
				APPROVER_FGT_ID,APPROVER_FGT_DATE,REJECT_REASON)
				VALUES (@Rpt_Id,@RPT_NAME,@UNIT_code,@ENTITY_ID,@REGULATOR_ID,@REGULATORY_DEPT,@SREF_code,'Y','5',@FREQUENCY_code,@T_PLUS_SUBMISSION_DATE,
				@BIZ_DAYS_ONLY,@SUBMISSION_MODE_ID,GETDATE(),'9999/12/31',@REPORT_CONSOLIDATER,@REPORT_CONTRIBUTOR1,@REPORT_CONTRIBUTOR2,@REPORT_CONTRIBUTOR3,
				@REPORT_CONTRIBUTOR4,@REMARKS,'AP',GETDATE(),'INITIAL',GETDATE(),'INITIAL',GETDATE(),'INITIAL',GETDATE(),NULL)
		
			SET @Row_Num_Ind = @@IDENTITY
			
			IF @FREQUENCY_code = '9' OR @FREQUENCY_code = '10'
			begin
			
				SET @Rec_No = 1
				
				IF LEN(@date1) > 0 AND LEN(@date1_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date1,@date1_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date2) > 0 AND LEN(@date2_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE)
						SELECT @Row_Num_Ind,@Rec_No,@date2,@date2_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date3) > 0 AND LEN(@date3_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date3,@date3_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date4) > 0 AND LEN(@date4_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date4,@date4_SD
					
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date5) > 0 AND LEN(@date5_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date5,@date5_SD
					
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date6) > 0 AND LEN(@date6_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date6,@date6_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date7) > 0 AND LEN(@date7_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date7,@date7_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date8) > 0 AND LEN(@date8_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date8,@date8_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date9) > 0 AND LEN(@date9_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date9,@date9_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date10) > 0 AND LEN(@date10_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date10,@date10_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date11) > 0 AND LEN(@date11_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date11,@date11_SD
					SET @Rec_No = @Rec_No + 1
				end
				
				IF LEN(@date12) > 0 AND LEN(@date12_SD) > 0
				begin
					INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA_LOADING] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE) 
						SELECT @Row_Num_Ind,@Rec_No,@date12,@date12_SD
					SET @Rec_No = @Rec_No + 1
				end
				
			end
		
		end
		
		FETCH NEXT FROM Cur_Listing INTO @SREF,@ENTITY_ID,@RPT_NAME,@REGULATORY_DEPT,@UNIT_ID,@REPORT_CONSOLIDATER,@REPORT_CONTRIBUTOR1,@REPORT_CONTRIBUTOR2,@REPORT_CONTRIBUTOR3,
		@REPORT_CONTRIBUTOR4,@REMARKS,@REGULATOR_ID,@SUBMISSION_MODE_ID,@FREQUENCY_ID,@T_PLUS_SUBMISSION_DATE,@BIZ_DAYS_ONLY,
		@date1,@date1_SD,@date2,@date2_SD,@date3,@date3_SD,@date4,@date4_SD,@date5,@date5_SD,@date6,@date6_SD,
		@date7,@date7_SD,@date8,@date8_SD,@date9,@date9_SD,@date10,@date10_SD,@date11,@date11_SD,@date12,@date12_SD 
	END 
	CLOSE Cur_Listing 
	DEALLOCATE Cur_Listing	

Commit

GO
