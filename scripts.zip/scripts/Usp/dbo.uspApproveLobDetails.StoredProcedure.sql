SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspApproveLobDetails]

@ACTION_TYPE char(1),
@STATUS_NEXT varchar(1),
@REJECT_REASON VARCHAR(150),
@APPROVER_ID Varchar(30),
@LOB_CODE varchar(3)

AS
BEGIN Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	
	SET @BeforeImage = (SELECT TOP 1 LOB_CODE + ' | ' + LOB_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
			+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
			+ [STATUS] + ' | ' + CHECKER_ID + ' | '
			+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'') + '|' + REJECT_REASON
			FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [LOB_CODE]=@LOB_CODE);
			
	EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_LOB_CODE','',@BeforeImage,'U';
	
	IF @ACTION_TYPE = 'A'
	BEGIN
		UPDATE [dbo].[RRF_GUI_LOB_CODE] SET [STATUS]=@STATUS_NEXT,[CHECKER_ID]=@APPROVER_ID,[CHECKER_UPDT_DT]=GETDATE()
				WHERE LOB_CODE=@LOB_CODE;
	END
	
	IF @ACTION_TYPE = 'R'
	BEGIN
		UPDATE [dbo].[RRF_GUI_LOB_CODE] SET [STATUS]=@STATUS_NEXT,[CHECKER_ID]=@APPROVER_ID,[CHECKER_UPDT_DT]=GETDATE(),[REJECT_REASON] = @REJECT_REASON
				WHERE LOB_CODE=@LOB_CODE;
	END
	
	SET @AfterImage = (SELECT TOP 1 LOB_CODE + ' | ' + LOB_CODE_NM + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
			+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
			+ [STATUS] + ' | ' + CHECKER_ID + ' | '
			+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'') + '|' + REJECT_REASON
			FROM [dbo].[RRF_GUI_LOB_CODE] WHERE [LOB_CODE]=@LOB_CODE);
		
	EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_LOB_CODE','',@AfterImage,'U';		

COMMIT

GO
