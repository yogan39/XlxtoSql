SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGenAllESubmissions]

@NO_OF_SET NUMERIC

AS
Begin Tran

	DECLARE @ROW_NUM NUMERIC
	DECLARE @RPT_ID VARCHAR(9)
	DECLARE @EFF_POSITION_DATE DATE
	DECLARE @EXP_POSITION_DATE DATE
	DECLARE @FREQUENCY_ID VARCHAR(2)

	--to start gen from today onwards
	SET @EFF_POSITION_DATE = CONVERT(DATE, GETDATE())
		
	DECLARE Cur_ESubmission_Data CURSOR FOR SELECT [ROW_NUM],[RPT_ID],[FREQUENCY_ID],[EXP_POSITION_DATE]
		FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE STATUS_ID='AP2' 
		--AND CONVERT(DATE, GETDATE()) BETWEEN [EFF_POSITION_DATE] AND [EXP_POSITION_DATE] 
		AND CONVERT(DATE, GETDATE()) BETWEEN @EFF_POSITION_DATE AND [EXP_POSITION_DATE] 
		ORDER BY [ROW_NUM]
	OPEN Cur_ESubmission_Data 
	FETCH NEXT FROM Cur_ESubmission_Data INTO @ROW_NUM,@RPT_ID,@FREQUENCY_ID,@EXP_POSITION_DATE
	WHILE @@FETCH_STATUS = 0
	BEGIN 
		
		IF @FREQUENCY_ID = '1'	--Daily
			EXEC [dbo].[uspGenESubmissionsDaily] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;

		IF @FREQUENCY_ID = '2'	--Weekly
			EXEC [dbo].[uspGenESubmissionsWeekly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
		
		IF @FREQUENCY_ID = '3'	--Bi-Monthly
			EXEC [dbo].[uspGenESubmissionsBiMonthly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
		
		IF @FREQUENCY_ID = '4'	--Monthly
			EXEC [dbo].[uspGenESubmissionsMonthly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
		
		IF @FREQUENCY_ID = '5'	--Quarterly
			EXEC [dbo].[uspGenESubmissionsQuarterly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
		
		--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
		--IF @FREQUENCY_ID = '6'	--Half Yearly_Calendar Year End
		--	EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
		--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
		IF @FREQUENCY_ID = '6'	--Half Yearly_Calendar Year End
			EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'1';
		
		--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
		IF @FREQUENCY_ID = '11'	--Half Yearly_Financial Year End
			EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'2';
			
		IF @FREQUENCY_ID = '7'	--Yearly_Calendar Year End
			EXEC [dbo].[uspGenESubmissionsYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'1';
			
		IF @FREQUENCY_ID = '8'	--Yearly_Financial Year End
			EXEC [dbo].[uspGenESubmissionsYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'2';
						
		IF @FREQUENCY_ID = '9' OR @FREQUENCY_ID = '10' --6 times yearly + AdHoc
			EXEC [dbo].[uspGenESubmissionsAdHoc] @ROW_NUM,@RPT_ID,@EFF_POSITION_DATE,@EXP_POSITION_DATE;		
		
		FETCH NEXT FROM Cur_ESubmission_Data INTO @ROW_NUM,@RPT_ID,@FREQUENCY_ID,@EXP_POSITION_DATE
	END 
	CLOSE Cur_ESubmission_Data 
	DEALLOCATE Cur_ESubmission_Data	

Commit

RETURN 1
GO
