SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspUpdateUnitDetails]

@UPDATE_TYPE char(1),
@STATUS_ID_PREV varchar(4),
@STATUS_ID_NEXT varchar(4),
@UNIT_CODE As varchar(3),
@UNIT_CODE_NM As varchar(30),
@DEPT_CODE As varchar(3),
@PREPARER_ID Varchar(30)

AS
BEGIN Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
		
	IF @UPDATE_TYPE = 'I'
	BEGIN
		BEGIN			
			INSERT INTO [dbo].[RRF_GUI_UNIT_CODE]
				(UNIT_CODE,UNIT_CODE_NM,DEPT_CODE,LOG_UPDT_USER_ID,LOG_UPDT_DT,[STATUS],CHECKER_ID,CHECKER_UPDT_DT)
				VALUES
				(@UNIT_CODE,@UNIT_CODE_NM,@DEPT_CODE,@PREPARER_ID,GETDATE(),@STATUS_ID_NEXT,'INITIAL',GETDATE())
					
			SET @AfterImage = (SELECT TOP 1 UNIT_CODE + ' | ' + UNIT_CODE_NM + ' | ' + DEPT_CODE + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_UNIT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [UNIT_CODE] =@UNIT_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_UNIT_CODE','',@AfterImage,'I';			
		END
	END
	
	IF @UPDATE_TYPE = 'U'
	BEGIN
		SET @BeforeImage = (SELECT TOP 1 UNIT_CODE + ' | ' + UNIT_CODE_NM + ' | ' + DEPT_CODE + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_UNIT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [UNIT_CODE] =@UNIT_CODE);
			
		EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_UNIT_CODE','',@BeforeImage,'U';	
		
		BEGIN	
			UPDATE [dbo].[RRF_GUI_UNIT_CODE] SET
				[DEPT_CODE]=@DEPT_CODE,[UNIT_CODE_NM]=@UNIT_CODE_NM,[LOG_UPDT_USER_ID]=@PREPARER_ID,[STATUS]='N',LOG_UPDT_DT=GETDATE()
				WHERE DEPT_CODE=@DEPT_CODE AND [UNIT_CODE]=@UNIT_CODE
					
			SET @AfterImage = (SELECT TOP 1 UNIT_CODE + ' | ' + UNIT_CODE_NM + ' | ' + DEPT_CODE + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_UNIT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [UNIT_CODE] =@UNIT_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_UNIT_CODE','',@AfterImage,'U';			
		END
	END
	
	

COMMIT

GO
