SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspUpdateDeptDetails]

@UPDATE_TYPE char(1),
--@STATUS_ID_PREV varchar(4),
--@STATUS_ID_NEXT varchar(4),
@DEPT_CODE As varchar(3),
@DEPT_CODE_NM As varchar(30),
@HOD As varchar(100),
@LOB_CODE As varchar(3),
@PREPARER_ID Varchar(30),
@REJECT_RES Varchar(MAX)

AS
BEGIN Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	DECLARE @Uniq_Dept varchar(3)

		
	IF @UPDATE_TYPE = 'I'
	BEGIN
		IF EXISTS (SELECT * FROM RRF_GUI_DEPT_CODE WHERE DEPT_CODE_NM = @DEPT_CODE_NM )
		BEGIN
		RETURN 10
		END
		ELSE
	   BEGIN			
		SET @Uniq_Dept = (SELECT TOP 1 DEPT_CODE FROM [dbo].[RRF_GUI_DEPT_CODE] ORDER BY CAST(DEPT_CODE AS NUMERIC) DESC)
		SET @Uniq_Dept = @Uniq_Dept + 1
		SET @Uniq_Dept = REPLICATE('0',3-LEN(@Uniq_Dept)) + CAST(@Uniq_Dept AS VARCHAR)

		BEGIN			
			INSERT INTO [dbo].[RRF_GUI_DEPT_CODE]
				(DEPT_CODE,DEPT_CODE_NM,LOB_CODE,HOD,LOG_UPDT_USER_ID,LOG_UPDT_DT,[STATUS],CHECKER_ID,CHECKER_UPDT_DT,REJECT_REASON)
				VALUES
				(@Uniq_Dept,@DEPT_CODE_NM,@LOB_CODE,@HOD,@PREPARER_ID,GETDATE(),'N','INITIAL',GETDATE(),@REJECT_RES)
					
			SET @AfterImage = (SELECT TOP 1 DEPT_CODE + ' | ' + DEPT_CODE_NM + ' | ' + LOB_CODE + ' | ' + HOD + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_DEPT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [LOB_CODE] =@LOB_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_DEPT_CODE','',@AfterImage,'I';			
		END
		END
	END
	
	IF @UPDATE_TYPE = 'U' or @UPDATE_TYPE ='A' or @UPDATE_TYPE ='R'
	BEGIN
		SET @BeforeImage = (SELECT TOP 1 DEPT_CODE + ' | ' + DEPT_CODE_NM + ' | ' + LOB_CODE + ' | ' + HOD + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_DEPT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [LOB_CODE] =@LOB_CODE);
			
		EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_DEPT_CODE','',@BeforeImage,@UPDATE_TYPE;	
		
		BEGIN	
			UPDATE [dbo].[RRF_GUI_DEPT_CODE] SET
				[LOB_CODE]=@LOB_CODE,[DEPT_CODE_NM]=@DEPT_CODE_NM,[LOG_UPDT_USER_ID]=@PREPARER_ID,[STATUS]= @UPDATE_TYPE,LOG_UPDT_DT=GETDATE(),HOD=@HOD,REJECT_REASON=@REJECT_RES
				WHERE DEPT_CODE=@DEPT_CODE AND [LOB_CODE]=@LOB_CODE
					
			SET @AfterImage = (SELECT TOP 1 DEPT_CODE + ' | ' + DEPT_CODE_NM + ' | ' + LOB_CODE + ' | ' + HOD + ' | ' + LOG_UPDT_USER_ID +  ' | ' 
				+ isnull(CAST(LOG_UPDT_DT AS VARCHAR),'') + ' | ' 
				+ [STATUS] + ' | ' + CHECKER_ID + ' | '
				+ isnull(CAST(CHECKER_UPDT_DT AS VARCHAR),'')
				FROM [dbo].[RRF_GUI_DEPT_CODE] WHERE [DEPT_CODE] = @DEPT_CODE AND [LOB_CODE] =@LOB_CODE);
			
			EXEC [dbo].[uspAuditTrail] @PREPARER_ID,'RRF_GUI_DEPT_CODE','',@AfterImage,@UPDATE_TYPE;			
		END
	END
COMMIT

GO
