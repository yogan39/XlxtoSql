SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[uspGetUserPageRolePermission]

@USER_ID Varchar(30),
@USER_LAN_DMN_ID Varchar(50)

AS

Begin
	SELECT a.[PAGE_CODE] AS PageCode,
	CASE  
		WHEN a.page_code IN ('SEC001','SEC002','SEC003','SEC004','MAN001','MAN002','MAN003','MAN004','MAN005','MAN006','MAN007') then
			CASE 
				WHEN b.[USER_ROLE_ID] = 'Admin' OR b.[USER_ROLE_ID] = 'AdminAA' then 'Y' 
				ELSE 'N' 
			end
		WHEN a.page_code IN ('CON001','CON002') then
			CASE 
				WHEN b.[USER_ROLE_ID] IN ('Approver','FGTAppvr','Preparer','Viewer') then 'Y' 
				ELSE 'N' 
			END
		ELSE
			'N'	
	END AS ViewOption, 
	a.[PAGE_FIND] as Url
	FROM [dbo].[RRF_GUI_PAGE_CODES] a, [dbo].[RRF_GUI_USERS] b
	WHERE 
	b.[USER_ID] = @USER_ID  AND b.[USER_DOMAIN_ID] = @USER_LAN_DMN_ID
End

GO
