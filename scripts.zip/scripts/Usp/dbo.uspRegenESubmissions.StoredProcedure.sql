SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspRegenESubmissions]

@ACTION_TYPE char(1),
@ROW_NUM varchar(50),
@RPT_ID varchar(9),
@APPROVER_ID Varchar(30),
@NO_OF_SET NUMERIC,
@EFF_POSITION_DATE varchar(10),
@EXP_POSITION_DATE varchar(10)

AS
Begin Tran

	DECLARE @BeforeImage varchar(max)
	DECLARE @AfterImage varchar(max)
	DECLARE @ROW_NUM_LOOP NUMERIC
	DECLARE @FREQUENCY_ID VARCHAR(2)
	
	IF EXISTS (SELECT [ROW_NUM] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID<>'Z')
	begin
	
		DECLARE Cur_ESubmission_Data CURSOR FOR SELECT [ROW_NUM] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID<>'Z' ORDER BY [ROW_NUM]
		OPEN Cur_ESubmission_Data 
		FETCH NEXT FROM Cur_ESubmission_Data INTO @ROW_NUM_LOOP
		WHILE @@FETCH_STATUS = 0
		BEGIN 
			
			SET @BeforeImage = (SELECT TOP 1 CAST(SUBMISSION_ID AS VARCHAR) + ' | ' + RPT_ID + ' | ' + CAST(POSITION_DATE AS VARCHAR) + ' | ' 
				+ CAST(TARGET_SUBMISSION_DATE AS VARCHAR) + ' | ' + isnull(CAST(APPROVED_EXTENDED_DATE AS VARCHAR),'') + ' | ' + isnull(CAST(RESUBMISSION_NO AS VARCHAR),'') + ' | '
				+ ISNULL(EXTENDED_ATTACHMENT_NAME,'') + ' | ' +
				+ isnull(EXTENDED_REASON,'') + ' | ' + isnull(CAST(ACTUAL_SUBMISSION_DATE AS VARCHAR),'') + ' | '
				+ isnull(COMPLIANCE,'') + ' | ' + isnull(COMPLIANCE_REMARK,'') + ' | ' + isnull(RRF_JUSTIFICATION,'') + ' | ' 
				+ isnull(CATEGORY_ISSUE_ID,'') + ' | ' + isnull(DESCRIPTION_ISSUE,'') + ' | ' + isnull(IMPACT_ISSUE,'') + ' | ' + isnull(CAUSAL,'') + ' | ' 
				+ isnull(ACTION_PLAN,'') + ' | ' + isnull(STATUS_UPDATE,'') + ' | ' + STATUS_ID + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
				+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
				+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'')
				FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE RPT_ID=@RPT_ID AND ROW_NUM=@ROW_NUM_LOOP);
			
			--DELETE FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE RPT_ID=@RPT_ID AND [ROW_NUM]=@ROW_NUM_LOOP;
			UPDATE [dbo].[RRF_GUI_ESUBMISSION_DATA] SET [STATUS_ID]='Z' WHERE RPT_ID=@RPT_ID AND [ROW_NUM]=@ROW_NUM_LOOP;
			
			SET @AfterImage = (SELECT TOP 1 CAST(SUBMISSION_ID AS VARCHAR) + ' | ' + RPT_ID + ' | ' + CAST(POSITION_DATE AS VARCHAR) + ' | ' 
				+ CAST(TARGET_SUBMISSION_DATE AS VARCHAR) + ' | ' + isnull(CAST(APPROVED_EXTENDED_DATE AS VARCHAR),'') + ' | ' + isnull(CAST(RESUBMISSION_NO AS VARCHAR),'') + ' | '
				+ ISNULL(EXTENDED_ATTACHMENT_NAME,'') + ' | ' +
				+ isnull(EXTENDED_REASON,'') + ' | ' + isnull(CAST(ACTUAL_SUBMISSION_DATE AS VARCHAR),'') + ' | '
				+ isnull(COMPLIANCE,'') + ' | ' + isnull(COMPLIANCE_REMARK,'') + ' | ' + isnull(RRF_JUSTIFICATION,'') + ' | ' 
				+ isnull(CATEGORY_ISSUE_ID,'') + ' | ' + isnull(DESCRIPTION_ISSUE,'') + ' | ' + isnull(IMPACT_ISSUE,'') + ' | ' + isnull(CAUSAL,'') + ' | ' 
				+ isnull(ACTION_PLAN,'') + ' | ' + isnull(STATUS_UPDATE,'') + ' | ' + STATUS_ID + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
				+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
				+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'')
				FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE RPT_ID=@RPT_ID AND ROW_NUM=@ROW_NUM_LOOP);
				
			EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ESUBMISSION_DATA',@BeforeImage,@AfterImage,'U'

			FETCH NEXT FROM Cur_ESubmission_Data INTO @ROW_NUM_LOOP
		END 
		CLOSE Cur_ESubmission_Data 
		DEALLOCATE Cur_ESubmission_Data	
	
	end
	
	IF @ACTION_TYPE = '1'	--regen
	begin
	
		SET @FREQUENCY_ID = (SELECT TOP 1 [FREQUENCY_ID] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE [ROW_NUM]=@ROW_NUM AND [RPT_ID]=@RPT_ID 
			AND [STATUS_ID]='AP2' 
			--AND CONVERT(DATE, GETDATE()) BETWEEN [EFF_POSITION_DATE] AND [EXP_POSITION_DATE])
			AND CONVERT(DATE, GETDATE()) BETWEEN @EFF_POSITION_DATE AND [EXP_POSITION_DATE])	--to start gen from today onwards
		
		IF @FREQUENCY_ID IS NOT NULL
		begin
		
			IF @FREQUENCY_ID = '1'	--Daily
				EXEC [dbo].[uspGenESubmissionsDaily] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;

			IF @FREQUENCY_ID = '2'	--Weekly
				EXEC [dbo].[uspGenESubmissionsWeekly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
			IF @FREQUENCY_ID = '3'	--Bi-Monthly
				EXEC [dbo].[uspGenESubmissionsBiMonthly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
			IF @FREQUENCY_ID = '4'	--Monthly
				EXEC [dbo].[uspGenESubmissionsMonthly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
			IF @FREQUENCY_ID = '5'	--Quarterly
				EXEC [dbo].[uspGenESubmissionsQuarterly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
			--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
			--IF @FREQUENCY_ID = '6'	--Half Yearly_Calendar Year End
			--	EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
			--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
			IF @FREQUENCY_ID = '6'	--Half Yearly_Calendar Year End
				EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'1';
			
			--megatshamsul - 20170315 - SR1363674 - new frequency Half Yearly_Financial Year End
			IF @FREQUENCY_ID = '11'	--Half Yearly_Financial Year End
				EXEC [dbo].[uspGenESubmissionsHalfYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'2';
				
			IF @FREQUENCY_ID = '7'	--Yearly_Calendar Year End
				EXEC [dbo].[uspGenESubmissionsYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'1';
				
			IF @FREQUENCY_ID = '8'	--Yearly_Financial Year End
				EXEC [dbo].[uspGenESubmissionsYearly] @ROW_NUM,@RPT_ID,@NO_OF_SET,@EFF_POSITION_DATE,@EXP_POSITION_DATE,'2';
							
			IF @FREQUENCY_ID = '9' OR @FREQUENCY_ID = '10' --6 times yearly + AdHoc
				EXEC [dbo].[uspGenESubmissionsAdHoc] @ROW_NUM,@RPT_ID,@EFF_POSITION_DATE,@EXP_POSITION_DATE;
			
		end
			
	end
	
Commit

RETURN 1
GO
