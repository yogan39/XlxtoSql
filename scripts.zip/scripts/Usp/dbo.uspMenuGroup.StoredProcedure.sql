SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspMenuGroup]

As
Begin
select Page_Menugrp_dsc as MenuGroup, Page_Menugrp as GrpId, Page_Menugrp_Seq as SeqNo from [dbo].[RRF_GUI_PAGE_MENUGRP]
order by Page_MenuGrp_Seq

select page_Menu_Grp as GrpId,Page_dsc As PageDesc,PAGE_FIND As Url,PAGE_CODE as PageCode from [dbo].[RRF_GUI_PAGE_CODES]
order by Page_menu_seq

--select a.page_Menu_Grp as GrpId,
--a.Page_dsc As PageDesc,
--b.page_link As Url,
--a.PAGE_CODE as PageCode from [dbo].[RRF_GUI_PAGE_CODES] a, [dbo].[RRF_GUI_PAGE_CODE_LINKS] b
--where
--b.page_code = b.page_code
--and
--b.page_code = a.page_code
--and
--b.page_link_seq = (select min(b.page_link_seq) from [dbo].[RRF_GUI_PAGE_CODE_LINKS] b)
End

GO
