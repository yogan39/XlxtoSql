SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListUNITListing]

@UNIT_ID varchar(10),
@DEPT_CD varchar (10)

AS	 
	IF (@UNIT_ID = 'All' AND @DEPT_CD = 'All')
	BEGIN
		SELECT [UNIT_CODE],[UNIT_CODE_NM],dept.[DEPT_CODE],dept.[DEPT_CODE_NM],[STATUS]=
		CASE 
			 WHEN unit.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		unit.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_UNIT_CODE] unit
		LEFT JOIN [dbo].[RRF_GUI_DEPT_CODE] dept ON dept.[DEPT_CODE]=unit.[DEPT_CODE]
		ORDER BY unit.[UNIT_CODE]		
	END
	
	ELSE
	IF (@UNIT_ID = 'All' AND @DEPT_CD != 'All')
	BEGIN
		SELECT [UNIT_CODE],[UNIT_CODE_NM],dept.[DEPT_CODE],dept.[DEPT_CODE_NM],[STATUS]=
		CASE 
			 WHEN unit.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		unit.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_UNIT_CODE] unit 
		LEFT JOIN [dbo].[RRF_GUI_DEPT_CODE] dept ON dept.[DEPT_CODE]=unit.[DEPT_CODE]
		WHERE unit.[DEPT_CODE] = @DEPT_CD
		ORDER BY unit.[UNIT_CODE]		
	END
	
	ELSE
	IF (@UNIT_ID != 'All' AND @DEPT_CD = 'All')
	BEGIN
		SELECT [UNIT_CODE],[UNIT_CODE_NM],dept.[DEPT_CODE],dept.[DEPT_CODE_NM],[STATUS]=
		CASE 
			 WHEN unit.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		unit.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_UNIT_CODE] unit 
		LEFT JOIN [dbo].[RRF_GUI_DEPT_CODE] dept ON dept.[DEPT_CODE]=unit.[DEPT_CODE]
		WHERE [UNIT_CODE] = @UNIT_ID
		ORDER BY unit.[UNIT_CODE]		
	END
	
	ELSE	
	BEGIN
		SELECT [UNIT_CODE],[UNIT_CODE_NM],dept.[DEPT_CODE],dept.[DEPT_CODE_NM],[STATUS]=
		CASE 
			 WHEN unit.[STATUS] =  'N' THEN 'Pending Approval'
			 ELSE 'Approved'
		END,
		unit.[REJECT_REASON]
		FROM [dbo].[RRF_GUI_UNIT_CODE] unit 
		LEFT JOIN [dbo].[RRF_GUI_DEPT_CODE] dept ON dept.[DEPT_CODE]=unit.[DEPT_CODE]
		WHERE [UNIT_CODE] = @UNIT_ID AND unit.[DEPT_CODE] = @DEPT_CD
		ORDER BY unit.[UNIT_CODE]		
	END
	
	
	
GO
