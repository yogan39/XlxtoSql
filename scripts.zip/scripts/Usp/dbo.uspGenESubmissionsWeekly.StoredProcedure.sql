SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGenESubmissionsWeekly]

@ROW_NUM varchar(50),
@RPT_ID varchar(9),
@NO_OF_SET NUMERIC,
@EFF_POSITION_DATE varchar(10),
@EXP_POSITION_DATE varchar(10)

AS
Begin Tran

	--megatshamsul - 20170315 - SR1363674 - updated frequency Weekly
	
	DECLARE @AfterImage varchar(max)
	DECLARE @dEFF_POSITION_DATE DATE
	DECLARE @dGUI_EFF_POSITION_DATE DATE
	DECLARE @dEXP_POSITION_DATE DATE
	DECLARE @BIZ_DAY_ONLY CHAR(1)
	DECLARE @dSUBMISSION_DATE DATE
	DECLARE @WEEK_NO NUMERIC
	DECLARE @WEEKLY_POSITION_DATE VARCHAR(4)
	DECLARE @TPLUS_WEEKLY_SUBMISSION_DATE NUMERIC
	DECLARE @SUBMISSION_ID NUMERIC
	DECLARE @Row_Num_Ind NUMERIC
	DECLARE @idaysAdded numeric
	DECLARE @idaysToAdd numeric
	DECLARE @PositionDateType VARCHAR(4)
	DECLARE @iPositionDate NUMERIC
	DECLARE @isDate VARCHAR(10)
	DECLARE @X NUMERIC
	DECLARE @isDateOK CHAR(1)
	
	SET @dEFF_POSITION_DATE = @EFF_POSITION_DATE
	SET @dEXP_POSITION_DATE = @EXP_POSITION_DATE
	SET @BIZ_DAY_ONLY = (SELECT TOP 1 [BIZ_DAY_ONLY] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='2')
	SET @dGUI_EFF_POSITION_DATE = (SELECT TOP 1 [EFF_POSITION_DATE] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE ROW_NUM=@ROW_NUM AND RPT_ID=@RPT_ID AND STATUS_ID='AP2' AND FREQUENCY_ID='2')
	
	IF @BIZ_DAY_ONLY IS NOT NULL
	begin

		SET @X = 1
		SET @isDateOK = '0'

		WHILE @X <= @NO_OF_SET	--loop within no of set
		begin
		
			DECLARE Cur_ESubmission_Data_Weekly CURSOR FOR SELECT a.[WEEK_NO],a.[WEEKLY_POSITION_DATE],a.[TPLUS_WEEKLY_SUBMISSION_DATE] 
				FROM [dbo].[RRF_GUI_ETEMPLATE_WEEKLY_DATA] a
				INNER JOIN [dbo].[RRF_GUI_ETEMPLATE_DATA] b ON a.[ROW_NUM_SRC]=b.[ROW_NUM]
				WHERE b.[RPT_ID]=@RPT_ID AND b.[ROW_NUM]=@ROW_NUM AND b.[FREQUENCY_ID]='2' AND b.[STATUS_ID]='AP2'
				AND CONVERT(DATE, GETDATE()) BETWEEN @EFF_POSITION_DATE AND b.[EXP_POSITION_DATE]
				AND @X <= @NO_OF_SET
				ORDER BY a.[WEEK_NO]
			OPEN Cur_ESubmission_Data_Weekly 
			FETCH NEXT FROM Cur_ESubmission_Data_Weekly INTO @WEEK_NO,@WEEKLY_POSITION_DATE,@TPLUS_WEEKLY_SUBMISSION_DATE
			WHILE @@FETCH_STATUS = 0
			BEGIN
				
				IF @X <= @NO_OF_SET	--loop within no of set
				begin
					
					IF @dEFF_POSITION_DATE < @dEXP_POSITION_DATE 
					begin
						
						IF @WEEKLY_POSITION_DATE = 'EOM'
						begin
							SET @dEFF_POSITION_DATE = DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,@dEFF_POSITION_DATE)+1,0))
							SET @isDateOK = '1'
						end
						ELSE
						begin
							SET @PositionDateType = (SELECT dbo.udf_GetNumeric(@WEEKLY_POSITION_DATE))
							SET @iPositionDate = CAST(@PositionDateType AS NUMERIC)
							SET @isDate = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/' + CAST(MONTH(@dEFF_POSITION_DATE) AS VARCHAR) + '/' + @PositionDateType
								
							IF ISDATE(@isDate) = 1
							begin
								SET @dEFF_POSITION_DATE = @isDate
								SET @isDateOK = '1'
							end	
							ELSE
								SET @isDateOK = '0'

						end
						
						IF @isDateOK = '1'
						begin
						
							--print @dEFF_POSITION_DATE
						
							IF @BIZ_DAY_ONLY = 'N'	--regardless of day types
								SET @dSUBMISSION_DATE = DATEADD(day,@TPLUS_WEEKLY_SUBMISSION_DATE,@dEFF_POSITION_DATE)
							ELSE
							begin
							
								--KL's weekend + KL's public holiday
								
								SET @dSUBMISSION_DATE = @dEFF_POSITION_DATE
								SET @idaysToAdd = @TPLUS_WEEKLY_SUBMISSION_DATE
								SET @idaysAdded = 1
								
								WHILE @idaysAdded <= @idaysToAdd
								begin
								
									SET @dSUBMISSION_DATE = DATEADD(day,1,@dSUBMISSION_DATE)
								
									IF UPPER(DATENAME(dw,@dSUBMISSION_DATE))='SATURDAY' OR  UPPER(DATENAME(dw,@dSUBMISSION_DATE))='SUNDAY'
										SET @idaysAdded = @idaysAdded
									ELSE
									begin
									
										IF EXISTS (SELECT [HOLIDAY_DATE] FROM [dbo].[RRF_GUI_PUBLIC_HOLIDAYS] WHERE [STATE_ID]='03' AND [HOLIDAY_DATE]=@dSUBMISSION_DATE)
											SET @idaysAdded = @idaysAdded
										ELSE
											SET @idaysAdded = @idaysAdded + 1
											
									end
									
								end
								
							end
							
							IF NOT EXISTS (SELECT [ROW_NUM] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE [RPT_ID]=@RPT_ID AND POSITION_DATE=@dEFF_POSITION_DATE AND TARGET_SUBMISSION_DATE=@dSUBMISSION_DATE AND STATUS_ID NOT IN ('Z'))
							begin
							
								IF @dEFF_POSITION_DATE >= @dGUI_EFF_POSITION_DATE AND @dEFF_POSITION_DATE < @dEXP_POSITION_DATE 
								begin
								
									SET @SUBMISSION_ID = (SELECT TOP 1 [SUBMISSION_ID] FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] ORDER BY [SUBMISSION_ID] DESC)
									
									IF LEN(@SUBMISSION_ID) = 0 OR @SUBMISSION_ID IS NULL
										SET @SUBMISSION_ID = 1
									ELSE
										SET @SUBMISSION_ID = @SUBMISSION_ID + 1
								
									INSERT INTO [dbo].[RRF_GUI_ESUBMISSION_DATA] ([SUBMISSION_ID],[RPT_ID],[POSITION_DATE],[TARGET_SUBMISSION_DATE],[STATUS_ID],[CREATE_DATE],
										[PREPARER_ID],[PREPARER_DATE])
										SELECT @SUBMISSION_ID,@RPT_ID,@dEFF_POSITION_DATE,@dSUBMISSION_DATE,'D1',GETDATE(),'SYSTEM',GETDATE();
								
									SET @Row_Num_Ind = @@IDENTITY
									
									SET @AfterImage = (SELECT TOP 1 CAST(SUBMISSION_ID AS VARCHAR) + ' | ' + RPT_ID + ' | ' + CAST(POSITION_DATE AS VARCHAR) + ' | ' 
										+ CAST(TARGET_SUBMISSION_DATE AS VARCHAR) + ' | ' + isnull(CAST(APPROVED_EXTENDED_DATE AS VARCHAR),'') + ' | ' + isnull(CAST(RESUBMISSION_NO AS VARCHAR),'') + ' | '
										+ ISNULL(EXTENDED_ATTACHMENT_NAME,'') + ' | ' +
										+ isnull(EXTENDED_REASON,'') + ' | ' + isnull(CAST(ACTUAL_SUBMISSION_DATE AS VARCHAR),'') + ' | '
										+ isnull(COMPLIANCE,'') + ' | ' + isnull(COMPLIANCE_REMARK,'') + ' | ' + isnull(RRF_JUSTIFICATION,'') + ' | ' 
										+ isnull(CATEGORY_ISSUE_ID,'') + ' | ' + isnull(DESCRIPTION_ISSUE,'') + ' | ' + isnull(IMPACT_ISSUE,'') + ' | ' + isnull(CAUSAL,'') + ' | ' 
										+ isnull(ACTION_PLAN,'') + ' | ' + isnull(STATUS_UPDATE,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
										+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
										+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'')
										FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] WHERE ROW_NUM=@Row_Num_Ind);
									
									EXEC [dbo].[uspAuditTrail] 'SYSTEM','RRF_GUI_ESUBMISSION_DATA','',@AfterImage,'I';
									
									SET @X = @X + 1
									
								end
						
							end
						
						end
						
						IF @WEEK_NO = 4
						begin
							SET @dEFF_POSITION_DATE = DATEADD(month, 1, @dEFF_POSITION_DATE)	--add another month
							SET @dEFF_POSITION_DATE = CAST(YEAR(@dEFF_POSITION_DATE) AS VARCHAR) + '/' + CAST(MONTH(@dEFF_POSITION_DATE) AS VARCHAR) + '/01'	--start as day first of the another month
						end
							
					end
					ELSE
						SET @X = @X + 1
				
				end
				
				FETCH NEXT FROM Cur_ESubmission_Data_Weekly INTO @WEEK_NO,@WEEKLY_POSITION_DATE,@TPLUS_WEEKLY_SUBMISSION_DATE
			END 
			CLOSE Cur_ESubmission_Data_Weekly 
			DEALLOCATE Cur_ESubmission_Data_Weekly
		
			
		
		end
	
	end

Commit

RETURN 1

GO
