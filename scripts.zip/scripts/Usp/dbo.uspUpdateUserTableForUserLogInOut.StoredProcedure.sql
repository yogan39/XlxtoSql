SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[uspUpdateUserTableForUserLogInOut]

@USER_ID	varchar(30),
@USER_LAN_DMN_ID	varchar(50),
@TS_LAST_DATE	datetime,
@IS_CURRLY_LOGGED_IN	char(1),
@LAST_LGIN_IP_ADR	varchar(16)

As

Begin tran

	IF @IS_CURRLY_LOGGED_IN = 'Y'
	begin
		Update dbo.RRF_GUI_USERS 
			set 
			TS_LAST_LGIN=@TS_LAST_DATE,
			IS_CURRLY_LOGGED_IN=@IS_CURRLY_LOGGED_IN,
			LAST_LGIN_IP_ADR=@LAST_LGIN_IP_ADR
			WHERE
			[USER_ID] = @USER_ID and [USER_DOMAIN_ID]=@USER_LAN_DMN_ID
	end
	ELSE
	begin
		Update dbo.RRF_GUI_USERS  
			set 
			TS_LAST_LGOT=@TS_LAST_DATE,
			IS_CURRLY_LOGGED_IN=@IS_CURRLY_LOGGED_IN
			WHERE
			[USER_ID] = @USER_ID and [USER_DOMAIN_ID]=@USER_LAN_DMN_ID
	end
	
Commit

GO
