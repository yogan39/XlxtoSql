SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListETemplatesAll]

@UNIT_ID varchar(3),
@RPT_ID varchar(9),
@RPT_NAME varchar(255),
@REGULATOR_ID varchar(3),
@SREF char(1),
@FREQUENCY_ID varchar(3),
@STATUS_ALL char(1),
@STATUS_DRAFT char(1),
@STATUS_NEW char(1),
@STATUS_APP char(1),
@STATUS_REJ char(1),
@STATUS_PA char(1),
@FROM_DATE varchar(10),
@TO_DATE varchar(10),
@IF_REJECT char(1),
@ROLE_ID varchar(10)

AS

	declare @strSQL varchar(3000)
	declare @strSQLCondition varchar(1000)
	declare @strSQLCondition_Status varchar(1000)
	declare @strSQLCondition_DateRange varchar(1000)
	declare @strSQLOrderBy varchar(1000)
	declare @strFromDate varchar(50)
	declare @strToDate varchar(50)
	
	set @strSQLOrderBy = ' ORDER BY a.[CREATE_DATE]'

	set @strSQL = 'SELECT a.[RPT_ID] AS [RPT ID],a.[RPT_NAME] AS [RPT NAME],b.[UNIT_CODE_NM] AS [UNIT],'
	set @strSQL = @strSQL + 'f.[DEPT_CODE_NM] AS [DEPT],g.[LOB_CODE_NM] AS [LOB],f.[HOD],'
	set @strSQL = @strSQL + 'a.[ENTITY_ID] AS [ENTITY],c.[REGULATOR_DESC] AS [REGULATOR],a.[REGULATOR_DEPT] AS [DEPT WITHIN REGULATOR],'
	set @strSQL = @strSQL + 'CASE a.[SREF] WHEN ''1'' THEN ''Yes(Monetary Penalty)'' WHEN ''2'' THEN ''Yes(Non-Monetary Penalty)'' WHEN ''N'' THEN ''No'' ELSE a.[SREF] END AS [SREF],'
	set @strSQL = @strSQL + 'CASE a.[REMINDER_ID] WHEN ''Y'' THEN ''Yes'' WHEN ''N'' THEN ''No'' ELSE a.[REMINDER_ID] END AS [SEND REMINDER],'
	set @strSQL = @strSQL + 'a.[REMINDER_DAYS] AS [REMINDER IN DAYS],d.[FREQUENCY_DESC] AS [SUBMISSION FREQUENCY],a.[T_PLUS_SUBMISSION_DATE] AS [TPLUS SUBMISSION IN DAYS],'
	set @strSQL = @strSQL + 'CASE a.[BIZ_DAY_ONLY] WHEN ''Y'' THEN ''Yes'' WHEN ''N'' THEN ''No'' ELSE a.[BIZ_DAY_ONLY] END AS [SUBMIT ON BIZ DAY ONLY],'
	set @strSQL = @strSQL + 'i.[SUBMISSION_MODE_DESC] AS [SUBMISSION MODE],'
	set @strSQL = @strSQL + 'CASE WHEN a.[EFF_POSITION_DATE] IS NULL THEN NULL ELSE CONVERT(VARCHAR,a.[EFF_POSITION_DATE],103) END AS [EFFECTIVE START POSITION DATE],'
	set @strSQL = @strSQL + 'CASE WHEN a.[EXP_POSITION_DATE] IS NULL THEN NULL ELSE CONVERT(VARCHAR,a.[EXP_POSITION_DATE],103) END AS [EFFECTIVE END POSITION DATE],'
	set @strSQL = @strSQL + 'a.[REPORT_CONSOLIDATER] AS [REPORT CONSOLIDATER],a.[REPORT_CONTRIBUTOR1] AS [REPORT CONTRIBUTOR1],a.[REPORT_CONTRIBUTOR2] AS [REPORT CONTRIBUTOR2],'
	set @strSQL = @strSQL + 'a.[REPORT_CONTRIBUTOR3] AS [REPORT CONTRIBUTOR3],a.[REPORT_CONTRIBUTOR4] AS [REPORT CONTRIBUTOR4],'
	set @strSQL = @strSQL + 'a.[REMARKS],e.[STATUS_DESC] AS [STATUS],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[CREATE_DATE],103) + '' '' + CONVERT(VARCHAR,a.[CREATE_DATE],114) AS [CREATION DATE],'
	set @strSQL = @strSQL + 'a.PREPARER_ID AS [PREPARER ID],CONVERT(VARCHAR,a.[PREPARER_DATE],103) + '' '' + CONVERT(VARCHAR,a.[PREPARER_DATE],114) AS [DATE PREPARED],'
	set @strSQL = @strSQL + 'a.APPROVER_ID AS [APPROVER ID],CASE WHEN a.[APPROVER_DATE] IS NULL THEN NULL ELSE CONVERT(VARCHAR,a.[APPROVER_DATE],103) + '' '' + CONVERT(VARCHAR,a.[APPROVER_DATE],114) END AS [APPROVED DATE],'
	set @strSQL = @strSQL + 'a.APPROVER_FGT_ID AS [FG ID],CASE WHEN a.[APPROVER_FGT_DATE] IS NULL THEN NULL ELSE CONVERT(VARCHAR,a.[APPROVER_FGT_DATE],103) + '' '' + CONVERT(VARCHAR,a.[APPROVER_FGT_DATE],114) END AS [APPROVED DATE BY FG],'
	set @strSQL = @strSQL + 'a.[REJECT_REASON] AS [REJECT REASON] '
	
	--megatshamsul - 20170314 - SR1363674 - update frequency monthly
	set @strSQL = @strSQL + ',a.[POSITION_DATE] '
	
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] a '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_UNIT_CODE] b on a.[UNIT_ID]=b.[UNIT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_REGULATOR_CODE] c on a.[REGULATOR_ID]=c.[REGULATOR_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_FREQUENCY_CODE] d on a.[FREQUENCY_ID]=d.[FREQUENCY_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_STATUS_CODE] e on a.[STATUS_ID]=e.[STATUS_ID] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_DEPT_CODE] f on b.[DEPT_CODE]=f.[DEPT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_LOB_CODE] g on f.[LOB_CODE]=g.[LOB_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_SUBMISSION_MODE_CODE] i on a.[SUBMISSION_MODE_ID]=i.[SUBMISSION_MODE_ID] '
	
	if @ROLE_ID <> 'FGTAppvr'	--FGTAppvr has access to all reports
		set @strSQLCondition = ' WHERE a.[UNIT_ID]=''' + @UNIT_ID + ''''
	else
		set @strSQLCondition = ''
	
	IF @RPT_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[RPT_ID]=''' + @RPT_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE a.[RPT_ID]=''' + @RPT_ID + ''''
	end
	
	IF @RPT_NAME <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[RPT_NAME] LIKE ''%' + @RPT_NAME + '%'''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE a.[RPT_NAME] LIKE ''%' + @RPT_NAME + '%'''
	end

	IF @REGULATOR_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[REGULATOR_ID]=''' + @REGULATOR_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE a.[REGULATOR_ID]=''' + @REGULATOR_ID + ''''
	end
	
	IF @SREF <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[SREF]=''' + @SREF + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' WHERE a.[SREF]=''' + @SREF + ''''
	end
	
	IF @FREQUENCY_ID <> ''
	begin
		if @strSQLCondition <> ''
			set @strSQLCondition = @strSQLCondition + ' AND a.[FREQUENCY_ID]=''' + @FREQUENCY_ID + ''''
		else
			set @strSQLCondition = @strSQLCondition + ' AND a.[FREQUENCY_ID]=''' + @FREQUENCY_ID + ''''
	end
	
	IF @STATUS_ALL = '0'
	begin
	
		set @strSQLCondition_Status = ''
		
		if @STATUS_DRAFT = '1'
			set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''D1'',''D2'',''D3'')'
		
		if @STATUS_NEW = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'')'
		end
		
		if @STATUS_APP = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''AP1'',''AP2'',''APX1'',''X'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''AP1'',''AP2'',''APX1'',''X'')'
		end
		
		if @STATUS_REJ = '1'
		begin
			if @strSQLCondition_Status <> ''
				set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''RJ1'',''RJ2'',''RJX1'',''RJX2'')'
			else
				set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''RJ1'',''RJ2'',''RJX1'',''RJX2'')'
		end
		
		if @STATUS_PA = '1'
		begin
			if @ROLE_ID = 'Approver'
			begin
				if @strSQLCondition_Status <> ''
					set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'')'
				else
					set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'')'
			end
			else
			begin
				if @ROLE_ID = 'FGTAppvr'
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''AP1'',''APX1'')'
					else
						set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''AP1'',''APX1'')'
				end
				else
				begin
					if @strSQLCondition_Status <> ''
						set @strSQLCondition_Status = @strSQLCondition_Status + ' OR a.[STATUS_ID] IN (''N'',''U'',''XR'',''AP1'',''APX1'')'
					else
						set @strSQLCondition_Status = 'a.[STATUS_ID] IN (''N'',''U'',''XR'',''AP1'',''APX1'')'
				end
			end
		end
		
		if @strSQLCondition_Status <> ''
			set @strSQLCondition = @strSQLCondition + ' AND (' + @strSQLCondition_Status + ')'
		
	end
	
IF @FROM_DATE <> '' AND @TO_DATE <> ''
	begin

		set @strFromDate = substring(@FROM_DATE,7,4) + '/' + substring(@FROM_DATE,4,2) + '/' + substring(@FROM_DATE,1,2) + ' 00:00:00'
		set @strToDate = substring(@TO_DATE,7,4) + '/' + substring(@TO_DATE,4,2) + '/' + substring(@TO_DATE,1,2) + ' 23:59:59'
		set @strSQLCondition_DateRange = ''
		
		IF @STATUS_ALL = '1'
		begin
			set @strSQLCondition_DateRange = '(a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
		end
		ELSE
		begin
		
			if @STATUS_DRAFT = '1' OR @STATUS_NEW = '1'
			begin
				if @strSQLCondition_DateRange <> ''
					set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				else
					set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			end
			
			if @STATUS_APP = '1' OR @STATUS_REJ = '1'
			begin
				if @strSQLCondition_DateRange <> ''
					set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_FGT_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				else
					set @strSQLCondition_DateRange = '(a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_FGT_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
			end
			
			if @STATUS_PA = '1'
			begin
				if @ROLE_ID = 'Approver'
				begin
					if @strSQLCondition_DateRange <> ''
						set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					else
						set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
				end
				else
				begin
					if @ROLE_ID = 'FGTAppvr'
					begin
					if @strSQLCondition_DateRange <> ''
						set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					else
						set @strSQLCondition_DateRange = '(a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					end
					else
					begin
						if @strSQLCondition_DateRange <> ''
							set @strSQLCondition_DateRange = @strSQLCondition_DateRange + ' OR (a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
						else
							set @strSQLCondition_DateRange = '(a.[PREPARER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''' OR a.[APPROVER_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'
					end
				end
			end		
		
		end
	
		if @strSQLCondition_DateRange = ''
			set @strSQLCondition_DateRange = '(a.[CREATE_DATE] BETWEEN ''' + @strFromDate + ''' AND ''' + @strToDate + ''')'

		set @strSQLCondition = @strSQLCondition + ' AND (' + @strSQLCondition_DateRange + ')'
		
	end

	set @strSQL = @strSQL + @strSQLCondition + @strSQLOrderBy
	
	EXECUTE(@strSQL)

GO
