SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListAlertPendingActionItems]

@Module_Id char(1)

AS

	IF @Module_Id = '1'
	begin
		SELECT 'ETemplate' AS [MODULE_ID],[ROW_NUM],[RPT_ID],NULL AS [SUBMISSION_ID],[STATUS_ID],[UNIT_ID],[RPT_NAME] 
			FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] 
			WHERE [STATUS_ID] NOT IN ('AP2','X','Z','O')
			ORDER BY [MODULE_ID],[ROW_NUM]
	end
		
	IF @Module_Id = '2'
	begin
		SELECT 'ESubmission' AS [MODULE_ID],a.[ROW_NUM],a.[RPT_ID],a.[SUBMISSION_ID],a.[STATUS_ID],b.[UNIT_ID],b.[RPT_NAME]  
			FROM [dbo].[RRF_GUI_ESUBMISSION_DATA] a INNER JOIN [dbo].[RRF_GUI_ETEMPLATE_DATA] b on a.[RPT_ID]=b.[RPT_ID]
			WHERE a.[STATUS_ID] NOT IN ('AP2','X','Z','O') AND b.[STATUS_ID]='AP2'
			--megatshamsul - 20170405 - SR1363674 - check against target submission date instead
			--AND a.[POSITION_DATE]<=GETDATE()
			AND a.[TARGET_SUBMISSION_DATE]<=GETDATE()
			ORDER BY [MODULE_ID],[ROW_NUM]
	end

GO
