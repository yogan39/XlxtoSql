SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGetDeptCode]

--@UNIT_ID varchar(3),
@LOB_CODE varchar(10),
--@ROLE_ID varchar(10),
@DEPT_CODE varchar(10)

AS
	BEGIN
		SELECT lob.[LOB_CODE],lob.[LOB_CODE_NM],[DEPT_CODE],dept.[DEPT_CODE_NM],dept.[HOD],dept.[STATUS],dept.[REJECT_REASON],dept.[CHECKER_ID],dept.[LOG_UPDT_USER_ID]
		FROM [dbo].[RRF_GUI_DEPT_CODE] dept 
		LEFT JOIN [dbo].[RRF_GUI_LOB_CODE] lob ON lob.[LOB_CODE]=dept.[LOB_CODE]
		WHERE dept.[LOB_CODE] = @LOB_CODE AND dept.[DEPT_CODE] = @DEPT_CODE
	END


GO
