SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspGetUnitCode]

@UNIT_ID varchar(3),
@DEPT_CODE varchar(10)

AS
	BEGIN
		SELECT unit.[UNIT_CODE],unit.[UNIT_CODE_NM],unit.[DEPT_CODE],dept.[DEPT_CODE_NM],unit.[STATUS],unit.[REJECT_REASON],unit.[CHECKER_ID],unit.[LOG_UPDT_USER_ID]
		FROM [dbo].[RRF_GUI_UNIT_CODE] unit 
		LEFT JOIN [dbo].[RRF_GUI_DEPT_CODE] dept ON dept.[DEPT_CODE]=unit.[DEPT_CODE]
		WHERE unit.[UNIT_CODE] = @UNIT_ID AND unit.[DEPT_CODE] = @DEPT_CODE
	END


GO
