SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListENTITYListing]

@UNIT_ID varchar(10),
@ENTITY_CD varchar(10),
@ROLE_ID varchar (10)

AS	 
	IF (@ENTITY_CD = 'All')
	BEGIN
		SELECT [ENTITY_CODE],[ENTITY_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  'N' THEN 'Pending Approval'
			 WHEN [STATUS] =  'R' THEN 'Rejected'
			 ELSE 'Approved'
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_ENTITY_CODE]
		ORDER BY [ENTITY_CODE]
	END
	ELSE
	BEGIN
		SELECT [ENTITY_CODE],[ENTITY_CODE_NM],[CHECKER_ID],[STATUS]=
		CASE 
			 WHEN [STATUS] =  'N' THEN 'Pending Approval'
			 WHEN [STATUS] =  'R' THEN 'Rejected'
			 ELSE 'Approved'
		END,
		[REJECT_REASON]
		FROM [dbo].[RRF_GUI_ENTITY_CODE]
		WHERE ENTITY_CODE = @ENTITY_CD
		ORDER BY [ENTITY_CODE]
	END
	
	
GO
