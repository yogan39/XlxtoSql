SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspApplicationLevelSecurityCheck]

@USER_ID varchar(30),
@USER_LAN_DMN_ID varchar(50)

AS

SELECT	a.[USER_ID] as UserId, a.IS_CURRLY_LOGGED_IN as IsCurrentlyLoggedIn , a.[STATUS_ID] as UserStatus
FROM [dbo].[RRF_GUI_USERS] a
WHERE (a.[USER_ID] = @USER_ID) AND (a.[USER_DOMAIN_ID] = @USER_LAN_DMN_ID)

GO
