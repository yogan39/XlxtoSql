SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspApproveETemplateDetails]

@ACTION_TYPE char(1),
@RPT_ID varchar(9),
@STATUS_ID varchar(4),
@ROW_NUM NUMERIC,
@REJECT_REASON VARCHAR(150),
@APPROVER_ID Varchar(30),
@ROLE_ID varchar(10)

AS
Begin Tran

	DECLARE @BeforeImage varchar(8000)
	DECLARE @AfterImage varchar(8000)
	DECLARE @STATUS_ID_NEXT varchar(4)
	DECLARE @STATUS_ID_OTHERS varchar(4)
	DECLARE @ROW_NUM_LOOP NUMERIC
	DECLARE @Row_Num_Ind NUMERIC
	DECLARE @FREQUENCY_ID VARCHAR(2)
	
	IF @ACTION_TYPE = 'A'
	begin
	
		IF @STATUS_ID = 'N' OR @STATUS_ID = 'U'
			SET @STATUS_ID_NEXT = 'AP1'
		
		IF @STATUS_ID = 'XR'
			SET @STATUS_ID_NEXT = 'APX1'
			
		IF @STATUS_ID = 'AP1'
			SET @STATUS_ID_NEXT = 'AP2'
		
		IF @STATUS_ID = 'APX1'
			SET @STATUS_ID_NEXT = 'X'
	
	end
	
	IF @ACTION_TYPE = 'R'
	begin
	
		IF @STATUS_ID = 'N' OR @STATUS_ID = 'U'
			SET @STATUS_ID_NEXT = 'RJ1'
		
		IF @STATUS_ID = 'XR'
			SET @STATUS_ID_NEXT = 'RJX1'
			
		IF @STATUS_ID = 'AP1' OR @STATUS_ID = 'AP2'
			SET @STATUS_ID_NEXT = 'RJ2'
		
		IF @STATUS_ID = 'APX1'
			SET @STATUS_ID_NEXT = 'RJX2'
	
	end
	
	IF @STATUS_ID = 'AP2' AND @STATUS_ID_NEXT = 'RJ2'	--FGT can reject an approved rec, then create new record
	begin
	
		--megatshamsul - 20170314 - SR1363674 - update frequency monthly
		INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_DATA]
			(RPT_ID,RPT_NAME,UNIT_ID,ENTITY_ID,REGULATOR_ID,REGULATOR_DEPT,SREF,REMINDER_ID,REMINDER_DAYS,FREQUENCY_ID,T_PLUS_SUBMISSION_DATE,BIZ_DAY_ONLY,
			SUBMISSION_MODE_ID,EFF_POSITION_DATE,EXP_POSITION_DATE,REPORT_CONSOLIDATER,REPORT_CONTRIBUTOR1,REPORT_CONTRIBUTOR2,REPORT_CONTRIBUTOR3,
			REPORT_CONTRIBUTOR4,REMARKS,STATUS_ID,CREATE_DATE,PREPARER_ID,PREPARER_DATE,APPROVER_ID,APPROVER_DATE,APPROVER_FGT_ID,APPROVER_FGT_DATE,
			REJECT_REASON,POSITION_DATE)
		SELECT @RPT_ID,RPT_NAME,UNIT_ID,ENTITY_ID,REGULATOR_ID,REGULATOR_DEPT,SREF,REMINDER_ID,REMINDER_DAYS,FREQUENCY_ID,T_PLUS_SUBMISSION_DATE,
			BIZ_DAY_ONLY,SUBMISSION_MODE_ID,EFF_POSITION_DATE,EXP_POSITION_DATE,REPORT_CONSOLIDATER,REPORT_CONTRIBUTOR1,REPORT_CONTRIBUTOR2,
			REPORT_CONTRIBUTOR3,REPORT_CONTRIBUTOR4,REMARKS,@STATUS_ID_NEXT,CREATE_DATE,PREPARER_ID,PREPARER_DATE,APPROVER_ID,APPROVER_DATE,
			@APPROVER_ID,GETDATE(),@REJECT_REASON,POSITION_DATE 
			FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE [RPT_ID]=@RPT_ID AND [ROW_NUM]=@ROW_NUM;
		
		SET @Row_Num_Ind = @@IDENTITY
		SET @FREQUENCY_ID = (SELECT FREQUENCY_ID FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE [ROW_NUM]=@Row_Num_Ind)
		
		IF @FREQUENCY_ID = '9' OR @FREQUENCY_ID = '10'
		begin

			INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA] (ROW_NUM_SRC,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE)
				SELECT @Row_Num_Ind,REC_NO,POSITION_DATE,TARGET_SUBMISSION_DATE FROM [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA] 
				WHERE [ROW_NUM_SRC]=@ROW_NUM;
		end
		
		--megatshamsul - 20170314 - SR1363674 - update frequency weekly
		IF @FREQUENCY_ID = '2'
		begin

			INSERT INTO [dbo].[RRF_GUI_ETEMPLATE_WEEKLY_DATA] (ROW_NUM_SRC,WEEK_NO,WEEKLY_POSITION_DATE,TPLUS_WEEKLY_SUBMISSION_DATE)
				SELECT @Row_Num_Ind,WEEK_NO,WEEKLY_POSITION_DATE,TPLUS_WEEKLY_SUBMISSION_DATE FROM [dbo].[RRF_GUI_ETEMPLATE_WEEKLY_DATA]
				WHERE [ROW_NUM_SRC]=@ROW_NUM;
				
		end
		
		--megatshamsul - 20170314 - SR1363674 - update frequency monthly
		SET @AfterImage = (SELECT TOP 1 RPT_ID + ' | ' + RPT_NAME + ' | ' + UNIT_ID + ' | ' + ENTITY_ID + ' | ' + REGULATOR_ID + ' | ' + REGULATOR_DEPT +  ' | ' 
			+ SREF + ' | ' + REMINDER_ID + ' | ' + isnull(CAST(REMINDER_DAYS AS VARCHAR),'') + ' | ' 
			+ FREQUENCY_ID + ' | ' + isnull(CAST(T_PLUS_SUBMISSION_DATE AS VARCHAR),'') + ' | '
			+ isnull(BIZ_DAY_ONLY,'') + ' | ' + SUBMISSION_MODE_ID + ' | ' + isnull(CAST(EFF_POSITION_DATE AS VARCHAR),'') + ' | '
			+ isnull(CAST(EXP_POSITION_DATE AS VARCHAR),'') + ' | ' + isnull(REPORT_CONSOLIDATER,'') + ' | ' + isnull(REPORT_CONTRIBUTOR1,'') + ' | ' 
			+ isnull(REPORT_CONTRIBUTOR2,'') + ' | ' + isnull(REPORT_CONTRIBUTOR3,'') + ' | ' + isnull(REPORT_CONTRIBUTOR4,'') + ' | ' 
			+ isnull(REMARKS,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
			+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
			+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'') + ' | '
			+ isnull(POSITION_DATE,'')
			FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE [RPT_ID]=@RPT_ID AND [ROW_NUM]=@ROW_NUM);
		
		EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ETEMPLATE_DATA','',@AfterImage,'I';
		
		IF @FREQUENCY_ID = '9' OR @FREQUENCY_ID = '10'
		begin
		
			DECLARE Cur_AuditTrail CURSOR FOR SELECT CAST(ROW_NUM_SRC AS VARCHAR) + ' | ' + CAST(REC_NO AS VARCHAR) + ' | ' + CAST(POSITION_DATE AS VARCHAR) + ' | ' + 
				 CAST(TARGET_SUBMISSION_DATE AS VARCHAR) FROM [dbo].[RRF_GUI_ETEMPLATE_ADHOC_DATA] WHERE ROW_NUM_SRC=@Row_Num_Ind ORDER BY REC_NO
			OPEN Cur_AuditTrail 
			FETCH NEXT FROM Cur_AuditTrail INTO @AfterImage
			WHILE @@FETCH_STATUS = 0
			BEGIN 
				
				EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ETEMPLATE_ADHOC_DATA','',@AfterImage,'I';
		
				FETCH NEXT FROM Cur_AuditTrail INTO @AfterImage
			END 
			CLOSE Cur_AuditTrail 
			DEALLOCATE Cur_AuditTrail		
	
		end
		
		--megatshamsul - 20170314 - SR1363674 - update frequency weekly
		IF @FREQUENCY_ID = '2'
		begin
		
			DECLARE Cur_AuditTrail CURSOR FOR SELECT CAST(ROW_NUM_SRC AS VARCHAR) + ' | ' + CAST(WEEK_NO AS VARCHAR) + ' | ' + WEEKLY_POSITION_DATE + ' | ' + 
				 CAST(TPLUS_WEEKLY_SUBMISSION_DATE AS VARCHAR) FROM [dbo].[RRF_GUI_ETEMPLATE_WEEKLY_DATA] WHERE ROW_NUM_SRC=@Row_Num_Ind ORDER BY WEEK_NO
			OPEN Cur_AuditTrail 
			FETCH NEXT FROM Cur_AuditTrail INTO @AfterImage
			WHILE @@FETCH_STATUS = 0
			BEGIN 
				
				EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ETEMPLATE_WEEKLY_DATA','',@AfterImage,'I';
		
				FETCH NEXT FROM Cur_AuditTrail INTO @AfterImage
			END 
			CLOSE Cur_AuditTrail 
			DEALLOCATE Cur_AuditTrail		
	
		end
	
	end
	ELSE
	begin
	
		--if final approved by FGTAppvr, remove all same RPT_ID but with different STATUS_ID, left only the current one at the end
		
		IF @STATUS_ID_NEXT = 'AP2' OR @STATUS_ID_NEXT = 'X'
		begin
		
			IF EXISTS (SELECT RPT_ID FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND [ROW_NUM]<>@ROW_NUM)
			begin
			
				DECLARE Cur_ETemplate_Data CURSOR FOR SELECT STATUS_ID,[ROW_NUM] FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND [ROW_NUM]<>@ROW_NUM
				OPEN Cur_ETemplate_Data 
				FETCH NEXT FROM Cur_ETemplate_Data INTO @STATUS_ID_OTHERS,@ROW_NUM_LOOP
				WHILE @@FETCH_STATUS = 0
				BEGIN 
					
					--megatshamsul - 20170314 - SR1363674 - update frequency monthly
					SET @BeforeImage = (SELECT TOP 1 RPT_ID + ' | ' + RPT_NAME + ' | ' + UNIT_ID + ' | ' + ENTITY_ID + ' | ' + REGULATOR_ID + ' | ' + REGULATOR_DEPT +  ' | ' 
						+ SREF + ' | ' + REMINDER_ID + ' | ' + isnull(CAST(REMINDER_DAYS AS VARCHAR),'') + ' | ' 
						+ FREQUENCY_ID + ' | ' + isnull(CAST(T_PLUS_SUBMISSION_DATE AS VARCHAR),'') + ' | '
						+ isnull(BIZ_DAY_ONLY,'') + ' | ' + SUBMISSION_MODE_ID + ' | ' + isnull(CAST(EFF_POSITION_DATE AS VARCHAR),'') + ' | '
						+ isnull(CAST(EXP_POSITION_DATE AS VARCHAR),'') + ' | ' + isnull(REPORT_CONSOLIDATER,'') + ' | ' + isnull(REPORT_CONTRIBUTOR1,'') + ' | ' 
						+ isnull(REPORT_CONTRIBUTOR2,'') + ' | ' + isnull(REPORT_CONTRIBUTOR3,'') + ' | ' + isnull(REPORT_CONTRIBUTOR4,'') + ' | ' 
						+ isnull(REMARKS,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
						+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
						+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'') + ' | '
						+ isnull(POSITION_DATE,'')
						FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID_OTHERS AND [ROW_NUM]=@ROW_NUM_LOOP);
					
					DELETE FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID_OTHERS AND [ROW_NUM]=@ROW_NUM_LOOP;
					
					EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ETEMPLATE_DATA',@BeforeImage,'','D'
			
					FETCH NEXT FROM Cur_ETemplate_Data INTO @STATUS_ID_OTHERS,@ROW_NUM_LOOP
				END 
				CLOSE Cur_ETemplate_Data 
				DEALLOCATE Cur_ETemplate_Data	
			
			end
		
		end
		
		--megatshamsul - 20170314 - SR1363674 - update frequency monthly
		SET @BeforeImage = (SELECT TOP 1 RPT_ID + ' | ' + RPT_NAME + ' | ' + UNIT_ID + ' | ' + ENTITY_ID + ' | ' + REGULATOR_ID + ' | ' + REGULATOR_DEPT +  ' | ' 
			+ SREF + ' | ' + REMINDER_ID + ' | ' + isnull(CAST(REMINDER_DAYS AS VARCHAR),'') + ' | '
			+ FREQUENCY_ID + ' | ' + isnull(CAST(T_PLUS_SUBMISSION_DATE AS VARCHAR),'') + ' | '
			+ isnull(BIZ_DAY_ONLY,'') + ' | ' + SUBMISSION_MODE_ID + ' | ' + isnull(CAST(EFF_POSITION_DATE AS VARCHAR),'') + ' | '
			+ isnull(CAST(EXP_POSITION_DATE AS VARCHAR),'') + ' | ' + isnull(REPORT_CONSOLIDATER,'') + ' | ' + isnull(REPORT_CONTRIBUTOR1,'') + ' | ' 
			+ isnull(REPORT_CONTRIBUTOR2,'') + ' | ' + isnull(REPORT_CONTRIBUTOR3,'') + ' | ' + isnull(REPORT_CONTRIBUTOR4,'') + ' | ' 
			+ isnull(REMARKS,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
			+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
			+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'') + ' | '
			+ isnull(POSITION_DATE,'')
			FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID AND [ROW_NUM]=@ROW_NUM);
		
		IF @ROLE_ID = 'Approver'
		begin
			UPDATE [dbo].[RRF_GUI_ETEMPLATE_DATA] SET [STATUS_ID]=@STATUS_ID_NEXT,[APPROVER_ID]=@APPROVER_ID,[APPROVER_DATE]=GETDATE(),
				[APPROVER_FGT_ID]=NULL,[APPROVER_FGT_DATE]=NULL,[REJECT_REASON]=@REJECT_REASON
				WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID AND [ROW_NUM]=@ROW_NUM;
		end	
						
		IF @ROLE_ID = 'FGTAppvr'		
		begin
			UPDATE [dbo].[RRF_GUI_ETEMPLATE_DATA] SET [STATUS_ID]=@STATUS_ID_NEXT,[APPROVER_FGT_ID]=@APPROVER_ID,[APPROVER_FGT_DATE]=GETDATE(),
				[REJECT_REASON]=@REJECT_REASON
				WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID AND [ROW_NUM]=@ROW_NUM;
		end	
		
		--megatshamsul - 20170314 - SR1363674 - update frequency monthly
		SET @AfterImage = (SELECT TOP 1 RPT_ID + ' | ' + RPT_NAME + ' | ' + UNIT_ID + ' | ' + ENTITY_ID + ' | ' + REGULATOR_ID + ' | ' + REGULATOR_DEPT +  ' | ' 
			+ SREF + ' | ' + REMINDER_ID + ' | ' + isnull(CAST(REMINDER_DAYS AS VARCHAR),'') + ' | '
			+ FREQUENCY_ID + ' | ' + isnull(CAST(T_PLUS_SUBMISSION_DATE AS VARCHAR),'') + ' | '
			+ isnull(BIZ_DAY_ONLY,'') + ' | ' + SUBMISSION_MODE_ID + ' | ' + isnull(CAST(EFF_POSITION_DATE AS VARCHAR),'') + ' | '
			+ isnull(CAST(EXP_POSITION_DATE AS VARCHAR),'') + ' | ' + isnull(REPORT_CONSOLIDATER,'') + ' | ' + isnull(REPORT_CONTRIBUTOR1,'') + ' | ' 
			+ isnull(REPORT_CONTRIBUTOR2,'') + ' | ' + isnull(REPORT_CONTRIBUTOR3,'') + ' | ' + isnull(REPORT_CONTRIBUTOR4,'') + ' | ' 
			+ isnull(REMARKS,'') + ' | ' + STATUS_ID + ' | ' + CAST(CREATE_DATE AS VARCHAR) + ' | ' + PREPARER_ID + ' | ' 
			+ CAST(PREPARER_DATE AS VARCHAR) + ' | ' + isnull(APPROVER_ID,'') + ' | ' + isnull(CAST(APPROVER_DATE AS VARCHAR),'') + ' | '
			+ isnull(APPROVER_FGT_ID,'') + ' | ' + isnull(CAST(APPROVER_FGT_DATE AS VARCHAR),'') + ' | ' + isnull(REJECT_REASON,'') + ' | '
			+ isnull(POSITION_DATE,'')
			FROM [dbo].[RRF_GUI_ETEMPLATE_DATA] WHERE RPT_ID=@RPT_ID AND STATUS_ID=@STATUS_ID_NEXT AND [ROW_NUM]=@ROW_NUM);
		
		EXEC [dbo].[uspAuditTrail] @APPROVER_ID,'RRF_GUI_ETEMPLATE_DATA',@BeforeImage,@AfterImage,'U'
	
	end
	
Commit

GO
