SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[uspListUsersAll]

@USER_ID varchar(30),
@UNIT_ID varchar(3),
@ROLE_ID varchar(10)

AS

	declare @strSQL varchar(3000)
	declare @strSQLCondition varchar(1000)
	declare @strSQLOrderBy varchar(1000)
	
	set @strSQLOrderBy = ' ORDER BY a.[USER_ID]'
	
	set @strSQL = 'SELECT a.[USER_ID],a.[USER_DOMAIN_ID],a.[USER_NAME],a.[EMP_ID],b.[UNIT_CODE_NM] AS [UNIT_DESC],'
	set @strSQL = @strSQL + 'f.[DEPT_CODE_NM] AS [DEPT_DESC],g.[LOB_CODE_NM] AS [LOB_DESC],f.[HOD],a.[DAYS_TO_DORMANT] AS [DRMT_DAYS],'--Added dormant days to display
	set @strSQL = @strSQL + 'a.[USER_EMAIL],a.[IP_ADDRESS],c.[GUI_ROLE_DSC] AS [ROLE_DESC],d.[USER_STAT_CODE_DSC] as [STATUS_DESC],'
	set @strSQL = @strSQL + 'a.[USER_STAT_REASON]'
	set @strSQL = @strSQL + 'CASE a.[IS_CURRLY_LOGGED_IN] WHEN ''Y'' THEN ''Yes'' WHEN ''N'' THEN ''No'' ELSE a.[IS_CURRLY_LOGGED_IN] END AS [IS_CURRLY_LOGGED_IN],'
	set @strSQL = @strSQL + 'a.[LAST_LGIN_IP_ADR],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[CRETN_DT],103) + '' '' + CONVERT(VARCHAR,a.[CRETN_DT],114) AS [CRETN_DT],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGIN],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGIN],114) AS [TS_LAST_LGIN],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[TS_LAST_LGOT],103) + '' '' + CONVERT(VARCHAR,a.[TS_LAST_LGOT],114) AS [TS_LAST_LGOT],'
	set @strSQL = @strSQL + 'a.[LOG_UPDT_USER_ID] AS [UPDT_USER_ID],'
	set @strSQL = @strSQL + 'CONVERT(VARCHAR,a.[LOG_UPDT_DT],103) + '' '' + CONVERT(VARCHAR,a.[LOG_UPDT_DT],114) AS [UPDT_DATE]'
	set @strSQL = @strSQL + 'FROM [dbo].[RRF_GUI_USERS] a '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_UNIT_CODE] b on a.[UNIT_ID]=b.[UNIT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_USER_ROLE] c on a.[USER_ROLE_ID]=c.[GUI_RULE_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_REF_USERSTAT] d on a.[STATUS_ID]=d.[USER_STAT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_DEPT_CODE] f on b.[DEPT_CODE]=f.[DEPT_CODE] '
	set @strSQL = @strSQL + 'INNER JOIN [dbo].[RRF_GUI_LOB_CODE] g on f.[LOB_CODE]=g.[LOB_CODE] '
	
	set @strSQLCondition = ' WHERE a.[STATUS_ID]<>''X'''	--ignore DELETED
	
	IF @USER_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND a.[USER_ID] LIKE ''%' + @USER_ID + '%'''
	end
	
	IF @UNIT_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND a.[UNIT_ID] = ''' + @UNIT_ID + ''''
	end
	
	IF @ROLE_ID <> ''
	begin
		set @strSQLCondition = @strSQLCondition + ' AND [GUI_RULE_CODE]=''' + @ROLE_ID + ''''
	end		
	
	set @strSQL = @strSQL + @strSQLCondition + @strSQLOrderBy
	
	EXECUTE(@strSQL)

GO
