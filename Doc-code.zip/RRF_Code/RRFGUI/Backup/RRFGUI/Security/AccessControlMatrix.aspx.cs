﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;

namespace RRFGUI.Security
{
    public partial class AccessControlMatrix : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "ACCESS CONTROL MATRIX";

            if (!IsPostBack)
            {
                TabContainerAccessControlMatrix.ActiveTab = TabPanelListing;

                fnLoadUnitCode();
                fnBindListing(false);
            }
        }

        #region PreLoading

        private void fnLoadUnitCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUnitCode(Session["strUserId"].ToString());

            ddlFilterUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            
            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["UNIT_CODE_NM"].ToString(), dr["UNIT_CODE"].ToString()));
            }
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        #endregion

        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    switch (e.Row.Cells[3].Text)
            //    {
            //        case "Y": e.Row.Cells[3].Text = "Yes"; break;
            //        case "N": e.Row.Cells[3].Text = "No"; break;
            //    }
            //}
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListAccessControlMatrix(ddlFilterUNIT_ID.Text, Session["strUserId"].ToString());
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();

            if (!ifExport)
                lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
        }

        #endregion

        #region region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            string strMessage = string.Empty;

            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintUnitId = "";
                    
                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(true);

                            if (ddlFilterUNIT_ID.SelectedValue.Length > 0)
                                strPrintUnitId = ddlFilterUNIT_ID.SelectedItem.Text;
                            else
                                strPrintUnitId = "All Units";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF ACCESS CONTROL MATRIX", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("UNIT_ID : " + strPrintUnitId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfAccessControlMatrix.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "AccessControlMatrixPrint.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "AccessControlMatrixPrint.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfAccessControlMatrix.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(true);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                                sb.Append('"' + val + '"' + ',');
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());

                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion
    }
}