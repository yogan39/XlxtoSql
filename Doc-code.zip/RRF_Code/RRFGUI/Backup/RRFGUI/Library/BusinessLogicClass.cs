﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.SessionState;
using System.Configuration;
using System.IO;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.ActiveDirectory;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net.Mail;

namespace RRFGUI.Library
{
    public class BusinessLogicClass
    {
        private static string strUserId = string.Empty;
        private static string SUCCESS = "SUCCESS";
        private static string ERROR = "ERROR";

        public BusinessLogicClass(string sUserId)
        {
            strUserId = sUserId;
        }

        #region Common Functions

        public static void ShowMessage(string Message)
        {
            string script = "<script type=\"text/javascript\">alert('" + Message + "');</script>";
            Page page;
            try
            {
                page = HttpContext.Current.CurrentHandler as Page;
            }
            catch
            {
                page = new Page();
            }
            if (page != null && !page.ClientScript.IsClientScriptBlockRegistered("alert"))
            {
                //page.ClientScript.RegisterClientScriptBlock(typeof(Alert), "alert", script);
                page.ClientScript.RegisterStartupScript(typeof(BusinessLogicClass), "alert", script);

            }
        }

        public static bool fnLogErrorInFile(long lngErrNumber, string strErrLocation, string strErrDescription, string strUserId)
        {
            DateTime CD = DateTime.Now;

            try
            {
                string strErrorLogPath = ConfigurationManager.AppSettings["LOG_FILE_PATH"].ToString();
                string strFileName = "Log_" + strUserId + "_" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                strFileName = strErrorLogPath + strFileName;

                StreamWriter sw = new StreamWriter(strFileName, true);
                sw.WriteLine("*******************************************************************************");
                sw.WriteLine("Date: " + DateTime.Now);
                sw.WriteLine("Error Number: " + lngErrNumber.ToString());
                sw.WriteLine("Description: " + strErrDescription);
                sw.WriteLine("Location: " + strErrLocation);
                sw.WriteLine("*******************************************************************************");
                sw.WriteLine();
                sw.Flush();
                sw.Close();
            }
            catch (Exception ex)
            {   }

            return true;
        }

        public static string fnRemoveIllegalCharFromGrid(string sInput)
        {
            string result = sInput;

            string pattern = @"[^a-zA-Z0-9@#$%&*+\-_(),+':;?.,![\]\s\\/+$]";
            Regex rgx = new Regex(pattern);
            result = rgx.Replace(sInput, "");

            return result;
        }

        public static string fnRemoveIllegalNonHTMLCharFromGrid(string sInput)
        {
            #region list of ignore chars

            List<String> ignoreList = new List<String>()
            {
                "&#127;",
                "&#128;",
                "&#129;",
                "&#130;",
                "&#131;",
                "&#132;",
                "&#133;",
                "&#134;",
                "&#135;",
                "&#136;",
                "&#137;",
                "&#138;",
                "&#139;",
                "&#140;",
                "&#141;",
                "&#142;",
                "&#143;",
                "&#144;",
                "&#145;",
                "&#146;",
                "&#147;",
                "&#148;",
                "&#149;",
                "&#150;",
                "&#151;",
                "&#152;",
                "&#153;",
                "&#154;",
                "&#155;",
                "&#156;",
                "&#157;",
                "&#158;",
                "&#159;",
                "&#160;",
                "&#161;",
                "&#162;",
                "&#163;",
                "&#164;",
                "&#165;",
                "&#166;",
                "&#167;",
                "&#168;",
                "&#169;",
                "&#170;",
                "&#171;",
                "&#172;",
                "&#173;",
                "&#174;",
                "&#175;",
                "&#176;",
                "&#177;",
                "&#178;",
                "&#179;",
                "&#180;",
                "&#181;",
                "&#182;",
                "&#183;",
                "&#184;",
                "&#185;",
                "&#186;",
                "&#187;",
                "&#188;",
                "&#189;",
                "&#190;",
                "&#191;",
                "&#192;",
                "&#193;",
                "&#194;",
                "&#195;",
                "&#196;",
                "&#197;",
                "&#198;",
                "&#199;",
                "&#200;",
                "&#201;",
                "&#202;",
                "&#203;",
                "&#204;",
                "&#205;",
                "&#206;",
                "&#207;",
                "&#208;",
                "&#209;",
                "&#210;",
                "&#211;",
                "&#212;",
                "&#213;",
                "&#214;",
                "&#215;",
                "&#216;",
                "&#217;",
                "&#218;",
                "&#219;",
                "&#220;",
                "&#221;",
                "&#222;",
                "&#223;",
                "&#224;",
                "&#225;",
                "&#226;",
                "&#227;",
                "&#228;",
                "&#229;",
                "&#230;",
                "&#231;",
                "&#232;",
                "&#233;",
                "&#234;",
                "&#235;",
                "&#236;",
                "&#237;",
                "&#238;",
                "&#239;",
                "&#240;",
                "&#241;",
                "&#242;",
                "&#243;",
                "&#244;",
                "&#245;",
                "&#246;",
                "&#247;",
                "&#248;",
                "&#249;",
                "&#250;",
                "&#251;",
                "&#252;",
                "&#253;",
                "&#254;",
                "&#255;"
            };

            #endregion

            string result = sInput;

            foreach (string word in ignoreList)
            {
                result = result.Replace(word, string.Empty);
            }

            return result;
        }

        public static string GetDDMMYYYY(DateTime dtNow)
        {
            string strDate = string.Empty;

            if (dtNow == null)
                dtNow = DateTime.Now;

            int dtDay = dtNow.Day;
            int dtMonth = dtNow.Month;
            int dtYear = dtNow.Year;

            if (dtDay.ToString().Length == 1)
                strDate = "0" + dtDay.ToString();
            else
                strDate = dtDay.ToString();

            strDate += "/";

            if (dtMonth.ToString().Length == 1)
                strDate += "0" + dtMonth.ToString();
            else
                strDate += dtMonth.ToString();

            strDate += "/";
            strDate += dtYear.ToString();

            return strDate;
        }

        public static string SetYYYYMMDD(string sDDMMYYYY)
        {
            string strDate = string.Empty;
            string[] arrDate = new string[1] {""};

            if (sDDMMYYYY.ToLower().Contains('/'))
                arrDate = sDDMMYYYY.Split('/');    //19/10/2016
            if (sDDMMYYYY.ToLower().Contains('-'))
                arrDate = sDDMMYYYY.Split('-');    //19-10-2016

            if (arrDate.Length == 3)
                strDate = arrDate[2] + '/' + arrDate[1] + '/' + arrDate[0]; //2016/10/19

            return strDate;
        }

        public static bool fnValidateDatesRange(string sDateFrom, string sDateTo)
        {
            bool ifOK = false;

            if (!string.IsNullOrEmpty(sDateFrom) && !string.IsNullOrEmpty(sDateTo))
            {
                try
                {
                    sDateFrom = sDateFrom.Replace('-', '/');
                    sDateTo = sDateTo.Replace('-', '/');

                    string[] arrTempDate = sDateFrom.Split('/');
                    string sTempDate = sDateFrom;

                    if (arrTempDate.Length == 3)
                        sTempDate = arrTempDate[2] + "/" + arrTempDate[1] + "/" + arrTempDate[0];

                    DateTime dDate1 = DateTime.Parse(sTempDate);

                    arrTempDate = sDateTo.Split('/');
                    sTempDate = sDateTo;

                    if (arrTempDate.Length == 3)
                        sTempDate = arrTempDate[2] + "/" + arrTempDate[1] + "/" + arrTempDate[0];

                    DateTime dDate2 = DateTime.Parse(sTempDate);

                    int result = DateTime.Compare(dDate1, dDate2);

                    if (result <= 0)
                        ifOK = true;

                }
                catch (Exception ex)
                { }
            }

            return ifOK;
        }

        public static DataTable fnLoadApprovalStatusCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListStatus", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnGetEmailRecipients(string sUnitId, string sRoleId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = sUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@ROLE_ID";
            parm2.DbType = DbType.String;
            parm2.Value = sRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetEmailRecipients", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static bool fnSendEmail(DataTable dtEmailTo, DataTable dtEmailCC, string sEmailSubject, string sEmailBody, string strUserId)
        {
            bool ifOK = false;

            try
            {
                string sSMTPSERVER = ConfigurationManager.AppSettings["SMTP_SERVER"];
                string sEMAILFROM = ConfigurationManager.AppSettings["EMAIL_FROM"];

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient(sSMTPSERVER);

                mail.From = new MailAddress(sEMAILFROM);

                foreach (DataRow dr in dtEmailTo.Rows)
                {
                    mail.To.Add(dr["USER_EMAIL"].ToString());
                }

                foreach (DataRow dr in dtEmailCC.Rows)
                {
                    mail.CC.Add(dr["USER_EMAIL"].ToString());
                }

                if (ConfigurationManager.AppSettings["SERVER_MODE"].Length > 0)
                    sEmailSubject = "(" + ConfigurationManager.AppSettings["SERVER_MODE"].ToString() + ")" + sEmailSubject;

                //megatshamsul - 20170323 - SR1363674 - add URL to all email notifications
                sEmailBody += "<p>";
                sEmailBody += ConfigurationManager.AppSettings["SITE_ROOT_URL"].ToString() + "/login.aspx";

                mail.IsBodyHtml = true;
                mail.Subject = sEmailSubject;
                mail.Body = sEmailBody;

                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential(strUserId, "");
                SmtpServer.EnableSsl = false;

                //pending - to take out!!
                //SmtpServer.Send(mail);

                ifOK = true;
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnSendEmail", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        //megatshamsul - 20170314 - SR1363674 - load ordinal day number
        public static DataTable fnLoadOrdinalNumber(string strUserId)
        {
            string[] arrOrdNumber = new[] { "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th", "11th", "12th", "13th", "14th", "15th", "16th", "17th", "18th", "19th", "20th", "21st", "22nd", "23rd", "24th", "25th", "26th", "27th", "28th", "29th", "30th", "31st", "EOM" };
            DataSet dsDetails = ToDataSet(arrOrdNumber);

            return dsDetails.Tables[0];
        }

        //megatshamsul - 20170314 - SR1363674 - convert string[] to DataSet
        private static DataSet ToDataSet(string[] input)
        {
            DataSet dataSet = new DataSet();
            DataTable dataTable = dataSet.Tables.Add();
            dataTable.Columns.Add();
            Array.ForEach(input, c => dataTable.Rows.Add()[0] = c);

            return dataSet;
        }

        #endregion

        #region Login Functions

        public static string fnValidateUserIdPassword(string strUserName, string strPassword, string strDomainName, string strSessionId, string strClientIpAddress)
        {
            string strMessage = string.Empty;
            string strAuditTrialMessage = string.Empty;
            string strSessionActionCode = string.Empty;
            string strSessionStatusCode = string.Empty;

            strSessionActionCode = "LI";

            if (string.IsNullOrEmpty(strUserName))
            {
                return "Enter the Login Name";
            }
            else if (string.IsNullOrEmpty(strPassword))
            {
                return "Enter the Password";
            }
            else
            {
                try
                {
                    PrincipalContext objPrincipleContext = new PrincipalContext(ContextType.Domain, strDomainName);
                    UserPrincipal objUserPrinciple = UserPrincipal.FindByIdentity(objPrincipleContext, strUserName);

                    if (objUserPrinciple == null)
                    {
                        strMessage = "Not authorised to access this application";
                        strAuditTrialMessage = "Invalid Lan ID";
                    }
                    else if (!objPrincipleContext.ValidateCredentials(strUserName, strPassword))
                    {
                        strMessage = "Not authorised to access this application";
                        strAuditTrialMessage = "Invalid Password";
                    }
                    else if (objUserPrinciple.AccountExpirationDate != null && !objUserPrinciple.PasswordNeverExpires)
                    {
                        strMessage = "Not authorised to access this application";
                        strAuditTrialMessage = "Password Expired";
                    }
                    else
                    {
                        strMessage = fnCheckApplicationLevelSecurity(strUserName, strDomainName);

                        if (!string.IsNullOrEmpty(strMessage))
                        {
                            strAuditTrialMessage = strMessage;

                            if (strMessage == "Concurrent Session")
                            {
                                strMessage = "Another active session exists";
                            }
                            else
                            {
                                strMessage = "Not authorised to access this application";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    fnLogErrorInFile(12, "fnValidateUserIdPassword.Exception", ex.Message, strUserName);

                    strMessage = ex.Message;
                    strAuditTrialMessage = strMessage;
                }

                if (!string.IsNullOrEmpty(strMessage))
                {
                    strSessionStatusCode = "NOK";
                    fnLogMaintenance(strSessionId, strSessionActionCode, strUserName, strDomainName, strClientIpAddress, strSessionStatusCode, strAuditTrialMessage);
                }
                else
                {
                    strSessionStatusCode = "OK";
                    fnLogMaintenance(strSessionId, strSessionActionCode, strUserName, strDomainName, strClientIpAddress, strSessionStatusCode, "Login Successful");
                }
            }

            return strMessage;
        }

        private static string fnCheckApplicationLevelSecurity(string strUserId, string strDomainId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspApplicationLevelSecurityCheck", SqlParameterList,strUserId);

            if (dtDetails == null || dtDetails.Rows.Count == 0)
            {
                strMessage = "Invalid Application User";
            }
            else
            {
                foreach (DataRow dr in dtDetails.Rows)
                {
                    if (dr["UserStatus"].ToString() != "A")
                    {
                        strMessage = "Invalid Application User";
                    }
                    else if (dr["IsCurrentlyLoggedIn"].ToString() == "Y")
                    {
                        strMessage = "Concurrent Session";
                    }
                }
            }

            return strMessage;
        }

        public static string fnLogMaintenance(string strSessionSeqNo, string strActionCode, string strWindowsUserId, string strWindowsDomainId, string strClientIpAddress, string strSessionStatusCode, string strSessionNote)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@SESN_SEQ_NO";
            parm1.DbType = DbType.String;
            parm1.Value = strSessionSeqNo;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@ACTN_CODE";
            parm2.DbType = DbType.String;
            parm2.Value = strActionCode;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@WNDWS_USER_ID";
            parm3.DbType = DbType.String;
            parm3.Value = strWindowsUserId;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@WNDWS_USER_DMN";
            parm4.DbType = DbType.String;
            parm4.Value = strWindowsDomainId;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@WNDWS_IP_ADR";
            parm5.DbType = DbType.String;
            parm5.Value = strClientIpAddress;

            SqlParameter parm6 = new SqlParameter();
            parm6.ParameterName = "@SESN_STAT_CODE";
            parm6.DbType = DbType.String;
            parm6.Value = strSessionStatusCode;

            SqlParameter parm7 = new SqlParameter();
            parm7.ParameterName = "@SESN_NOTE";
            parm7.DbType = DbType.String;
            parm7.Value = strSessionNote;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);
            SqlParameterList.Add(parm6);
            SqlParameterList.Add(parm7);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspSessionLogMaintenance", SqlParameterList, strWindowsUserId);

            if (dtDetails.Rows.Count > 0)
                strMessage = dtDetails.Rows[0][0].ToString();
            else
                strMessage = ERROR;

            return strMessage;
        }

        public static void fnLockUserLanID(string strUserId, string strDomainName)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainName;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspDisableUserID", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
                strMessage = dtDetails.Rows[0][0].ToString();
            else
                strMessage = ERROR;
        }

        public static bool fnUpdateUserStatusforLoginAndLogOut(string strLoginCode, string strUserId, string strDomainId, string strClientIpAddress)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;
            bool isOk = false;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@LAST_LGIN_IP_ADR";
            parm3.DbType = DbType.String;
            parm3.Value = strClientIpAddress;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@IS_CURRLY_LOGGED_IN";
            parm4.DbType = DbType.String;
            parm4.Value = strLoginCode;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@TS_LAST_DATE";
            parm5.DbType = DbType.String;
            parm5.Value = DateTime.Now;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);

            isOk = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspUpdateUserTableForUserLogInOut", SqlParameterList, strUserId);

            return isOk;
        }

        public static DataTable fnLoadRoleToSession(string strUserId, string strDomainName)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainName;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetUserPageRolePermission", SqlParameterList, strUserId);

            DataTable dtSessionPermission = new DataTable();

            DataColumn PageCode = new DataColumn();
            PageCode.ColumnName = "PageCode";
            dtSessionPermission.Columns.Add(PageCode);

            DataColumn Url = new DataColumn();
            Url.ColumnName = "Url";
            dtSessionPermission.Columns.Add(Url);

            DataColumn ViewOption = new DataColumn();
            ViewOption.ColumnName = "ViewOption";
            dtSessionPermission.Columns.Add(ViewOption);

            DataRow drSession;

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtDetails.Rows)
                {
                    if (dr["ViewOption"].ToString() == "N")
                    {
                    }
                    else
                    {
                        drSession = dtSessionPermission.NewRow();
                        drSession["PageCode"] = dr["PageCode"];
                        drSession["Url"] = dr["Url"];

                        if (dr["ViewOption"].ToString() == "Y")
                            drSession["ViewOption"] = "1";
                        else
                            drSession["ViewOption"] = "0";

                        dtSessionPermission.Rows.Add(drSession);
                    }
                }
            }

            return dtSessionPermission;
        }

        public static DataSet fnGetMenuGroup(string strUserId)
        {
            DataSet dsDetails = new DataSet();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> OdbcParameterList = new List<SqlParameter>();

            dsDetails = ObjDataClass.fnReturnDataSet("P", "dbo.uspMenuGroup", new List<SqlParameter>(), strUserId);

            return dsDetails;
        }
        
        public static DataTable fnGetUserName(string strUserId, string strDomainName)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strUserName = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainName;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetUserName", SqlParameterList, strUserId);

            //if (dtDetails.Rows.Count > 0)
            //    strUserName = dtDetails.Rows[0][0].ToString();

            return dtDetails;
        }

        public static string fnLoadSupervisorToSession(string strUserId, string strDomainName)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strSupervisorFlag = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_LAN_DMN_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strDomainName;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetUserSupervisorFlag", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
                strSupervisorFlag = dtDetails.Rows[0][0].ToString();

            return strSupervisorFlag;
        }

        #endregion

        #region User Id Maintenance Functions

        public static DataTable fnLoadUnitCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListUnit", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnLoadRoleCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListRoles", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnLoadUserStatusCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListUserStatus", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnGetUnitDetails(string strUnitId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUnitId;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetUnitDetails", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetUserDetails(string strSearchUserId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strSearchUserId;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetUserDetails", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnListUsers(string strSearchUserId, string strSearchUnitId, string strSearchRoleId, string strUserId, bool ifExport)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            
            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@USER_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strSearchUserId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@UNIT_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSearchUnitId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@ROLE_ID";
            parm3.DbType = DbType.String;
            parm3.Value = strSearchRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);

            if (ifExport)
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListUsersAll", SqlParameterList, strUserId);
            else
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListUsers", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static string fnUpdateUserDetails(string Update_Type, DataTable dtCodeDetails, string strUserId)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UPDATE_TYPE";
            parm1.DbType = DbType.String;
            parm1.Value = Update_Type;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@DATA_DETAILS";
            parm2.SqlDbType = SqlDbType.Structured;
            parm2.Value = dtCodeDetails;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@MAKER_ID";
            parm3.DbType = DbType.String;
            parm3.Value = strUserId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);

            isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspUpdateUserDetails", SqlParameterList, strUserId);

            if (isOK)
            {
                if (Update_Type == "I")
                    strMessage = "Insert User Details successful";
                else if (Update_Type == "U")
                    strMessage = "Update User Details successful";
                else if (Update_Type == "D")
                    strMessage = "Delete User Details successful";
            }
            else
            {
                if (Update_Type == "I")
                    strMessage = "Failed to insert User Details";
                else if (Update_Type == "U")
                    strMessage = "Failed to update User Details";
                else if (Update_Type == "D")
                    strMessage = "Failed to delete User Details";
            }

            return strMessage;
        }

        #endregion

        #region Audit Trail Functions

        public static DataTable fnListAuditTrail(string strListType, string strSearchUserId, string strSearchUpdtFromDate, string strSearchUpdtToDate, string strSearchTblNm, string strSearchActnId, string strUserId, bool ifExport)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@LIST_TYPE";
            parm1.DbType = DbType.String;
            parm1.Value = strListType;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@UPDT_USER_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSearchUserId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@LOG_UPDT_DT_FROM";
            parm3.DbType = DbType.String;
            parm3.Value = strSearchUpdtFromDate;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@LOG_UPDT_DT_TO";
            parm4.DbType = DbType.String;
            parm4.Value = strSearchUpdtToDate;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@TBL_NM";
            parm5.DbType = DbType.String;
            parm5.Value = strSearchTblNm;

            SqlParameter parm6 = new SqlParameter();
            parm6.ParameterName = "@ACTN";
            parm6.DbType = DbType.String;
            parm6.Value = strSearchActnId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);
            SqlParameterList.Add(parm6);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListAuditTrail", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetAuditTrailDetails(string strId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ID";
            parm1.DbType = DbType.String;
            parm1.Value = strId;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetAuditTrail", SqlParameterList, strUserId);

            return dtDetails;
        }
        
        #endregion

        #region Session Log Functions

        public static DataTable fnListSessionLog(string strSearchLogDate, string strSearchUserId, string strSearchActionCode, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@LOG_DATE";
            parm1.DbType = DbType.String;
            parm1.Value = strSearchLogDate;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSearchUserId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@ACTION_CODE";
            parm3.DbType = DbType.String;
            parm3.Value = strSearchActionCode;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            
            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListSessionLog", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetSessionLogDetails(string strSESSION_SEQ_NO, string strSelectedUserId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@SESSION_SEQ_NO";
            parm1.DbType = DbType.String;
            parm1.Value = strSESSION_SEQ_NO;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@USER_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSelectedUserId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetSessionLog", SqlParameterList, strUserId);

            return dtDetails;
        }

        #endregion

        #region Access Control Matrix Functions

        public static DataTable fnListAccessControlMatrix(string strSearchUnitId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strSearchUnitId;

            SqlParameterList.Add(parm1);
            
            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListAccessControlMatrix", SqlParameterList, strUserId);

            return dtDetails;
        }

        #endregion

        #region E-Template Maintenance Functions

        //megatshamsul - 20170420 - SR1363674 - Entities loaded from table instead
        public static DataTable fnLoadEntityCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListEntity", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnLoadRegulatorCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListRegulator", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnLoadFrequencyCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListFrequency", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnLoadSubmissionCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListSubmissionMode", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnListETemplates(string strSearchRptId, string strSearchRptName, string strSearchRegulatorId, string strSearchSREF, string strSearchFrequencyId, bool bFilterStatusAll, bool bFilterStatusDraft, bool bFilterStatusNew, bool bFilterStatusApproved, bool bFilterStatusRejected, bool bFilterStatusPendingApproval, string strSearchFromDate, string strSearchToDate, string strUserId, string strUnitId, string strRoleId, bool ifExport, bool ifReject)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@RPT_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSearchRptId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@RPT_NAME";
            parm3.DbType = DbType.String;
            parm3.Value = strSearchRptName;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@REGULATOR_ID";
            parm4.DbType = DbType.String;
            parm4.Value = strSearchRegulatorId;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@SREF";
            parm5.DbType = DbType.String;
            parm5.Value = strSearchSREF;

            SqlParameter parm6 = new SqlParameter();
            parm6.ParameterName = "@FREQUENCY_ID";
            parm6.DbType = DbType.String;
            parm6.Value = strSearchFrequencyId;

            SqlParameter parm7 = new SqlParameter();
            parm7.ParameterName = "@STATUS_ALL";
            parm7.DbType = DbType.String;

            if (bFilterStatusAll)
                parm7.Value = "1";
            else
                parm7.Value = "0";

            SqlParameter parm8 = new SqlParameter();
            parm8.ParameterName = "@STATUS_DRAFT";
            parm8.DbType = DbType.String;

            if (bFilterStatusDraft)
                parm8.Value = "1";
            else
                parm8.Value = "0";

            SqlParameter parm9 = new SqlParameter();
            parm9.ParameterName = "@STATUS_NEW";
            parm9.DbType = DbType.String;

            if (bFilterStatusNew)
                parm9.Value = "1";
            else
                parm9.Value = "0";

            SqlParameter parm10 = new SqlParameter();
            parm10.ParameterName = "@STATUS_APP";
            parm10.DbType = DbType.String;

            if (bFilterStatusApproved)
                parm10.Value = "1";
            else
                parm10.Value = "0";

            SqlParameter parm11 = new SqlParameter();
            parm11.ParameterName = "@STATUS_REJ";
            parm11.DbType = DbType.String;

            if (bFilterStatusRejected)
                parm11.Value = "1";
            else
                parm11.Value = "0";

            SqlParameter parm12 = new SqlParameter();
            parm12.ParameterName = "@STATUS_PA";
            parm12.DbType = DbType.String;

            if (bFilterStatusPendingApproval)
                parm12.Value = "1";
            else
                parm12.Value = "0";
            
            SqlParameter parm13 = new SqlParameter();
            parm13.ParameterName = "@FROM_DATE";
            parm13.DbType = DbType.String;
            parm13.Value = strSearchFromDate;

            SqlParameter parm14 = new SqlParameter();
            parm14.ParameterName = "@TO_DATE";
            parm14.DbType = DbType.String;
            parm14.Value = strSearchToDate;

            SqlParameter parm15 = new SqlParameter();
            parm15.ParameterName = "@IF_REJECT";
            parm15.DbType = DbType.String;

            if (ifReject && !ifExport)
                parm15.Value = "1";
            else
                parm15.Value = "0";

            SqlParameter parm16 = new SqlParameter();
            parm16.ParameterName = "@ROLE_ID";
            parm16.DbType = DbType.String;
            parm16.Value = strRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);
            SqlParameterList.Add(parm6);
            SqlParameterList.Add(parm7);
            SqlParameterList.Add(parm8);
            SqlParameterList.Add(parm9);
            SqlParameterList.Add(parm10);
            SqlParameterList.Add(parm11);
            SqlParameterList.Add(parm12);
            SqlParameterList.Add(parm13);
            SqlParameterList.Add(parm14);
            SqlParameterList.Add(parm15);
            SqlParameterList.Add(parm16);

            if (ifExport)
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListETemplatesAll", SqlParameterList, strUserId);
            else
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListETemplates", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetETemplateDetails(string strRptId, string strStatusId, string strROW_NUM, string strUnitId, string strUserId, string strRoleId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@RPT_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strRptId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@STATUS_ID";
            parm3.DbType = DbType.String;
            parm3.Value = strStatusId;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@ROW_NUM";
            parm4.DbType = DbType.String;
            parm4.Value = strROW_NUM;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@ROLE_ID";
            parm5.DbType = DbType.String;
            parm5.Value = strRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetETemplate", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetETemplateAdHocDetails(string strRowNum, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ROW_NUM";
            parm1.DbType = DbType.String;
            parm1.Value = strRowNum;

            SqlParameterList.Add(parm1);
            
            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetETemplateAdHoc", SqlParameterList, strUserId);

            return dtDetails;
        }

        //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
        public static DataTable fnGetETemplateWeeklyDetails(string strRowNum, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ROW_NUM";
            parm1.DbType = DbType.String;
            parm1.Value = strRowNum;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetETemplateWeekly", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static bool fnAllowToSubmitETemplate(string strRptId, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            bool ifOK = false;

            int iTotal = 0;
            string sTotal = string.Empty;

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@RPT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strRptId;

            SqlParameterList.Add(parm1);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetTotalESubmissionActive", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtDetails.Rows)
                {
                    sTotal = dr["TOTAL_REC"].ToString();
                    iTotal = Convert.ToInt32(sTotal);
                }
            }

            if (iTotal == 0)
                ifOK = true;    //RPT_ID is not active yet in E-Submissions

            return ifOK;
        }

        //megatshamsul - 20170314 - SR1363674 - update frequency weekly
        //public static string fnUpdateETemplateDetails(string Update_Type, string Status_Id_Prev, string Status_Id_Next, DataTable dtCodeDetails, DataTable dtCodeDetailsAdhoc, string strUserId, ref bool ifSuccess)
        public static string fnUpdateETemplateDetails(string Update_Type, string Status_Id_Prev, string Status_Id_Next, DataTable dtCodeDetails, DataTable dtCodeDetailsAdhoc, DataTable dtCodeDetailsWeekly, string strUserId, ref bool ifSuccess)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            if (Update_Type == "I")
                isOK = true;
            else
            {
                SqlParameter parmRowNum = new SqlParameter();
                parmRowNum.ParameterName = "@ROW_NUM";
                parmRowNum.DbType = DbType.String;
                parmRowNum.Value = dtCodeDetails.Rows[0]["ROW_NUM"].ToString();

                SqlParameter parmRptId = new SqlParameter();
                parmRptId.ParameterName = "@RPT_ID";
                parmRptId.DbType = DbType.String;
                parmRptId.Value = dtCodeDetails.Rows[0]["RPT_ID"].ToString();
                
                SqlParameterList.Add(parmRowNum);
                SqlParameterList.Add(parmRptId);

                //to check if record still intact
                DataTable dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetETemplateStatus", SqlParameterList, strUserId);

                if (dtDetails.Rows.Count > 0)
                {
                    foreach (DataRow drUnit in dtDetails.Rows)
                    {
                        if (drUnit["STATUS_ID"].ToString() == Status_Id_Prev)
                            isOK = true;
                        else
                            strMessage = "Record has been changed. Please try again.";
                    }
                }
            }

            if (isOK)
            {
                SqlParameterList = new List<SqlParameter>();

                SqlParameter parm1 = new SqlParameter();
                parm1.ParameterName = "@UPDATE_TYPE";
                parm1.DbType = DbType.String;
                parm1.Value = Update_Type;

                SqlParameter parm2 = new SqlParameter();
                parm2.ParameterName = "@STATUS_ID_PREV";
                parm2.DbType = DbType.String;
                parm2.Value = Status_Id_Prev;

                SqlParameter parm3 = new SqlParameter();
                parm3.ParameterName = "@STATUS_ID_NEXT";
                parm3.DbType = DbType.String;
                parm3.Value = Status_Id_Next;

                SqlParameter parm4 = new SqlParameter();
                parm4.ParameterName = "@DATA_DETAILS";
                parm4.SqlDbType = SqlDbType.Structured;
                parm4.Value = dtCodeDetails;

                SqlParameter parm5 = new SqlParameter();
                parm5.ParameterName = "@DATA_DETAILS_ADHOC";
                parm5.SqlDbType = SqlDbType.Structured;
                parm5.Value = dtCodeDetailsAdhoc;

                SqlParameter parm6 = new SqlParameter();
                parm6.ParameterName = "@PREPARER_ID";
                parm6.DbType = DbType.String;
                parm6.Value = strUserId;

                //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                SqlParameter parm7 = new SqlParameter();
                parm7.ParameterName = "@DATA_DETAILS_WEEKLY";
                parm7.SqlDbType = SqlDbType.Structured;
                parm7.Value = dtCodeDetailsWeekly;

                SqlParameterList.Add(parm1);
                SqlParameterList.Add(parm2);
                SqlParameterList.Add(parm3);
                SqlParameterList.Add(parm4);
                SqlParameterList.Add(parm5);
                SqlParameterList.Add(parm6);

                //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                SqlParameterList.Add(parm7);

                isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspUpdateETemplateDetails", SqlParameterList, strUserId);
                ifSuccess = isOK;

                if (isOK)
                {
                    if (Status_Id_Next == "D1" || Status_Id_Next == "D2" || Status_Id_Next == "D3")
                        strMessage = "Draft created successfully. Please submit for approval.";
                    else if (Status_Id_Next == "N")
                        strMessage = "Data inserted successfully. Pending for approval.";
                    else if (Status_Id_Next == "U")
                        strMessage = "Data updated successfully. Pending for approval.";
                    else if (Status_Id_Next == "XR")
                        strMessage = "Data discontinued successfully. Pending for approval.";
                }
                else
                {
                    if (Update_Type == "I")
                        strMessage = "Failed to insert Details";
                    else if (Update_Type == "U")
                        strMessage = "Failed to update Details";
                    else if (Update_Type == "D")
                        strMessage = "Failed to discontinue Details";
                }
            }

            return strMessage;
        }

        public static string fnApproveETemplate(string Action_Type, string Rpt_Id, string Status_Id, string Row_Num, string strRejectReason, string strUserId, string strRoleId, ref bool ifSuccess)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parmRowNum = new SqlParameter();
            parmRowNum.ParameterName = "@ROW_NUM";
            parmRowNum.DbType = DbType.String;
            parmRowNum.Value = Row_Num;

            SqlParameter parmRptId = new SqlParameter();
            parmRptId.ParameterName = "@RPT_ID";
            parmRptId.DbType = DbType.String;
            parmRptId.Value = Rpt_Id;

            SqlParameterList.Add(parmRowNum);
            SqlParameterList.Add(parmRptId);

            //to check if record still intact
            DataTable dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetETemplateStatus", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow drUnit in dtDetails.Rows)
                {
                    if (drUnit["STATUS_ID"].ToString() == Status_Id)
                        isOK = true;
                    else
                        strMessage = "Record has been changed. Please try again.";
                }
            }

            if (isOK)
            {
                SqlParameterList = new List<SqlParameter>();

                SqlParameter parm1 = new SqlParameter();
                parm1.ParameterName = "@ACTION_TYPE";
                parm1.DbType = DbType.String;
                parm1.Value = Action_Type;

                SqlParameter parm2 = new SqlParameter();
                parm2.ParameterName = "@RPT_ID";
                parm2.DbType = DbType.String;
                parm2.Value = Rpt_Id;

                SqlParameter parm3 = new SqlParameter();
                parm3.ParameterName = "@STATUS_ID";
                parm3.DbType = DbType.String;
                parm3.Value = Status_Id;

                SqlParameter parm4 = new SqlParameter();
                parm4.ParameterName = "@ROW_NUM";
                parm4.DbType = DbType.String;
                parm4.Value = Row_Num;

                SqlParameter parm5 = new SqlParameter();
                parm5.ParameterName = "@REJECT_REASON";
                parm5.DbType = DbType.String;
                parm5.Value = strRejectReason;

                SqlParameter parm6 = new SqlParameter();
                parm6.ParameterName = "@APPROVER_ID";
                parm6.DbType = DbType.String;
                parm6.Value = strUserId;

                SqlParameter parm7 = new SqlParameter();
                parm7.ParameterName = "@ROLE_ID";
                parm7.DbType = DbType.String;
                parm7.Value = strRoleId;

                SqlParameterList.Add(parm1);
                SqlParameterList.Add(parm2);
                SqlParameterList.Add(parm3);
                SqlParameterList.Add(parm4);
                SqlParameterList.Add(parm5);
                SqlParameterList.Add(parm6);
                SqlParameterList.Add(parm7);

                isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspApproveETemplateDetails", SqlParameterList, strUserId);
                ifSuccess = isOK;

                if (isOK)
                {
                    if (Status_Id == "N" || Status_Id == "U" || Status_Id == "XR")
                    {
                        if (Action_Type == "A")
                            strMessage = "Data approved successfully. Pending for FGT approval.";
                        else if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                    else if (Status_Id == "AP1" || Status_Id == "APX1")
                    {
                        if (Action_Type == "A")
                            strMessage = "Data approved successfully.";
                        else if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                    else if (Status_Id == "AP2")    //only FGT can reject an approved rec
                    {
                        if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                }
                else
                {
                    if (Action_Type == "A")
                        strMessage = "Failed to approve Details";
                    else if (Action_Type == "R")
                        strMessage = "Failed to reject Details";
                }
            }

            return strMessage;
        }

        public static bool fnRegenESubmissions(string Action_Type, string Row_Num, string Rpt_Id, string strUserId, string strEFF_POSITION_DATE, string strEXP_POSITION_DATE)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            string sNoOfSet = ConfigurationManager.AppSettings["DEFAULT_ESUBMISSION_TOTAL_SET"].ToString();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ACTION_TYPE";
            parm1.DbType = DbType.String;
            parm1.Value = Action_Type;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@ROW_NUM";
            parm2.DbType = DbType.String;
            parm2.Value = Row_Num;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@RPT_ID";
            parm3.DbType = DbType.String;
            parm3.Value = Rpt_Id;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@APPROVER_ID";
            parm4.DbType = DbType.String;
            parm4.Value = strUserId;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@NO_OF_SET";
            parm5.DbType = DbType.String;
            parm5.Value = sNoOfSet;

            SqlParameter parm6 = new SqlParameter();
            parm6.ParameterName = "@EFF_POSITION_DATE";
            parm6.DbType = DbType.String;
            //parm6.Value = SetYYYYMMDD(strEFF_POSITION_DATE);
            parm6.Value = SetYYYYMMDD(GetDDMMYYYY(DateTime.Now));   //to start regen from today onwards

            SqlParameter parm7 = new SqlParameter();
            parm7.ParameterName = "@EXP_POSITION_DATE";
            parm7.DbType = DbType.String;
            parm7.Value = SetYYYYMMDD(strEXP_POSITION_DATE);

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);
            SqlParameterList.Add(parm6);
            SqlParameterList.Add(parm7);

            isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspRegenESubmissions", SqlParameterList, strUserId);

            return isOK;
        }

        #endregion

        #region E-Submission Maintenance Functions

        public static DataTable fnLoadCategoryIssueCode(string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListCategoryIssue", new List<SqlParameter>(), strUserId);

            return dtDetails;
        }

        public static DataTable fnListESubmissions(string strSearchRptId, string strSearchRptName, string strSearchRegulatorId, string strSearchSREF, string strSearchFrequencyId, bool bFilterStatusAll, bool bFilterStatusDraft, bool bFilterStatusNew, bool bFilterStatusApproved, bool bFilterStatusRejected, bool bFilterStatusPendingApproval, bool bFilterStatusDue, bool bFilterStatusPastDue, string strSearchFromDate, string strSearchToDate, string strUserId, string strUnitId, string strRoleId, bool ifExport, bool ifReject)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@RPT_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSearchRptId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@RPT_NAME";
            parm3.DbType = DbType.String;
            parm3.Value = strSearchRptName;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@REGULATOR_ID";
            parm4.DbType = DbType.String;
            parm4.Value = strSearchRegulatorId;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@SREF";
            parm5.DbType = DbType.String;
            parm5.Value = strSearchSREF;

            SqlParameter parm6 = new SqlParameter();
            parm6.ParameterName = "@FREQUENCY_ID";
            parm6.DbType = DbType.String;
            parm6.Value = strSearchFrequencyId;

            SqlParameter parm7 = new SqlParameter();
            parm7.ParameterName = "@STATUS_ALL";
            parm7.DbType = DbType.String;

            if (bFilterStatusAll)
                parm7.Value = "1";
            else
                parm7.Value = "0";

            SqlParameter parm8 = new SqlParameter();
            parm8.ParameterName = "@STATUS_DRAFT";
            parm8.DbType = DbType.String;

            if (bFilterStatusDraft)
                parm8.Value = "1";
            else
                parm8.Value = "0";

            SqlParameter parm9 = new SqlParameter();
            parm9.ParameterName = "@STATUS_NEW";
            parm9.DbType = DbType.String;

            if (bFilterStatusNew)
                parm9.Value = "1";
            else
                parm9.Value = "0";

            SqlParameter parm10 = new SqlParameter();
            parm10.ParameterName = "@STATUS_APP";
            parm10.DbType = DbType.String;

            if (bFilterStatusApproved)
                parm10.Value = "1";
            else
                parm10.Value = "0";

            SqlParameter parm11 = new SqlParameter();
            parm11.ParameterName = "@STATUS_REJ";
            parm11.DbType = DbType.String;

            if (bFilterStatusRejected)
                parm11.Value = "1";
            else
                parm11.Value = "0";

            SqlParameter parm12 = new SqlParameter();
            parm12.ParameterName = "@STATUS_PA";
            parm12.DbType = DbType.String;

            if (bFilterStatusPendingApproval)
                parm12.Value = "1";
            else
                parm12.Value = "0";

            SqlParameter parm13 = new SqlParameter();
            parm13.ParameterName = "@FROM_DATE";
            parm13.DbType = DbType.String;
            parm13.Value = strSearchFromDate;

            SqlParameter parm14 = new SqlParameter();
            parm14.ParameterName = "@TO_DATE";
            parm14.DbType = DbType.String;
            parm14.Value = strSearchToDate;

            SqlParameter parm15 = new SqlParameter();
            parm15.ParameterName = "@IF_REJECT";
            parm15.DbType = DbType.String;

            if (ifReject && !ifExport)
                parm15.Value = "1";
            else
                parm15.Value = "0";

            SqlParameter parm16 = new SqlParameter();
            parm16.ParameterName = "@ROLE_ID";
            parm16.DbType = DbType.String;
            parm16.Value = strRoleId;

            SqlParameter parm17 = new SqlParameter();
            parm17.ParameterName = "@STATUS_DUE";
            parm17.DbType = DbType.String;

            if (bFilterStatusDue)
                parm17.Value = "1";
            else
                parm17.Value = "0";

            SqlParameter parm18 = new SqlParameter();
            parm18.ParameterName = "@STATUS_PASTDUE";
            parm18.DbType = DbType.String;

            if (bFilterStatusPastDue)
                parm18.Value = "1";
            else
                parm18.Value = "0";

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);
            SqlParameterList.Add(parm6);
            SqlParameterList.Add(parm7);
            SqlParameterList.Add(parm8);
            SqlParameterList.Add(parm9);
            SqlParameterList.Add(parm10);
            SqlParameterList.Add(parm11);
            SqlParameterList.Add(parm12);
            SqlParameterList.Add(parm13);
            SqlParameterList.Add(parm14);
            SqlParameterList.Add(parm15);
            SqlParameterList.Add(parm16);
            SqlParameterList.Add(parm17);
            SqlParameterList.Add(parm18);

            if (ifExport)
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListESubmissionsAll", SqlParameterList, strUserId);
            else
                dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspListESubmissions", SqlParameterList, strUserId);

            return dtDetails;
        }

        public static DataTable fnGetESubmissionDetails(string strSubmissionId, string strStatusId, string strROW_NUM, string strUnitId, string strUserId, string strRoleId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@UNIT_ID";
            parm1.DbType = DbType.String;
            parm1.Value = strUnitId;

            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@SUBMISSION_ID";
            parm2.DbType = DbType.String;
            parm2.Value = strSubmissionId;

            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@STATUS_ID";
            parm3.DbType = DbType.String;
            parm3.Value = strStatusId;

            SqlParameter parm4 = new SqlParameter();
            parm4.ParameterName = "@ROW_NUM";
            parm4.DbType = DbType.String;
            parm4.Value = strROW_NUM;

            SqlParameter parm5 = new SqlParameter();
            parm5.ParameterName = "@ROLE_ID";
            parm5.DbType = DbType.String;
            parm5.Value = strRoleId;

            SqlParameterList.Add(parm1);
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);
            SqlParameterList.Add(parm4);
            SqlParameterList.Add(parm5);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetESubmission", SqlParameterList, strUserId);

            return dtDetails;
        }

        //megatshamsul - 20170317 - SR1363674 - new Resubmission fields
        public static DataTable fnGetESubmissionResubmissionDetails(string strROW_NUM, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ROW_NUM";
            parm1.DbType = DbType.String;
            parm1.Value = strROW_NUM;

            SqlParameterList.Add(parm1);
            
            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetESubmissionResubmission", SqlParameterList, strUserId);

            return dtDetails;
        }

        //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
        //public static DataTable fnLoadESubmissionAttachment(string strRowNum, string strUserId)
        public static DataTable fnLoadESubmissionAttachment(string strRowNum, string sAttachType, string sRecNo, string strUserId)
        {
            DataTable dtDetails = new DataTable();
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();

            SqlParameter parm1 = new SqlParameter();
            parm1.ParameterName = "@ROW_NUM";
            parm1.DbType = DbType.String;
            parm1.Value = strRowNum;

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
            SqlParameter parm2 = new SqlParameter();
            parm2.ParameterName = "@ATTACH_TYPE";
            parm2.DbType = DbType.String;
            parm2.Value = sAttachType;

            //megatshamsul - 20170317 - SR1363674 - add resubmission attachments no
            SqlParameter parm3 = new SqlParameter();
            parm3.ParameterName = "@REC_NO";
            parm3.DbType = DbType.String;
            parm3.Value = sRecNo;

            SqlParameterList.Add(parm1);

            //megatshamsul - 20170317 - SR1363674 - add JUSTIFICATION ATTACHMENT + resubmission attachments
            SqlParameterList.Add(parm2);
            SqlParameterList.Add(parm3);

            dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetESubmissionAttachment", SqlParameterList, strUserId);

            return dtDetails;
        }

        //megatshamsul - 20170321 - SR1363674 - new field justification attachment + resubmission details & attachment
        //public static string fnUpdateESubmissionDetails(string Update_Type, string Status_Id_Prev, string Status_Id_Next, DataTable dtCodeDetails, FileUpload fuEXTENDED_ATTACHMENT, string sRMV_ATTACHMENT, string strUserId, ref bool ifSuccess)
        public static string fnUpdateESubmissionDetails(string Update_Type, string Status_Id_Prev, string Status_Id_Next, DataTable dtCodeDetails, DataTable dtCodeDetailsResubmission, FileUpload fuEXTENDED_ATTACHMENT, string sRMV_ATTACHMENT, FileUpload fuJUSTIFICATION_ATTACHMENT, string sRMV_JUSTIFICATION_ATTACHMENT, FileUpload fuRESUBMISSION_ATTACHMENT_1, string sRMV_RESUBMISSION_ATTACHMENT_1, FileUpload fuRESUBMISSION_ATTACHMENT_2, string sRMV_RESUBMISSION_ATTACHMENT_2, FileUpload fuRESUBMISSION_ATTACHMENT_3, string sRMV_RESUBMISSION_ATTACHMENT_3, FileUpload fuRESUBMISSION_ATTACHMENT_4, string sRMV_RESUBMISSION_ATTACHMENT_4, FileUpload fuRESUBMISSION_ATTACHMENT_5, string sRMV_RESUBMISSION_ATTACHMENT_5, string strUserId, ref bool ifSuccess)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parmRowNum = new SqlParameter();
            parmRowNum.ParameterName = "@ROW_NUM";
            parmRowNum.DbType = DbType.String;
            parmRowNum.Value = dtCodeDetails.Rows[0]["ROW_NUM"].ToString();

            SqlParameter parmRptId = new SqlParameter();
            parmRptId.ParameterName = "@SUBMISSION_ID";
            parmRptId.DbType = DbType.String;
            parmRptId.Value = dtCodeDetails.Rows[0]["SUBMISSION_ID"].ToString();

            SqlParameterList.Add(parmRowNum);
            SqlParameterList.Add(parmRptId);

            //to check if record still intact
            DataTable dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetESubmissionStatus", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow drUnit in dtDetails.Rows)
                {
                    if (drUnit["STATUS_ID"].ToString() == Status_Id_Prev)
                        isOK = true;
                    else
                        strMessage = "Record has been changed. Please try again.";
                }
            }

            if (isOK)
            {
                SqlParameterList = new List<SqlParameter>();

                SqlParameter parm1 = new SqlParameter();
                parm1.ParameterName = "@UPDATE_TYPE";
                parm1.DbType = DbType.String;
                parm1.Value = Update_Type;

                SqlParameter parm2 = new SqlParameter();
                parm2.ParameterName = "@STATUS_ID_PREV";
                parm2.DbType = DbType.String;
                parm2.Value = Status_Id_Prev;

                SqlParameter parm3 = new SqlParameter();
                parm3.ParameterName = "@STATUS_ID_NEXT";
                parm3.DbType = DbType.String;
                parm3.Value = Status_Id_Next;

                SqlParameter parm4 = new SqlParameter();
                parm4.ParameterName = "@DATA_DETAILS";
                parm4.SqlDbType = SqlDbType.Structured;
                parm4.Value = dtCodeDetails;

                SqlParameter parm5 = new SqlParameter();
                parm5.ParameterName = "@EXTENDED_ATTACHMENT_DATA";
                parm5.SqlDbType = SqlDbType.VarBinary;

                byte[] bImage = new byte[fuEXTENDED_ATTACHMENT.PostedFile.ContentLength];
                Stream objStream = fuEXTENDED_ATTACHMENT.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuEXTENDED_ATTACHMENT.PostedFile.ContentLength);

                parm5.Value = bImage;

                SqlParameter parm6 = new SqlParameter();
                parm6.ParameterName = "@RMV_ATTACHMENT";
                parm6.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_ATTACHMENT = "0";
                else if (bImage.Length == 0 && sRMV_ATTACHMENT == "1")
                    sRMV_ATTACHMENT = "1";
                else if (bImage.Length == 0 && sRMV_ATTACHMENT == "0")
                    sRMV_ATTACHMENT = "2";  

                parm6.Value = sRMV_ATTACHMENT;

                SqlParameter parm7 = new SqlParameter();
                parm7.ParameterName = "@PREPARER_ID";
                parm7.DbType = DbType.String;
                parm7.Value = strUserId;

                //megatshamsul - 20170321 - SR1363674 - new field justification attachment
                SqlParameter parm8 = new SqlParameter();
                parm8.ParameterName = "@JUSTIFICATION_ATTACHMENT_DATA";
                parm8.SqlDbType = SqlDbType.VarBinary;

                //megatshamsul - 20170321 - SR1363674 - new field justification attachment
                bImage = new byte[fuJUSTIFICATION_ATTACHMENT.PostedFile.ContentLength];
                objStream = fuJUSTIFICATION_ATTACHMENT.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuJUSTIFICATION_ATTACHMENT.PostedFile.ContentLength);
                parm8.Value = bImage;

                //megatshamsul - 20170321 - SR1363674 - new field justification attachment
                SqlParameter parm9 = new SqlParameter();
                parm9.ParameterName = "@RMV_JUSTIFICATION_ATTACHMENT";
                parm9.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_JUSTIFICATION_ATTACHMENT = "0";
                else if (bImage.Length == 0 && sRMV_JUSTIFICATION_ATTACHMENT == "1")
                    sRMV_JUSTIFICATION_ATTACHMENT = "1";
                else if (bImage.Length == 0 && sRMV_JUSTIFICATION_ATTACHMENT == "0")
                    sRMV_JUSTIFICATION_ATTACHMENT = "2"; 

                parm9.Value = sRMV_JUSTIFICATION_ATTACHMENT;

                //megatshamsul - 20170321 - SR1363674 - resubmission details
                SqlParameter parm10 = new SqlParameter();
                parm10.ParameterName = "@DATA_RESUBMISSION_DETAILS";
                parm10.SqlDbType = SqlDbType.Structured;
                parm10.Value = dtCodeDetailsResubmission;

                //megatshamsul - 20170321 - SR1363674 - resubmission attachments
                #region Resubmission Attachments

                SqlParameter parm11 = new SqlParameter();
                parm11.ParameterName = "@RESUBMISSION_ATTACHMENT_1_DATA";
                parm11.SqlDbType = SqlDbType.VarBinary;

                bImage = new byte[fuRESUBMISSION_ATTACHMENT_1.PostedFile.ContentLength];
                objStream = fuRESUBMISSION_ATTACHMENT_1.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuRESUBMISSION_ATTACHMENT_1.PostedFile.ContentLength);
                parm11.Value = bImage;

                SqlParameter parm12 = new SqlParameter();
                parm12.ParameterName = "@RMV_RESUBMISSION_ATTACHMENT_1";
                parm12.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_RESUBMISSION_ATTACHMENT_1 = "0";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_1 == "1")
                    sRMV_RESUBMISSION_ATTACHMENT_1 = "1";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_1 == "0")
                    sRMV_RESUBMISSION_ATTACHMENT_1 = "2";

                parm12.Value = sRMV_RESUBMISSION_ATTACHMENT_1;

                SqlParameter parm13 = new SqlParameter();
                parm13.ParameterName = "@RESUBMISSION_ATTACHMENT_2_DATA";
                parm13.SqlDbType = SqlDbType.VarBinary;

                bImage = new byte[fuRESUBMISSION_ATTACHMENT_2.PostedFile.ContentLength];
                objStream = fuRESUBMISSION_ATTACHMENT_2.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuRESUBMISSION_ATTACHMENT_2.PostedFile.ContentLength);
                parm13.Value = bImage;

                SqlParameter parm14 = new SqlParameter();
                parm14.ParameterName = "@RMV_RESUBMISSION_ATTACHMENT_2";
                parm14.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_RESUBMISSION_ATTACHMENT_2 = "0";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_2 == "1")
                    sRMV_RESUBMISSION_ATTACHMENT_2 = "1";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_2 == "0")
                    sRMV_RESUBMISSION_ATTACHMENT_2 = "2";

                parm14.Value = sRMV_RESUBMISSION_ATTACHMENT_2;

                SqlParameter parm15 = new SqlParameter();
                parm15.ParameterName = "@RESUBMISSION_ATTACHMENT_3_DATA";
                parm15.SqlDbType = SqlDbType.VarBinary;

                bImage = new byte[fuRESUBMISSION_ATTACHMENT_3.PostedFile.ContentLength];
                objStream = fuRESUBMISSION_ATTACHMENT_3.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuRESUBMISSION_ATTACHMENT_3.PostedFile.ContentLength);
                parm15.Value = bImage;

                SqlParameter parm16 = new SqlParameter();
                parm16.ParameterName = "@RMV_RESUBMISSION_ATTACHMENT_3";
                parm16.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_RESUBMISSION_ATTACHMENT_3 = "0";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_3 == "1")
                    sRMV_RESUBMISSION_ATTACHMENT_3 = "1";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_3 == "0")
                    sRMV_RESUBMISSION_ATTACHMENT_3 = "2";

                parm16.Value = sRMV_RESUBMISSION_ATTACHMENT_3;

                SqlParameter parm17 = new SqlParameter();
                parm17.ParameterName = "@RESUBMISSION_ATTACHMENT_4_DATA";
                parm17.SqlDbType = SqlDbType.VarBinary;

                bImage = new byte[fuRESUBMISSION_ATTACHMENT_4.PostedFile.ContentLength];
                objStream = fuRESUBMISSION_ATTACHMENT_4.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuRESUBMISSION_ATTACHMENT_4.PostedFile.ContentLength);
                parm17.Value = bImage;

                SqlParameter parm18 = new SqlParameter();
                parm18.ParameterName = "@RMV_RESUBMISSION_ATTACHMENT_4";
                parm18.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_RESUBMISSION_ATTACHMENT_4 = "0";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_4 == "1")
                    sRMV_RESUBMISSION_ATTACHMENT_4 = "1";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_4 == "0")
                    sRMV_RESUBMISSION_ATTACHMENT_4 = "2";

                parm18.Value = sRMV_RESUBMISSION_ATTACHMENT_4;

                SqlParameter parm19 = new SqlParameter();
                parm19.ParameterName = "@RESUBMISSION_ATTACHMENT_5_DATA";
                parm19.SqlDbType = SqlDbType.VarBinary;

                bImage = new byte[fuRESUBMISSION_ATTACHMENT_5.PostedFile.ContentLength];
                objStream = fuRESUBMISSION_ATTACHMENT_5.PostedFile.InputStream;
                objStream.Read(bImage, 0, fuRESUBMISSION_ATTACHMENT_5.PostedFile.ContentLength);
                parm19.Value = bImage;

                SqlParameter parm20 = new SqlParameter();
                parm20.ParameterName = "@RMV_RESUBMISSION_ATTACHMENT_5";
                parm20.DbType = DbType.String;

                if (bImage.Length > 0)
                    sRMV_RESUBMISSION_ATTACHMENT_5 = "0";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_5 == "1")
                    sRMV_RESUBMISSION_ATTACHMENT_5 = "1";
                else if (bImage.Length == 0 && sRMV_RESUBMISSION_ATTACHMENT_5 == "0")
                    sRMV_RESUBMISSION_ATTACHMENT_5 = "2";

                parm20.Value = sRMV_RESUBMISSION_ATTACHMENT_5;

                #endregion

                SqlParameterList.Add(parm1);
                SqlParameterList.Add(parm2);
                SqlParameterList.Add(parm3);
                SqlParameterList.Add(parm4);
                SqlParameterList.Add(parm5);
                SqlParameterList.Add(parm6);
                SqlParameterList.Add(parm7);

                //megatshamsul - 20170321 - SR1363674 - new field justification attachment + resubmission details
                SqlParameterList.Add(parm8);
                SqlParameterList.Add(parm9);
                SqlParameterList.Add(parm10);

                //megatshamsul - 20170321 - SR1363674 - resubmission attachments
                SqlParameterList.Add(parm11);
                SqlParameterList.Add(parm12);
                SqlParameterList.Add(parm13);
                SqlParameterList.Add(parm14);
                SqlParameterList.Add(parm15);
                SqlParameterList.Add(parm16);
                SqlParameterList.Add(parm17);
                SqlParameterList.Add(parm18);
                SqlParameterList.Add(parm19);
                SqlParameterList.Add(parm20);

                isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspUpdateESubmissionDetails", SqlParameterList, strUserId);
                ifSuccess = isOK;

                if (isOK)
                {
                    if (Status_Id_Next == "D1" || Status_Id_Next == "D2" || Status_Id_Next == "D3")
                        strMessage = "Draft created successfully. Please submit for approval.";
                    else if (Status_Id_Next == "N")
                        strMessage = "Data inserted successfully. Pending for approval.";
                    else if (Status_Id_Next == "U")
                        strMessage = "Data updated successfully. Pending for approval.";
                    else if (Status_Id_Next == "XR")
                        strMessage = "Data discontinued successfully. Pending for approval.";
                }
                else
                {
                    if (Update_Type == "I")
                        strMessage = "Failed to insert Details";
                    else if (Update_Type == "U")
                        strMessage = "Failed to update Details";
                    else if (Update_Type == "D")
                        strMessage = "Failed to discontinue Details";
                }
            }

            return strMessage;
        }

        //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
        //public static string fnApproveESubmission(string Action_Type, string Submission_Id, string Status_Id, string Row_Num, string strRejectReason, string strUserId, string strRoleId, ref bool ifSuccess)
        public static string fnApproveESubmission(string Action_Type, string Submission_Id, string Status_Id, string Row_Num, string strRejectReason, string strCompliance, string strUserId, string strRoleId, ref bool ifSuccess)
        {
            bool isOK = false;
            DataClass ObjDataClass = new DataClass();
            List<SqlParameter> SqlParameterList = new List<SqlParameter>();
            string strMessage = string.Empty;

            SqlParameter parmRowNum = new SqlParameter();
            parmRowNum.ParameterName = "@ROW_NUM";
            parmRowNum.DbType = DbType.String;
            parmRowNum.Value = Row_Num;

            SqlParameter parmRptId = new SqlParameter();
            parmRptId.ParameterName = "@SUBMISSION_ID";
            parmRptId.DbType = DbType.String;
            parmRptId.Value = Submission_Id;

            SqlParameterList.Add(parmRowNum);
            SqlParameterList.Add(parmRptId);

            //to check if record still intact
            DataTable dtDetails = ObjDataClass.fnReturnDataTable("P", "dbo.uspGetESubmissionStatus", SqlParameterList, strUserId);

            if (dtDetails.Rows.Count > 0)
            {
                foreach (DataRow drUnit in dtDetails.Rows)
                {
                    if (drUnit["STATUS_ID"].ToString() == Status_Id)
                        isOK = true;
                    else
                        strMessage = "Record has been changed. Please try again.";
                }
            }

            if (isOK)
            {
                SqlParameterList = new List<SqlParameter>();

                SqlParameter parm1 = new SqlParameter();
                parm1.ParameterName = "@ACTION_TYPE";
                parm1.DbType = DbType.String;
                parm1.Value = Action_Type;

                SqlParameter parm2 = new SqlParameter();
                parm2.ParameterName = "@SUBMISSION_ID";
                parm2.DbType = DbType.String;
                parm2.Value = Submission_Id;

                SqlParameter parm3 = new SqlParameter();
                parm3.ParameterName = "@STATUS_ID";
                parm3.DbType = DbType.String;
                parm3.Value = Status_Id;

                SqlParameter parm4 = new SqlParameter();
                parm4.ParameterName = "@ROW_NUM";
                parm4.DbType = DbType.String;
                parm4.Value = Row_Num;

                SqlParameter parm5 = new SqlParameter();
                parm5.ParameterName = "@REJECT_REASON";
                parm5.DbType = DbType.String;
                parm5.Value = strRejectReason;

                SqlParameter parm6 = new SqlParameter();
                parm6.ParameterName = "@APPROVER_ID";
                parm6.DbType = DbType.String;
                parm6.Value = strUserId;

                SqlParameter parm7 = new SqlParameter();
                parm7.ParameterName = "@ROLE_ID";
                parm7.DbType = DbType.String;
                parm7.Value = strRoleId;

                //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
                SqlParameter parm8 = new SqlParameter();
                parm8.ParameterName = "@COMPLIANCE";
                parm8.DbType = DbType.String;
                parm8.Value = strCompliance;

                SqlParameterList.Add(parm1);
                SqlParameterList.Add(parm2);
                SqlParameterList.Add(parm3);
                SqlParameterList.Add(parm4);
                SqlParameterList.Add(parm5);
                SqlParameterList.Add(parm6);
                SqlParameterList.Add(parm7);

                //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
                SqlParameterList.Add(parm8);

                isOK = ObjDataClass.fnExecuteNonQuery("P", "dbo.uspApproveESubmissionDetails", SqlParameterList, strUserId);
                ifSuccess = isOK;

                if (isOK)
                {
                    if (Status_Id == "N" || Status_Id == "U" || Status_Id == "XR")
                    {
                        if (Action_Type == "A")
                        {
                            //megatshamsul - 20170323 - SR1363674 - set STATUS_ID 'AP2' if COMPLIANCE='Y'
                            //strMessage = "Data approved successfully. Pending for FGT approval.";
                            if (strCompliance == "Y")
                                strMessage = "Data approved successfully.";
                            else
                                strMessage = "Data approved successfully. Pending for FGT approval.";
                        }
                        else if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                    else if (Status_Id == "AP1" || Status_Id == "APX1")
                    {
                        if (Action_Type == "A")
                            strMessage = "Data approved successfully.";
                        else if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                    else if (Status_Id == "AP2")    //only FGT can reject an approved rec
                    {
                        if (Action_Type == "R")
                            strMessage = "Data rejected successfully.";
                    }
                }
                else
                {
                    if (Action_Type == "A")
                        strMessage = "Failed to approve Details";
                    else if (Action_Type == "R")
                        strMessage = "Failed to reject Details";
                }
            }

            return strMessage;
        }

        #endregion
    }
}