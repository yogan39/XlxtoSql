﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RRFGUI.Library;
using System.Data;
using System.Configuration;

namespace RRFGUI
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //txtbxLoginName.Text = "10024079B";
            //txtbxPassword.Text = "123";

            if (!IsPostBack)
            {
                string IsSessionExpire = Request.QueryString["IsSessionExpire"];

                if (!string.IsNullOrEmpty(IsSessionExpire))
                {
                    Response.Write("<script language=javascript>alert('Session Expired. Kindly relogin to application.');</script>");
                }

                txtbxLoginName.Focus();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Write("<script language='javascript'> { window.close(); }</script>");
        }

        protected void btnEnter_Click(object sender, EventArgs e)
        {
            string strIpAddress = string.Empty;
            string strUserValidation = string.Empty;

            strIpAddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (string.IsNullOrEmpty(strIpAddress))
                strIpAddress = Request.ServerVariables["REMOTE_ADDR"];

            string strClientIPAddress = string.Empty;
            string strHostName = string.Empty;

            if (strIpAddress == "127.0.0.1")
            {
                strHostName = System.Net.Dns.GetHostName();
                strClientIPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();
                strIpAddress = strClientIPAddress;
            }

            if (string.IsNullOrEmpty(txtbxLoginName.Text))
            {
                BusinessLogicClass.ShowMessage("Enter the Login Name");
                return;
            }
            else if (string.IsNullOrEmpty(txtbxPassword.Text))
            {
                BusinessLogicClass.ShowMessage("Enter the Password");
                return;
            }
            else if (string.IsNullOrEmpty(ddlDomainName.SelectedValue))
            {
                BusinessLogicClass.ShowMessage("Select the Domain");
                return;
            }
            else if (Session.Count > 2)
            {
                BusinessLogicClass.ShowMessage("Session is already logged in. Kindly Logoff the session and try again.");
                return;
            }
            else
            {
                if (ConfigurationManager.AppSettings["AD_AUTHENTICATION"].ToString() == "ON")
                    strUserValidation = BusinessLogicClass.fnValidateUserIdPassword(txtbxLoginName.Text, txtbxPassword.Text, ddlDomainName.SelectedValue, Session.SessionID, strIpAddress);
            }

            if (!string.IsNullOrEmpty(strUserValidation))
            {
                int LoginAttempts = Convert.ToInt32(Session["Login"]);

                BusinessLogicClass.ShowMessage(strUserValidation);

                string strLoggedUserId = string.Empty;

                if (Session["AlreadyLoggedUser"] != null)
                    strLoggedUserId = Session["AlreadyLoggedUser"].ToString();

                if (txtbxLoginName.Text == strLoggedUserId)
                {
                    LoginAttempts++;
                    Session["Login"] = LoginAttempts;
                }
                else
                {
                    Session["Login"] = 1;
                    Session["AlreadyLoggedUser"] = txtbxLoginName.Text;
                }

                if (LoginAttempts == 3)
                {
                    BusinessLogicClass.fnLockUserLanID(txtbxLoginName.Text, ddlDomainName.SelectedValue);
                    BusinessLogicClass.ShowMessage("User Id is locked out. Kindly contact Administrator");
                }

                return;
            }
            else
            {
                if (Session.Count > 2)
                {
                    BusinessLogicClass.ShowMessage("Session is already logged in. Kindly Logoff the session and try again.");
                    return;
                }
                else
                {
                    Session["Login"] = 0;
                    fnLoadSessionObjects();
                    BusinessLogicClass.fnUpdateUserStatusforLoginAndLogOut("Y", txtbxLoginName.Text, ddlDomainName.SelectedValue, strIpAddress);
                    Response.Redirect("~/Welcome.aspx?userID=" + Session["strUserId"]);
                }
            }
        }

        public void fnLoadSessionObjects()
        {
            string strIpAddress = string.Empty;
            string strClientIPAddress = string.Empty;
            string strHostName = string.Empty;

            strIpAddress = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (string.IsNullOrEmpty(strIpAddress))
                strIpAddress = Request.ServerVariables["REMOTE_ADDR"];

            if (strIpAddress == "127.0.0.1")
            {
                strHostName = System.Net.Dns.GetHostName();
                strClientIPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();
                strIpAddress = strClientIPAddress;
            }

            Session["strUserId"] = txtbxLoginName.Text;
            Session["strDomainName"] = ddlDomainName.SelectedValue;
            Session["ClientIPAddress"] = strIpAddress;

            Session["dtAccessControll"] = BusinessLogicClass.fnLoadRoleToSession(txtbxLoginName.Text, ddlDomainName.SelectedValue);
            Session["MenuGroup"] = BusinessLogicClass.fnGetMenuGroup(txtbxLoginName.Text);

            DataTable dtUserDetails = BusinessLogicClass.fnGetUserName(txtbxLoginName.Text, ddlDomainName.SelectedValue);

            foreach (DataRow dr in dtUserDetails.Rows)
            {
                Session["strUserName"] = dr["USER_NAME"].ToString();
                Session["strUnitId"] = dr["UNIT_ID"].ToString();
                Session["strRoleId"] = dr["USER_ROLE_ID"].ToString();
            }
            
            //Session["IsApprover"] = BusinessLogicClass.fnLoadSupervisorToSession(txtbxLoginName.Text, ddlDomainName.SelectedValue);
            Session["SessionId"] = Session.SessionID;
        }
    }
}