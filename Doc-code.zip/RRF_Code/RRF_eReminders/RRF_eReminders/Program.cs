﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using RRF_eReminders.Library;
using System.Data;
using System.Data.SqlClient;

namespace RRF_eReminders
{
    class Program
    {
        static string strUserId = "SYSTEM";

        static void Main(string[] args)
        {
            bool ifOK = false;

            BusinessLogicClass.fnLogActivityInFile("******************************************************", strUserId);
            BusinessLogicClass.fnLogActivityInFile("START", strUserId);

            string sActionType = ConfigurationManager.AppSettings["ACTION_TYPE"].ToString();

            BusinessLogicClass.fnLogActivityInFile("ACTION_TYPE:" + sActionType, strUserId);

            switch (sActionType)
            {
                case "1":   //1:Gen E-Submission Due List for All
                //case "1a":   //1:Gen E-Submission Due List for Daily + Weekly
                case "1a1":   //1:Gen E-Submission Due List for Daily
                case "1a2":   //1:Gen E-Submission Due List for Weekly
                case "1b":   //1:Gen E-Submission Due List for Monthly
                case "1c":   //1:Gen E-Submission Due List for Quarteryly + Yearly
                case "1d":   //1:Gen E-Submission Due List for AdHoc + 6 Times Yearly
                    ifOK = fnGenESubmissionDueList(sActionType);
                    break;

                case "2a":   //2:Gen pending action items reminder  for eTemplate

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    //ifOK = fnGenAlertPendingActionItems("1");

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    if (BusinessLogicClass.fnAllowSendAlerts(strUserId))
                        ifOK = fnGenAlertPendingActionItems("1");
                    else
                        BusinessLogicClass.fnLogActivityInFile("IGNORE:NON-WORKING DAYS", strUserId);

                    break;

                case "2b":   //2:Gen pending action items reminder  for eSubmission

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    //ifOK = fnGenAlertPendingActionItems("2");

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    if (BusinessLogicClass.fnAllowSendAlerts(strUserId))
                        ifOK = fnGenAlertPendingActionItems("2");
                    else
                        BusinessLogicClass.fnLogActivityInFile("IGNORE:NON-WORKING DAYS", strUserId);

                    break;

                case "3":   //3:Gen pending submission due reminder

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    //ifOK = fnGenAlertPendingSubmissionDue();

                    //megatshamsul - 20170419 - SR1363674 - send reminder only during working days (KL)
                    if (BusinessLogicClass.fnAllowSendAlerts(strUserId))
                        ifOK = fnGenAlertPendingSubmissionDue();
                    else
                        BusinessLogicClass.fnLogActivityInFile("IGNORE:NON-WORKING DAYS", strUserId);

                    break;

                case "4":   //4:Load user listing
                    ifOK = fnLoadUserListing();
                    break;

                case "5":   //5:Load E-Template listing
                    ifOK = fnLoadETemplateListing();
                    break;

                case "6":   //6:Set inactive user to Dormant
                    ifOK = fnSetDormantUsers();
                    break;
            }

            BusinessLogicClass.fnLogActivityInFile("SUCCESS:" + ifOK.ToString().ToUpper(), strUserId);
            BusinessLogicClass.fnLogActivityInFile("END", strUserId);
            BusinessLogicClass.fnLogActivityInFile("******************************************************", strUserId);
        }

        static bool fnGenESubmissionDueList(string sActionType)
        {
            bool ifOK = false;

            try
            {
                ifOK = BusinessLogicClass.fnGenESubmissionDueList(sActionType, strUserId);
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnGenESubmissionDueList", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        static bool fnGenAlertPendingActionItems(string module_id)
        {
            bool ifOK = false;
            string sEmailSubject = string.Empty;
            string sEmailBody = string.Empty; ;
            string sRoleId = string.Empty;
            string sIdName = string.Empty;
            string sIdValue = string.Empty;

            try
            {
                DataTable dtDetails = BusinessLogicClass.fnListAlertPendingActionItems(module_id, strUserId);

                if (dtDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtDetails.Rows)
                    {
                        sEmailSubject = string.Empty;
                        sRoleId = string.Empty;
                        sIdName = string.Empty;
                        sIdValue = string.Empty;

                        switch (dr["STATUS_ID"].ToString())
                        {
                            case "D1":
                            case "D2":
                            case "D3":

                                switch (dr["MODULE_ID"].ToString())
                                {
                                    case "ETemplate":
                                        sEmailSubject = "There is an E-Template item still pending in Preparer's queue - RPT_ID " + dr["RPT_ID"].ToString();
                                        sEmailBody = "E-Template Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "RPT_ID";
                                        sIdValue = dr["RPT_ID"].ToString();
                                        break;
                                    case "ESubmission":
                                        sEmailSubject = "There is an E-Submission item still pending in Preparer's queue - SUBMISSION_ID " + dr["SUBMISSION_ID"].ToString();
                                        sEmailBody = "E-Submission Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "SUBMISSION_ID";
                                        sIdValue = dr["SUBMISSION_ID"].ToString();
                                        break;
                                }
                                sRoleId = "Preparer";
                                break;

                            case "RJ1":
                            case "RJ2":
                            case "RJX1":
                            case "RJX2":

                                switch (dr["MODULE_ID"].ToString())
                                {
                                    case "ETemplate":
                                        sEmailSubject = "There is an E-Template item still pending in Reject Bucket List - RPT_ID " + dr["RPT_ID"].ToString();
                                        sEmailBody = "E-Template Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "RPT_ID";
                                        sIdValue = dr["RPT_ID"].ToString();
                                        break;
                                    case "ESubmission":
                                        sEmailSubject = "There is an E-Submission item still pending in Reject Bucket List - SUBMISSION_ID " + dr["SUBMISSION_ID"].ToString();
                                        sEmailBody = "E-Submission Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "SUBMISSION_ID";
                                        sIdValue = dr["SUBMISSION_ID"].ToString();
                                        break;
                                }
                                sRoleId = "Preparer";
                                break;

                            case "N":
                            case "U":
                            case "XR":

                                switch (dr["MODULE_ID"].ToString())
                                {
                                    case "ETemplate":
                                        sEmailSubject = "There is an E-Template item still pending in Approver's queue - RPT_ID " + dr["RPT_ID"].ToString();
                                        sEmailBody = "E-Template Report Name " + dr["RPT_NAME"].ToString() + " is still pending in approver’s queue. Please act accordingly.";
                                        sIdName = "RPT_ID";
                                        sIdValue = dr["RPT_ID"].ToString();
                                        break;
                                    case "ESubmission":
                                        sEmailSubject = "There is an E-Submission item still pending in Approver's queue - SUBMISSION_ID " + dr["SUBMISSION_ID"].ToString();
                                        sEmailBody = "E-Submission Report Name " + dr["RPT_NAME"].ToString() + " is still pending in approver’s queue. Please act accordingly.";
                                        sIdName = "SUBMISSION_ID";
                                        sIdValue = dr["SUBMISSION_ID"].ToString();
                                        break;
                                }
                                sRoleId = "Approver";
                                break;

                            case "AP1":
                            case "APX1":

                                switch (dr["MODULE_ID"].ToString())
                                {
                                    case "ETemplate":
                                        sEmailSubject = "There is an E-Template item still pending in FGT's queue - RPT_ID " + dr["RPT_ID"].ToString();
                                        sEmailBody = "E-Template Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "RPT_ID";
                                        sIdValue = dr["RPT_ID"].ToString();
                                        break;
                                    case "ESubmission":
                                        sEmailSubject = "There is an E-Submission item still pending in FGT's queue - SUBMISSION_ID " + dr["SUBMISSION_ID"].ToString();
                                        sEmailBody = "E-Submission Report Name " + dr["RPT_NAME"].ToString() + " is still pending in your queue. Please act accordingly.";
                                        sIdName = "SUBMISSION_ID";
                                        sIdValue = dr["SUBMISSION_ID"].ToString();
                                        break;
                                }
                                sRoleId = "FGTAppvr";
                                break;
                        }

                        if (!string.IsNullOrEmpty(sEmailSubject))
                        {
                            BusinessLogicClass.fnLogActivityInFile(sIdName + ":" + sIdValue + " for ROLE_ID:" + sRoleId, strUserId);

                            DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(dr["UNIT_ID"].ToString(), sRoleId, strUserId);
                            DataTable dtEmailCC = new DataTable();

                            BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, strUserId);

                            ifOK = true;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnGenAlertPendingActionItems", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        static bool fnGenAlertPendingSubmissionDue()
        {
            bool ifOK = false;
            string sEmailSubject = string.Empty;
            string sEmailBody = string.Empty; ;
            
            try
            {
                DataTable dtDetails = BusinessLogicClass.fnListAlertPendingSubmissionDue(strUserId);

                if (dtDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtDetails.Rows)
                    {
                        BusinessLogicClass.fnLogActivityInFile("SUBMISSION_ID:" + dr["SUBMISSION_ID"].ToString(), strUserId);

                        sEmailSubject = "Your Report Name " + dr["RPT_NAME"].ToString() + " is due on the " + dr["SUBMISSION_DATE"].ToString() + ". Please submit ASAP.";

                        //megatshamsul - 20170323 - SR1363674 - add remark into submission due email
                        sEmailBody = "<font face=Arial size=2><i>There will not be any Email Reminders for DAILY and ADHOC frequencies.</i>";

                        DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(dr["UNIT_ID"].ToString(), "Preparer", strUserId);
                        DataTable dtEmailTo2 = BusinessLogicClass.fnGetEmailRecipients(dr["UNIT_ID"].ToString(), "Approver", strUserId);
                        dtEmailTo.Merge(dtEmailTo2);

                        DataTable dtEmailCC = new DataTable();

                        BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, strUserId);

                        ifOK = true;
                    }

                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnGenAlertPendingSubmissionDue", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        static bool fnLoadETemplateListing()
        {
            bool ifOK = false;

            try
            {
                //DataTable dtDetails = BusinessLogicClass.fnReadETemplateXLSFile(strUserId);
                DataSet dsDetails = BusinessLogicClass.fnReadETemplateXLSFile2(strUserId);

                //if (dtDetails.Rows.Count > 0)
                if (dsDetails.Tables.Count > 0)
                {
                    DataTable dtUpload = new DataTable(ConfigurationManager.AppSettings["XLS_ETEMPLATE_SHEETNAME"].ToString());
                    dtUpload.Columns.Add("SREF", typeof(string));
                    dtUpload.Columns.Add("ENTITY_ID", typeof(string));
                    dtUpload.Columns.Add("RPT_NAME", typeof(string));
                    dtUpload.Columns.Add("REGULATOR_DESC", typeof(string));
                    dtUpload.Columns.Add("REGULATORY_DEPT", typeof(string));    //REGULATOR_DEPT
                    dtUpload.Columns.Add("SUBMISSION_MODE_DESC", typeof(string));
                    dtUpload.Columns.Add("UNIT_ID", typeof(string));
                    dtUpload.Columns.Add("REPORT_CONSOLIDATER", typeof(string));
                    dtUpload.Columns.Add("REPORT_CONTRIBUTOR1", typeof(string));
                    dtUpload.Columns.Add("REPORT_CONTRIBUTOR2", typeof(string));
                    dtUpload.Columns.Add("REPORT_CONTRIBUTOR3", typeof(string));
                    dtUpload.Columns.Add("REPORT_CONTRIBUTOR4", typeof(string));
                    dtUpload.Columns.Add("REMARKS", typeof(string));
                    dtUpload.Columns.Add("REGULATOR_ID", typeof(string));
                    dtUpload.Columns.Add("SUBMISSION_MODE_ID", typeof(string));
                    dtUpload.Columns.Add("FREQUENCY_ID", typeof(string));
                    dtUpload.Columns.Add("T_PLUS_SUBMISSION_DATE", typeof(string));
                    dtUpload.Columns.Add("BIZ_DAYS_ONLY", typeof(string));
                    dtUpload.Columns.Add("date1", typeof(string));
                    dtUpload.Columns.Add("date1_SD", typeof(string));
                    dtUpload.Columns.Add("date2", typeof(string));
                    dtUpload.Columns.Add("date2_SD", typeof(string));
                    dtUpload.Columns.Add("date3", typeof(string));
                    dtUpload.Columns.Add("date3_SD", typeof(string));
                    dtUpload.Columns.Add("date4", typeof(string));
                    dtUpload.Columns.Add("date4_SD", typeof(string));
                    dtUpload.Columns.Add("date5", typeof(string));
                    dtUpload.Columns.Add("date5_SD", typeof(string));
                    dtUpload.Columns.Add("date6", typeof(string));
                    dtUpload.Columns.Add("date6_SD", typeof(string));
                    dtUpload.Columns.Add("date7", typeof(string));
                    dtUpload.Columns.Add("date7_SD", typeof(string));
                    dtUpload.Columns.Add("date8", typeof(string));
                    dtUpload.Columns.Add("date8_SD", typeof(string));
                    dtUpload.Columns.Add("date9", typeof(string));
                    dtUpload.Columns.Add("date9_SD", typeof(string));
                    dtUpload.Columns.Add("date10", typeof(string));
                    dtUpload.Columns.Add("date10_SD", typeof(string));
                    dtUpload.Columns.Add("date11", typeof(string));
                    dtUpload.Columns.Add("date11_SD", typeof(string));
                    dtUpload.Columns.Add("date12", typeof(string));
                    dtUpload.Columns.Add("date12_SD", typeof(string));

                    //ifOK = BusinessLogicClass.fnPrepareETemplateListing(ref dtDetails, strUserId);
                    ifOK = BusinessLogicClass.fnPrepareETemplateListing2(dsDetails, ref dtUpload, strUserId);

                    //foreach (DataRow dr in dtDetails.Rows)
                    //{
                    //    foreach (object item in dr.ItemArray)
                    //        Console.WriteLine(item.ToString() + "=" + item.ToString().Length.ToString());
                    //}

                    if (ifOK)
                    {
                        //ifOK = BusinessLogicClass.fnLoadETemplateListing(dtDetails, strUserId);
                        ifOK = BusinessLogicClass.fnLoadETemplateListing(dtUpload, strUserId);
                    }
                    else
                        BusinessLogicClass.fnLogActivityInFile("Failed to prepare DB data", strUserId);
                }
                else
                {
                    BusinessLogicClass.fnLogActivityInFile("No Data!", strUserId);
                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnLoadETemplateListing", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }

        static bool fnLoadUserListing()
        {
            bool ifOK = false;

            try
            {
                //DataTable dtDetails = BusinessLogicClass.fnReadUserListingXLSFile(strUserId);
                DataSet dsDetails = BusinessLogicClass.fnReadUserListingXLSFile2(strUserId);

                //if (dtDetails.Rows.Count > 0)
                if (dsDetails.Tables.Count > 0)
                {
                    DataTable dtUpload = new DataTable(ConfigurationManager.AppSettings["XLS_USERLISTING_SHEETNAME"].ToString());
                    dtUpload.Columns.Add("USER_ID", typeof(string));
                    dtUpload.Columns.Add("DOMAIN_ID", typeof(string));
                    dtUpload.Columns.Add("USER_NAME", typeof(string));
                    dtUpload.Columns.Add("LOB", typeof(string));
                    dtUpload.Columns.Add("DEPT", typeof(string));
                    dtUpload.Columns.Add("HOD", typeof(string));
                    dtUpload.Columns.Add("UNIT", typeof(string));
                    dtUpload.Columns.Add("ROLE", typeof(string));
                    dtUpload.Columns.Add("EMP_ID", typeof(string));
                    dtUpload.Columns.Add("USER_EMAIL", typeof(string));
                    dtUpload.Columns.Add("IP_ADDRESS", typeof(string));

                    //ifOK = BusinessLogicClass.fnPrepareUserListing(ref dtDetails, strUserId);
                    ifOK = BusinessLogicClass.fnPrepareUserListing2(dsDetails, ref dtUpload, strUserId);

                    if (ifOK)
                    {
                        //ifOK = BusinessLogicClass.fnLoadUserListing(dtDetails, strUserId);
                        ifOK = BusinessLogicClass.fnLoadUserListing(dtUpload, strUserId);
                    }
                    else
                        BusinessLogicClass.fnLogActivityInFile("Failed to prepare DB data", strUserId);
                }
                else
                {
                    BusinessLogicClass.fnLogActivityInFile("No Data!", strUserId);
                }
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnLoadUserListing", ex.Message, strUserId);    //12 as default err code
            }

            Console.ReadLine();
            return ifOK;
        }

        static bool fnSetDormantUsers()
        {
            bool ifOK = false;

            try
            {
                ifOK = BusinessLogicClass.fnSetDormantUsers(strUserId);
            }
            catch (Exception ex)
            {
                BusinessLogicClass.fnLogErrorInFile(12, "fnSetDormantUsers", ex.Message, strUserId);    //12 as default err code
            }

            return ifOK;
        }
    }
}
