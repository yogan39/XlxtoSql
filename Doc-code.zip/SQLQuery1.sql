--user profile
select * from RRF_GUI_USERS where USER_ID like '10024079%'

--org charts
select * from RRF_GUI_UNIT_CODE where UNIT_CODE='001'
select * from RRF_GUI_DEPT_CODE where DEPT_CODE='001'
select * from RRF_GUI_LOB_CODE where LOB_CODE='001'

--template table
select top 5 * from RRF_GUI_ETEMPLATE_DATA where UNIT_ID='001' order by ROW_NUM desc

--audit trail table
select * from RRF_GUI_AUDT_TRL where TBL_NM='RRF_GUI_ETEMPLATE_DATA' and after_img like '000000266%' order by LOG_UPDT_DT desc

NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | NC | test rmk | U | NC | NC | Oct 10 2017 10:43AM | NC | NC | NC | NC | NC | NC

--status codes
select * from RRF_GUI_STATUS_CODE

--esubmission
select * from RRF_GUI_ESUBMISSION_DATA where RPT_ID='000000254' order by ROW_NUM

--user profile
select * from rrf_gui_users 

--org chart table
select * from RRF_GUI_UNIT_CODE
select * from RRF_GUI_dept_CODE
select * from RRF_GUI_lob_CODE

--user status
select * from RRF_GUI_REF_USERSTAT

--session log
select * from RRF_GUI_SESN_LOG order by TS_LOG desc

select * from RRF_GUI_USER_ROLE

select * from RRF_GUI_PAGE_CODES
