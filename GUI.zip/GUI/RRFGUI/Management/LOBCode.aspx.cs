﻿using RRFGUI.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RRFGUI.Management
{
    
    public partial class LOBCode : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "LOB MAINTENANCE";
            if(!IsPostBack)
            {
                TabContainerLOBMaintenance.ActiveTab = TabPanelListing;
                switch (Session["strRoleId"].ToString())
                {
                    case "Admin":
                        btToAdd.Visible = true;
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("All","All"));
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        break;

                    case "AdminAA":
                        btToAdd.Visible = false;
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("All", "All"));
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("Approved", "A"));
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("Rejected", "R"));
                        DDLOBList.Items.Add(new System.Web.UI.WebControls.ListItem("Pending", "P"));
                        break;
                }
                fnBindLob(false);
            }
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
           string strLobid = grdvwListing.SelectedRow.Cells[1].Text;
            

            string strMessage = string.Empty;
            strMessage = fnEnableforEdit(strLobid);

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindLob(false);
        }

        protected void grdvwListing_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        private void fnBindLob( bool isExport)
        {
            txtLobNo.Text = string.Empty;
            txtLobName.Text = string.Empty;
            txtREJECT_REASON.Text = string.Empty;
            TabContainerLOBMaintenance.ActiveTab = TabPanelListing;
            string strroleid = Session["strRoleId"].ToString();
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadLOB(strroleid, Session["strUserId"].ToString(), txtfilterLOB.Text.ToString(),isExport, DDLOBList.SelectedValue);
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
        }

        private void fnEnableforAdding()
        {
            txtLobName.Enabled = true;
            btnCreate.Visible = true;
             lbllobcode.Visible = false;
            txtLobNo.Visible = false;

        }

        private void fnEnablecntrlforEdit(string strststus)
        {
            switch (Session["strRoleId"].ToString())
            {
                case "Admin":
                    txtLobName.Enabled = true;
                    btnUpdate.Visible = true;
                    lbllobcode.Visible = true;
                    txtLobNo.Visible = true;
                    break;
                case "AdminAA":
                    txtREJECT_REASON.Enabled = true;
                    txtLobName.Enabled = false;
                    if (strststus=="A")
                    {
                        btnAprove.Visible = false;
                    }
                    else
                    {
                        btnAprove.Visible = true;
                    }
                   
                    btnReject.Visible = true;
                    lbllobcode.Visible = true;
                    txtLobNo.Visible = true;
                    break;
            }
            
        }

        private string fnEnableforEdit(string strlobcode)
        {
            string strMessage = string.Empty;
            string strstatus = string.Empty;
            TabContainerLOBMaintenance.ActiveTab = TabPanelDetails;

            if (TabContainerLOBMaintenance.ActiveTabIndex == 1)
            {
                DataTable dtCodeDetails = BusinessLogicClass.fnLobGetlist(strlobcode, Session["strUserId"].ToString());

                if (dtCodeDetails.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtCodeDetails.Rows)
                    {
                        txtLobName.Text = dr["LOB_CODE_NM"].ToString();
                        txtLobNo.Text = dr["LOB_CODE"].ToString();
                        txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                        strstatus = dr["STATUS"].ToString();
                    }

                    fnEnablecntrlforEdit(strstatus);
                }
                else
                {
                    strMessage = "No record found";
                }
            }


            return strMessage;
        }

        protected void btToAdd_Click(object sender, EventArgs e)
        {
            TabContainerLOBMaintenance.ActiveTab = TabPanelDetails;
            fnEnableforAdding();
        }

        protected void btnAprove_Click(object sender, EventArgs e)
        {
            try
            {
                ShowMessage(BusinessLogicClass.fnupdateLob("A", "", Session["strUserId"].ToString(), txtLobNo.Text.ToString(), txtLobName.Text.ToString()), string.Empty);         
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            ShowMessage(BusinessLogicClass.fnupdateLob("I", "", Session["strUserId"].ToString(), "", txtLobName.Text.ToString()), string.Empty);
            fnBindLob(false);
           
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            ShowMessage(BusinessLogicClass.fnupdateLob("U", "", Session["strUserId"].ToString(), txtLobNo.Text.ToString(), txtLobName.Text.ToString()), string.Empty);
            fnBindLob(false);
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtREJECT_REASON.Text))
            {
                ShowMessage("This is mandatory field, input is required - REJECT_REASON", txtREJECT_REASON.ClientID.ToString());
                
            }
            else
            {
                ShowMessage(BusinessLogicClass.fnupdateLob("R", txtREJECT_REASON.Text.ToString(), Session["strUserId"].ToString(), txtLobNo.Text.ToString(), txtLobName.Text.ToString()), string.Empty);
                fnBindLob(false);
            }
            
        }

        [WebMethod]
        public static List<string> fnSerchLOBName(string prefixText, int count)// tested ok yogan.
        {
            string ssuserid = HttpContext.Current.Session["strUserId"].ToString();
            string ssrole = HttpContext.Current.Session["strRoleId"].ToString();

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadLOB(ssrole, ssuserid, prefixText,true,string.Empty); //Yogan Added Search by Name according to SR''

            List<string> LOB_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                LOB_NAME.Add(dr["LOB_CODE_NM"].ToString());
            }
            return LOB_NAME;
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            fnBindLob(true);
        }

    }  
}