﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;
using System.Web.Services;

namespace RRFGUI.Security
{
    public partial class UserIdMaintenance : System.Web.UI.Page
    {
        string strUSER_ID = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "USER ID MAINTENANCE";

            if (!IsPostBack)
            {
                TabContainerUserIdMaintenance.ActiveTab = TabPanelListing;

                fnLoadUnitCode();
                fnLoadRoleCode();
                fnLoadDomainId();
                fnLoadUserStatus();
                fnLoadIsCurrentlyLoggedIn();
                fnResetEditForm();
                fnBindListing(false);
            }
        }

        #region PreLoading

        private void fnLoadUnitCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUnitCode(Session["strUserId"].ToString());

            ddlFilterUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["UNIT_CODE_NM"].ToString(), dr["UNIT_CODE"].ToString()));
                ddlUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["UNIT_CODE_NM"].ToString(), dr["UNIT_CODE"].ToString()));
            }
        }

        private void fnLoadRoleCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadRoleCode(Session["strUserId"].ToString());

            ddlFilterUSER_ROLE.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlUSER_ROLE_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterUSER_ROLE.Items.Add(new System.Web.UI.WebControls.ListItem(dr["GUI_RULE_CODE"].ToString(), dr["GUI_RULE_CODE"].ToString()));
                ddlUSER_ROLE_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["GUI_RULE_CODE"].ToString(), dr["GUI_RULE_CODE"].ToString()));
            }
        }

        private void fnLoadDomainId()
        {
            ddlUSER_DOMAIN_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlUSER_DOMAIN_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMBANKGROUP", "AMBANKGROUP"));
            ddlUSER_DOMAIN_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMAB","AMAB"));
            ddlUSER_DOMAIN_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMMB","AMMB"));
            ddlUSER_DOMAIN_ID.Items.Add(new System.Web.UI.WebControls.ListItem("GRPUSR", "GRPUSR"));
        }

        private void fnLoadUserStatus()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUserStatusCode(Session["strUserId"].ToString());

            ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            
            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["USER_STAT_CODE_DSC"].ToString(), dr["USER_STAT_CODE"].ToString()));
            }
        }

        private void fnLoadIsCurrentlyLoggedIn()
        {
            ddlIS_CURRENTLY_LOGGED_IN.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlIS_CURRENTLY_LOGGED_IN.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlIS_CURRENTLY_LOGGED_IN.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }
            
            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        #endregion

        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            strUSER_ID = grdvwListing.SelectedRow.Cells[1].Text;

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(txtFilterUser_name.Text, txtFilterUSER_ID.Text, ddlFilterUNIT_ID.SelectedValue, ddlFilterUSER_ROLE.SelectedValue, Session["strUserId"].ToString(), ifExport);//Yogan added Name search According To SR''.
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();

            if (!ifExport)
                lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
        }

        #endregion

        #region Details

        private string fnShowSelectedData()
        {
            TabContainerUserIdMaintenance.ActiveTab = TabPanelDetails;

            string strMessage = string.Empty;
            System.Web.UI.WebControls.ListItem oListItem;

            DataTable dtCodeDetails = BusinessLogicClass.fnGetUserDetails(strUSER_ID, Session["strUserId"].ToString());

            if (dtCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtUSER_ID.Text = strUSER_ID;
                    txtUSER_NAME.Text = dr["USER_NAME"].ToString();

                    oListItem = ddlUSER_DOMAIN_ID.Items.FindByValue(dr["DOMAIN_ID"].ToString());
                    if (oListItem != null)
                        ddlUSER_DOMAIN_ID.SelectedValue = oListItem.Value;

                    oListItem = ddlUNIT_ID.Items.FindByValue(dr["UNIT_ID"].ToString());
                    if (oListItem != null)
                        ddlUNIT_ID.SelectedValue = oListItem.Value;

                    DataTable dtUnitCodeDetails = BusinessLogicClass.fnGetUnitDetails(dr["UNIT_ID"].ToString());

                    if (dtUnitCodeDetails.Rows.Count > 0)
                    {
                        foreach (DataRow drUnit in dtUnitCodeDetails.Rows)
                        {
                            txtDEPT_ID.Text = drUnit["DEPT_CODE_NM"].ToString();
                            txtLOB_ID.Text = drUnit["LOB_CODE_NM"].ToString();
                            txtHOD.Text = drUnit["HOD"].ToString();
                        }
                    }
                    else
                    {
                        txtDEPT_ID.Text = "";
                        txtLOB_ID.Text = "";
                        txtHOD.Text = "";
                    }

                    oListItem = ddlUSER_ROLE_ID.Items.FindByValue(dr["USER_ROLE_ID"].ToString());
                    if (oListItem != null)
                        ddlUSER_ROLE_ID.SelectedValue = oListItem.Value;

                    oListItem = ddlSTATUS_ID.Items.FindByValue(dr["STATUS_ID"].ToString());
                    if (oListItem != null)
                        ddlSTATUS_ID.SelectedValue = oListItem.Value;

                    txtUSER_STAT_REASON.Text = dr["USER_STAT_REASON"].ToString();

                    oListItem = ddlIS_CURRENTLY_LOGGED_IN.Items.FindByValue(dr["CURRENTLY_LOGGED_IN"].ToString());
                    if (oListItem != null)
                        ddlIS_CURRENTLY_LOGGED_IN.SelectedValue = oListItem.Value;

                    txtEMP_ID.Text = dr["EMP_ID"].ToString();
                    txtUSER_EMAIL.Text = dr["USER_EMAIL"].ToString();
                    txtIP_ADDRESS.Text = dr["IP_ADDRESS"].ToString();
                    txtCRETN_DT.Text = dr["CREATION_DATE"].ToString();
                    txtTS_LAST_LGIN.Text = dr["LAST_LOGIN"].ToString();
                    txtTS_LAST_LGOT.Text = dr["LAST_LOGOUT"].ToString();
                    txtUPDT_USER_ID.Text = dr["UPDT_USER_ID"].ToString();
                    txtUPDT_DATE.Text = dr["UPDT_DATE"].ToString();
                }

                EnableFieldsForEditing();
            }
            else
                strMessage = "No record found";

            return strMessage;
        }

        [WebMethod]
        public static object fnGetUnitDetails(string sUnitId)
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnGetUnitDetails(sUnitId);

            string[] theListing = new string[3];

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                theListing[0] = dr["DEPT_CODE_NM"].ToString();
                theListing[1] = dr["LOB_CODE_NM"].ToString();
                theListing[2] = dr["HOD"].ToString();
            }

            return new { Listing = theListing };
        }

        protected void btnNew_OnClick(object sender, EventArgs e)
        {
            fnResetEditForm();

            //megatshamsul - 20161116 - to default status as Active for new user as per user request during mtg on 16/11/2016
            ddlSTATUS_ID.SelectedValue = "A";
            
            EnableFieldsForAdding();
            TabContainerUserIdMaintenance.ActiveTab = TabPanelDetails;
        }

        protected void btnAddUser_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit())
            {
                ShowMessage(fnUpdateDeleteUser("I"), string.Empty);
                fnResetEditForm();
                fnBindListing(false);

                TabContainerUserIdMaintenance.ActiveTab = TabPanelListing;
            }
        }

        protected void btnUpdateUser_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit())
            {
                ShowMessage(fnUpdateDeleteUser("U"), string.Empty);
                fnResetEditForm();
                fnBindListing(false);

                TabContainerUserIdMaintenance.ActiveTab = TabPanelListing;
            }
        }

        protected void btnDeleteUser_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsDelete())
            {
                ShowMessage(fnUpdateDeleteUser("D"), string.Empty);
                fnResetEditForm();
                fnBindListing(false);

                TabContainerUserIdMaintenance.ActiveTab = TabPanelListing;
            }
        }

        private string fnUpdateDeleteUser(string Update_Type)
        {
            DataTable dtCodeDetails = new DataTable("DataTypeUpdateUser");
            dtCodeDetails.Columns.Add("USER_ID", typeof(string));
            dtCodeDetails.Columns.Add("USER_DOMAIN_ID", typeof(string));
            dtCodeDetails.Columns.Add("USER_NAME", typeof(string));
            dtCodeDetails.Columns.Add("UNIT_ID", typeof(string));
            dtCodeDetails.Columns.Add("USER_ROLE_ID", typeof(string));
            dtCodeDetails.Columns.Add("STATUS_ID", typeof(string));
            dtCodeDetails.Columns.Add("USER_STAT_REASON", typeof(string));
            dtCodeDetails.Columns.Add("IS_CURRLY_LOGGED_IN", typeof(string));
            dtCodeDetails.Columns.Add("EMP_ID", typeof(string));
            dtCodeDetails.Columns.Add("USER_EMAIL", typeof(string));
            dtCodeDetails.Columns.Add("IP_ADDRESS", typeof(string));

            DataRow drCodeDetails = dtCodeDetails.NewRow();

            drCodeDetails["USER_ID"] = txtUSER_ID.Text.ToString();
            drCodeDetails["USER_DOMAIN_ID"] = ddlUSER_DOMAIN_ID.SelectedValue.ToString();
            drCodeDetails["USER_NAME"] = txtUSER_NAME.Text.ToString();
            drCodeDetails["UNIT_ID"] = ddlUNIT_ID.SelectedValue.ToString();
            drCodeDetails["USER_ROLE_ID"] = ddlUSER_ROLE_ID.SelectedValue.ToString();
            drCodeDetails["STATUS_ID"] = ddlSTATUS_ID.SelectedValue.ToString();
            drCodeDetails["USER_STAT_REASON"] = txtUSER_STAT_REASON.Text.ToString();
            drCodeDetails["IS_CURRLY_LOGGED_IN"] = ddlIS_CURRENTLY_LOGGED_IN.SelectedValue.ToString();
            drCodeDetails["EMP_ID"] = txtEMP_ID.Text.ToString();
            drCodeDetails["USER_EMAIL"] = txtUSER_EMAIL.Text.ToString();
            drCodeDetails["IP_ADDRESS"] = txtIP_ADDRESS.Text.ToString();

            dtCodeDetails.Rows.Add(drCodeDetails);

            string strMessage = BusinessLogicClass.fnUpdateUserDetails(Update_Type, dtCodeDetails, Session["strUserId"].ToString());

            return strMessage;
        }

        private void fnResetEditForm()
        {
            txtUSER_ID.Text = "";
            txtUSER_ID.Enabled = false;

            txtUSER_NAME.Text = "";
            txtUSER_NAME.Enabled = false;

            ddlUSER_DOMAIN_ID.SelectedIndex = 0;
            ddlUSER_DOMAIN_ID.Enabled = false;

            ddlUNIT_ID.SelectedIndex = 0;
            ddlUNIT_ID.Enabled = false;

            txtDEPT_ID.Text = "";
            txtDEPT_ID.Enabled = false;

            txtLOB_ID.Text = "";
            txtLOB_ID.Enabled = false;

            txtHOD.Text = "";
            txtHOD.Enabled = false;

            ddlUSER_ROLE_ID.SelectedIndex = 0;
            ddlUSER_ROLE_ID.Enabled = false;

            txtEMP_ID.Text = "";
            txtEMP_ID.Enabled = false;

            txtUSER_EMAIL.Text = "";
            txtUSER_EMAIL.Enabled = false;

            txtIP_ADDRESS.Text = "";
            txtIP_ADDRESS.Enabled = false;

            ddlSTATUS_ID.SelectedIndex = 0;
            ddlSTATUS_ID.Enabled = false;

            txtUSER_STAT_REASON.Text = "";
            txtUSER_STAT_REASON.Enabled = false;

            txtCRETN_DT.Text = "";
            txtCRETN_DT.Enabled = false;

            txtTS_LAST_LGIN.Text = "";
            txtTS_LAST_LGIN.Enabled = false;

            txtTS_LAST_LGOT.Text = "";
            txtTS_LAST_LGOT.Enabled = false;

            ddlIS_CURRENTLY_LOGGED_IN.SelectedIndex = 0;
            ddlIS_CURRENTLY_LOGGED_IN.Enabled = false;

            txtLAST_LGIN_IP_ADR.Text = "";
            txtLAST_LGIN_IP_ADR.Enabled = false;

            txtUPDT_USER_ID.Text = "";
            txtUPDT_USER_ID.Enabled = false;

            txtUPDT_DATE.Text = "";
            txtUPDT_DATE.Enabled = false;

            btnAddUser.Enabled = false;
            btnAddUser.Visible = false;

            btnUpdateUser.Enabled = false;
            btnUpdateUser.Visible = false;

            btnDeleteUser.Enabled = false;
            btnDeleteUser.Visible = false;
        }

        private void EnableFieldsForAdding()
        {
            txtUSER_ID.Enabled = true;
            txtUSER_NAME.Enabled = true;
            ddlUSER_DOMAIN_ID.Enabled = true;
            ddlUNIT_ID.Enabled = true;
            ddlUSER_ROLE_ID.Enabled = true;
            ddlSTATUS_ID.Enabled = true;
            txtUSER_STAT_REASON.Enabled = true;
            txtEMP_ID.Enabled = true;
            txtUSER_EMAIL.Enabled = true;
            txtIP_ADDRESS.Enabled = true;

            System.Web.UI.WebControls.ListItem oListItem = ddlIS_CURRENTLY_LOGGED_IN.Items.FindByValue("N");
            if (oListItem != null)
                ddlIS_CURRENTLY_LOGGED_IN.SelectedValue = oListItem.Value;
            ddlIS_CURRENTLY_LOGGED_IN.Enabled = false;

            txtCRETN_DT.Enabled = false;
            txtTS_LAST_LGIN.Enabled = false;
            txtTS_LAST_LGOT.Enabled = false;
            txtUPDT_USER_ID.Enabled = false;
            txtUPDT_DATE.Enabled = false;

            btnAddUser.Enabled = true;
            btnAddUser.Visible = true;

            btnUpdateUser.Enabled = false;
            btnUpdateUser.Visible = false;

            btnDeleteUser.Enabled = false;
            btnDeleteUser.Visible = false;
        }

        private void EnableFieldsForEditing()
        {
            txtUSER_ID.Enabled = false;
            txtUSER_NAME.Enabled = true;
            ddlUSER_DOMAIN_ID.Enabled = true;
            ddlUNIT_ID.Enabled = true;
            txtDEPT_ID.Enabled = false;
            txtLOB_ID.Enabled = false;
            txtHOD.Enabled = false;
            ddlUSER_ROLE_ID.Enabled = true;
            txtEMP_ID.Enabled = true;
            txtUSER_EMAIL.Enabled = true;
            txtIP_ADDRESS.Enabled = true;
            ddlSTATUS_ID.Enabled = true;
            txtUSER_STAT_REASON.Enabled = true;
            txtCRETN_DT.Enabled = false;
            txtTS_LAST_LGIN.Enabled = false;
            txtTS_LAST_LGOT.Enabled = false;
            ddlIS_CURRENTLY_LOGGED_IN.Enabled = true;
            txtLAST_LGIN_IP_ADR.Enabled = false;
            txtUPDT_USER_ID.Enabled = false;
            txtUPDT_DATE.Enabled = false;

            btnAddUser.Enabled = false;
            btnAddUser.Visible = false;

            btnUpdateUser.Enabled = true;
            btnUpdateUser.Visible = true;

            btnDeleteUser.Enabled = true;
            btnDeleteUser.Visible = true;
        }

        private bool ValidateFieldsAddEdit()
        {
            if (string.IsNullOrEmpty(txtUSER_ID.Text))
            {
                ShowMessage("Please enter USER_ID", txtUSER_ID.ClientID.ToString());
                return false;
            }
            else if (txtUSER_ID.Text == Session["strUserId"].ToString())
            {
                ShowMessage("Please select other users", txtUSER_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtUSER_NAME.Text))
            {
                ShowMessage("Please enter USER_NAME", txtUSER_NAME.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlUSER_DOMAIN_ID.SelectedValue))
            {
                ShowMessage("Please select USER_DOMAIN_ID", ddlUSER_DOMAIN_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlUNIT_ID.SelectedValue))
            {
                ShowMessage("Please select UNIT_ID", ddlUNIT_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlUSER_ROLE_ID.SelectedValue))
            {
                ShowMessage("Please select USER_ROLE_ID", ddlUSER_ROLE_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlSTATUS_ID.SelectedValue))
            {
                ShowMessage("Please select STATUS_ID", ddlSTATUS_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlIS_CURRENTLY_LOGGED_IN.SelectedValue))
            {
                ShowMessage("Please select IS_CURRENTLY_LOGGED_IN", ddlIS_CURRENTLY_LOGGED_IN.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtEMP_ID.Text))
            {
                ShowMessage("Please enter EMP_ID", txtEMP_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtUSER_EMAIL.Text))
            {
                ShowMessage("Please enter USER_EMAIL", txtUSER_EMAIL.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtIP_ADDRESS.Text))
            {
                ShowMessage("Please enter IP_ADDRESS", txtIP_ADDRESS.ClientID.ToString());
                return false;
            }

            return true;
        }

        private bool ValidateFieldsDelete()
        {
            if (string.IsNullOrEmpty(txtUSER_ID.Text))
            {
                ShowMessage("Please enter USER_ID", txtUSER_ID.ClientID.ToString());
                return false;
            }
            else if (txtUSER_ID.Text == Session["strUserId"].ToString())
            {
                ShowMessage("Please select other users", txtUSER_ID.ClientID.ToString());
                return false;
            }

            return true;
        }

        #endregion

        #region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintUserId = "";
                    string strPrintUnitId = "";
                    string strPrintRoleId = "";

                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(false);

                            if (txtFilterUSER_ID.Text.Length > 0)
                                strPrintUserId = txtFilterUSER_ID.Text;
                            else
                                strPrintUserId = "All Users";

                            if (ddlFilterUNIT_ID.SelectedValue.Length > 0)
                                strPrintUnitId = ddlFilterUNIT_ID.SelectedItem.Text;
                            else
                                strPrintUnitId = "All Units";

                            if (ddlFilterUSER_ROLE.SelectedValue.Length > 0)
                                strPrintRoleId = ddlFilterUSER_ROLE.SelectedItem.Text;
                            else
                                strPrintRoleId = "All Roles";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF USERS", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("USER_ID : " + strPrintUserId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell6 = new PdfPCell(new Phrase("UNIT_ID : " + strPrintUnitId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell6.Border = 0;
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0;
                            table.AddCell(cell6);

                            PdfPCell cell7 = new PdfPCell(new Phrase("USER_ROLE : " + strPrintRoleId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell7.Border = 0;
                            cell7.Colspan = 3;
                            cell7.HorizontalAlignment = 0;
                            table.AddCell(cell7);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfUserIdMaintenance.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "UserIdMaintenancePrint.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "UserIdMaintenancePrint.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfUserIdMaintenance.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(false);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                                sb.Append('"' + val + '"' + ',');
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());

                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion

        [WebMethod]
        public static List<string> fnSerchUserName(string prefixText, int count)// tested ok yogan.
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(prefixText, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''

            List<string> USER_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                USER_NAME.Add(dr["USER_NAME"].ToString());
            }
            return USER_NAME;
        }

        protected void txtFilterUser_name_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFilterUser_name.Text))
            {
                DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(txtFilterUser_name.Text, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''

                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtFilterUSER_ID.Text = dr["USER_ID"].ToString();
                }

            }
            else
            {
                txtFilterUSER_ID.Text = string.Empty;

            }
            txtFilterUSER_ID.Enabled = false;
        }
    }
}