﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;
using System.Web.Services;

namespace RRFGUI.Security
{
    public partial class SessionLog : System.Web.UI.Page
    {
        string strSESSION_SEQ_NO = string.Empty;
        string strUSER_ID = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "SESSION LOG";

            if (!IsPostBack)
            {
                TabContainerSessionLog.ActiveTab = TabPanelListing;

                //default to current date
                txtFilterLOG_DATE.Text = BusinessLogicClass.GetDDMMYYYY(DateTime.Now);

                fnLoadUserId();
                fnLoadActionCode();
                fnBindListing(false);
                ddlFilterUSER_ID.Enabled = false;
            }
        }

        #region PreLoading

        private void fnLoadUserId()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(string.Empty,string.Empty, string.Empty, string.Empty, Session["strUserId"].ToString(), false); //Yogan Added Search by Name according to SR''

            ddlFilterUSER_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterUSER_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["USER_ID"].ToString() + " - " + dr["USER_NAME"].ToString(), dr["USER_ID"].ToString()));
            }
            
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();
        }

        private void fnLoadActionCode()
        {
            ddlFilterACTION_CODE.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlFilterACTION_CODE.Items.Add(new System.Web.UI.WebControls.ListItem("Log In", "LI"));
            ddlFilterACTION_CODE.Items.Add(new System.Web.UI.WebControls.ListItem("Log Out", "LO"));
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        #endregion

        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            strSESSION_SEQ_NO = grdvwListing.SelectedRow.Cells[1].Text;
            strUSER_ID = grdvwListing.SelectedRow.Cells[4].Text;

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);

            fnBindListing(false);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    switch (e.Row.Cells[3].Text)
            //    {
            //        case "Y": e.Row.Cells[3].Text = "Yes"; break;
            //        case "N": e.Row.Cells[3].Text = "No"; break;
            //    }
            //}
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListSessionLog(txtFilterLOG_DATE.Text, ddlFilterUSER_ID.SelectedValue, ddlFilterACTION_CODE.SelectedValue, Session["strUserId"].ToString());
            grdvwListing.DataSource = dtCodeDetails;
            grdvwListing.DataBind();

            if (!ifExport)
                lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
        }

        #endregion

        #region Details

        private string fnShowSelectedData()
        {
            TabContainerSessionLog.ActiveTab = TabPanelDetails;

            string strMessage = string.Empty;

            DataTable dtCodeDetails = BusinessLogicClass.fnGetSessionLogDetails(strSESSION_SEQ_NO, strUSER_ID, Session["strUserId"].ToString());

            if (dtCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtSESSION_SEQ_NO.Text = strSESSION_SEQ_NO;
                    txtLOG_DATE.Text = dr["LOG_DATE"].ToString();
                    txtACTION_CODE.Text = dr["ACTION_CODE"].ToString();
                    txtUSER_ID.Text = dr["USER_ID"].ToString();
                    txtIP_ADDRESS.Text = dr["IP_ADDRESS"].ToString();
                    txtSTATUS_CODE.Text = dr["STATUS_CODE"].ToString();
                    txtSTATUS_DESC.Text = dr["STATUS_DESC"].ToString();
                }
            }
            else
                strMessage = "No record found";

            return strMessage;
        }

        #endregion

        #region region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            string strMessage = string.Empty;

            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintLogDt = "";
                    string strPrintUserId = "";
                    string strPrintActionId = "";

                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(true);

                            if (txtFilterLOG_DATE.Text.Length > 0)
                                strPrintLogDt = txtFilterLOG_DATE.Text;
                            else
                                strPrintLogDt = "All Dates";

                            if (ddlFilterUSER_ID.SelectedValue.Length > 0)
                                strPrintUserId = ddlFilterUSER_ID.SelectedItem.Text;
                            else
                                strPrintUserId = "All Users";

                            if (ddlFilterACTION_CODE.SelectedValue.Length > 0)
                                strPrintActionId = ddlFilterACTION_CODE.SelectedItem.Text;
                            else
                                strPrintActionId = "All Actions";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF SESSION LOG", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("LOG_DATE : " + strPrintLogDt, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell6 = new PdfPCell(new Phrase("USER_ID : " + strPrintUserId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell6.Border = 0;
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0;
                            table.AddCell(cell6);

                            PdfPCell cell1 = new PdfPCell(new Phrase("ACTION_CODE : " + strPrintActionId, new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell1.Border = 0;
                            cell1.Colspan = 3;
                            cell1.HorizontalAlignment = 0;
                            table.AddCell(cell1);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfSessionLog.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "SessionLogPrint.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "SessionLogPrint.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfSessionLog.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(true);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                                sb.Append('"' + val + '"' + ',');
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());

                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion

        #region Search User by name using AutoComplete Extender

        [WebMethod]
        public static List<string> fnSerchUserName(string prefixText, int count)// tested ok yogan.
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(prefixText, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''

            List<string> USER_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                USER_NAME.Add(dr["USER_NAME"].ToString());
            }
            return USER_NAME;
        }
        #endregion

        #region Displaying ID and Username and ID
        protected void txtfilterName_TextChanged(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(txtfilterName.Text))
            {
                DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(txtfilterName.Text, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''
                System.Web.UI.WebControls.ListItem oListItem;
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    oListItem = new System.Web.UI.WebControls.ListItem(dr["USER_ID"].ToString() + " - " + dr["USER_NAME"].ToString(), dr["USER_ID"].ToString());
                    ddlFilterUSER_ID.Items.Add(oListItem);
                    ddlFilterUSER_ID.SelectedValue = oListItem.Value;
                }
            }
            else
            {
                ddlFilterUSER_ID.Text = string.Empty;

            }
            
        }
        #endregion
    }
}