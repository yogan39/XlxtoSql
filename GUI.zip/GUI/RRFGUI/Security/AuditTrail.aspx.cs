﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;
using System.Web.Services;

namespace RRFGUI.Security
{
    public partial class AuditTrail : System.Web.UI.Page
    {
        string strID = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "AUDIT TRAIL";

            if (!IsPostBack)
            {
                //default to current date
                txtFilterDateFrom.Text = BusinessLogicClass.GetDDMMYYYY(DateTime.Now);
                txtFilterDateTo.Text = BusinessLogicClass.GetDDMMYYYY(DateTime.Now);

                TabContainerAuditTrail.ActiveTab = TabPanelListing;

                fnLoadTableName();
                fnLoadAction();
                fnBindListing(false);
            }
        }

        #region PreLoading

        private void fnLoadTableName()
        {
            ddlFilterTBL_NM.Items.Add(new System.Web.UI.WebControls.ListItem("All Tables", ""));
            ddlFilterTBL_NM.Items.Add(new System.Web.UI.WebControls.ListItem("RRF_GUI_USERS", "RRF_GUI_USERS"));
            ddlFilterTBL_NM.Items.Add(new System.Web.UI.WebControls.ListItem("RRF_GUI_ETEMPLATE_DATA", "RRF_GUI_ETEMPLATE_DATA"));
            ddlFilterTBL_NM.Items.Add(new System.Web.UI.WebControls.ListItem("RRF_GUI_ESUBMISSION_DATA", "RRF_GUI_ESUBMISSION_DATA"));
        }

        private void fnLoadAction()
        {
            ddlFilterACTN.Items.Add(new System.Web.UI.WebControls.ListItem("All Actions", ""));
            ddlFilterACTN.Items.Add(new System.Web.UI.WebControls.ListItem("DELETE", "D"));
            ddlFilterACTN.Items.Add(new System.Web.UI.WebControls.ListItem("INSERT", "I"));
            ddlFilterACTN.Items.Add(new System.Web.UI.WebControls.ListItem("UPDATE", "U"));
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        #endregion
        
        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            strID = grdvwListing.SelectedRow.Cells[1].Text;

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);

            fnBindListing(false);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            bool ifOK = false;

            if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ifOK = true;
            }
            else if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date From", txtFilterDateFrom.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date To", txtFilterDateTo.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                if (BusinessLogicClass.fnValidateDatesRange(txtFilterDateFrom.Text, txtFilterDateTo.Text))
                    ifOK = true;
                else
                    ShowMessage("Please select correct Date range", txtFilterDateFrom.ClientID.ToString());
            }

            if (ifOK)
            {
                string strListType = "P";

                if (!ifExport)
                    strListType = "L";

                DataTable dtCodeDetails = BusinessLogicClass.fnListAuditTrail(strListType, txtFilterUPDT_USER_ID.Text, txtFilterDateFrom.Text, txtFilterDateTo.Text, ddlFilterTBL_NM.SelectedValue, ddlFilterACTN.SelectedValue, Session["strUserId"].ToString(), ifExport);
                grdvwListing.DataSource = dtCodeDetails;
                grdvwListing.DataBind();

                if (!ifExport)
                    lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
            }
        }

        #endregion

        #region Details

        private string fnShowSelectedData()
        {
            TabContainerAuditTrail.ActiveTab = TabPanelDetails;

            string strMessage = string.Empty;
            
            DataTable dtCodeDetails = BusinessLogicClass.fnGetAuditTrailDetails(strID, Session["strUserId"].ToString());

            if (dtCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtID.Text = strID;
                    txtLOG_UPDT_DT.Text = dr["LOG_UPDT_DT"].ToString(); ;
                    txtTBL_NM.Text = dr["TBL_NM"].ToString(); ;
                    txtACTN.Text = dr["ACTN"].ToString(); ;
                    txtUPDT_USER_ID.Text = dr["UPDT_USER_ID"].ToString(); ;
                    txtBEFORE_IMG.Text = dr["BEFORE_IMG"].ToString();
                    txtAFTER_IMG.Text = dr["AFTER_IMG"].ToString();
                    txtDIFF.Text = dr["DIFF"].ToString();
                }
            }
            else
                strMessage = "No record found";

            return strMessage;
        }

        #endregion

        #region region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            string strMessage = string.Empty;

            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintUserId = "";
                    string strPrintUpdateDt = "";
                    string strPrintTblName = "";
                    string strPrintActionId = "";

                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(true);

                            if (txtFilterUPDT_USER_ID.Text.Length > 0)
                                strPrintUserId = txtFilterUPDT_USER_ID.Text;
                            else
                                strPrintUserId = "All Users";

                            if (txtFilterDateFrom.Text.Length > 0 && txtFilterDateTo.Text.Length > 0)
                                strPrintUpdateDt = "Between " + txtFilterDateFrom.Text + " And " + txtFilterDateTo.Text;
                            else
                                strPrintUpdateDt = "All Dates";

                            if (ddlFilterTBL_NM.SelectedValue.Length > 0)
                                strPrintTblName = ddlFilterTBL_NM.SelectedItem.Text;
                            else
                                strPrintTblName = "All Tables";

                            if (ddlFilterACTN.SelectedValue.Length > 0)
                            {
                                switch (ddlFilterACTN.SelectedValue)
                                {
                                    case "I": strPrintActionId = "INSERT"; break;
                                    case "U": strPrintActionId = "UPDATE"; break;
                                    case "D": strPrintActionId = "DELETE"; break;
                                }
                            }
                            else
                                strPrintActionId = "All Actions";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF AUDIT TRAIL", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("Update ID : " + strPrintUserId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell6 = new PdfPCell(new Phrase("Log Update Date : " + strPrintUpdateDt, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell6.Border = 0;
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0;
                            table.AddCell(cell6);

                            PdfPCell cell1 = new PdfPCell(new Phrase("Table Name : " + strPrintTblName, new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell1.Border = 0;
                            cell1.Colspan = 3;
                            cell1.HorizontalAlignment = 0;
                            table.AddCell(cell1);

                            PdfPCell cell4 = new PdfPCell(new Phrase("Action : " + strPrintActionId, new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell4.Border = 0;
                            cell4.Colspan = 3;
                            cell4.HorizontalAlignment = 0;
                            table.AddCell(cell4);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 20f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfAuditTrail.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "AuditTrailPrint.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "AuditTrailPrint.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfAuditTrail.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(true);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                                sb.Append('"' + val + '"' + ',');
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());

                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion

        #region Search User by name using AutoComplete Extender

        [WebMethod]
        public static List<string> fnSerchUserName(string prefixText, int count)// tested ok yogan.
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(prefixText, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''

            List<string> USER_NAME = new List<string>();

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                USER_NAME.Add(dr["USER_NAME"].ToString());
            }
            return USER_NAME;
        }
       

        protected void txtFilterName_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFilterName.Text))
            {
                DataTable dtCodeDetails = BusinessLogicClass.fnListUsers(txtFilterName.Text, string.Empty, string.Empty, string.Empty, string.Empty, false); //Yogan Added Search by Name according to SR''

                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtFilterUPDT_USER_ID.Text = dr["USER_ID"].ToString();
                }
            }
            else
            {
                txtFilterUPDT_USER_ID.Text = string.Empty;

            }
            txtFilterUPDT_USER_ID.Enabled = false;
        }

        #endregion
    }
}