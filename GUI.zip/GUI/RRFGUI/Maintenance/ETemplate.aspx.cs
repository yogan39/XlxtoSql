﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using RRFGUI.Library;
using System.Configuration;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Threading;
using System.Text;
using System.Web.Services;
using System.Text.RegularExpressions;

namespace RRFGUI.Maintenance
{
    public partial class ETemplate : System.Web.UI.Page
    {
        string strRPT_ID = string.Empty;
        string strSTATUS_ID = string.Empty;
        string strROW_NUM = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Label lblPage = (Label)Master.FindControl("lblPageName");
            lblPage.Text = "E-TEMPLATE MAINTENANCE";

            if (!IsPostBack)
            {
                TabContainerETemplate.ActiveTab = TabPanelListing;

                switch (Session["strRoleId"].ToString())
                {
                    case "Approver":
                    case "FGTAppvr":
                        chkbxFilterStatusPendingApproval.Checked = true;
                        break;
                }

                txtHdnDefaultReminderDays.Text = ConfigurationManager.AppSettings["REMINDER_DAYS_DEFAULT"].ToString();

                fnLoadUnitCode();
                fnLoadEntityCode();
                fnLoadRegulatorCode();
                fnLoadSREFCode();
                fnLoadReminderCode();
                fnLoadFrequencyCode();
                fnLoadBizDayOffCode();
                fnLoadSubmissionCode();
                fnLoadStatusCode();
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                //megatshamsul - 20170314 - SR1363674 - load ordinal day number
                fnLoadPositionDates();
            }
        }

        #region PreLoading

        private void fnLoadUnitCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadUnitCode(Session["strUserId"].ToString());

            ddlUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlUNIT_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["UNIT_CODE_NM"].ToString(), dr["UNIT_CODE"].ToString()));
            }
        }

        private void fnLoadEntityCode()
        {
            //megatshamsul - 20170420 - SR1363674 - Entities loaded from table instead
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMBANK", "AMBANK"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMBANK ISLAMIC", "AMBANK ISLAMIC"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMIL", "AMIL"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMINVESTMENT", "AMINVESTMENT"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AmFuture", "AmFuture"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AMMB Holdings Berhad", "AMMB Holdings Berhad"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AmSec Nom (A) Sdn Bhd", "AmSec Nom (A) Sdn Bhd"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AmSec Nom (T) Sdn Bhd", "AmSec Nom (T) Sdn Bhd"));
            //ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("AmSecurities Holding Sdn Bhd", "AmSecurities Holding Sdn Bhd"));

            DataTable dtCodeDetails = BusinessLogicClass.fnLoadEntityCode(Session["strUserId"].ToString());

            ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlENTITY_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["ENTITY_CODE_NM"].ToString(), dr["ENTITY_CODE"].ToString()));
            }
        }

        private void fnLoadRegulatorCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadRegulatorCode(Session["strUserId"].ToString());

            ddlFilterREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["REGULATOR_DESC"].ToString(), dr["REGULATOR_ID"].ToString()));
                ddlREGULATOR_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["REGULATOR_DESC"].ToString(), dr["REGULATOR_ID"].ToString()));
            }
        }

        private void fnLoadSREFCode()
        {
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Monetary Penalty)", "1"));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Non-Monetary Penalty)", "2"));
            ddlFilterSREF.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));

            ddlSREF.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Monetary Penalty)", "1"));
            ddlSREF.Items.Add(new System.Web.UI.WebControls.ListItem("Yes(Non-Monetary Penalty)", "2"));
            ddlSREF.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void fnLoadReminderCode()
        {
            ddlREMINDER_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlREMINDER_ID.Items.Add(new System.Web.UI.WebControls.ListItem("Yes", "Y"));
            ddlREMINDER_ID.Items.Add(new System.Web.UI.WebControls.ListItem("No", "N"));
        }

        private void fnLoadFrequencyCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadFrequencyCode(Session["strUserId"].ToString());

            ddlFilterFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("All", ""));
            ddlFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlFilterFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["FREQUENCY_DESC"].ToString(), dr["FREQUENCY_ID"].ToString()));
                ddlFREQUENCY_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["FREQUENCY_DESC"].ToString(), dr["FREQUENCY_ID"].ToString()));
            }
        }

        private void fnLoadBizDayOffCode()
        {
            ddlBIZ_DAY_ONLY.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlBIZ_DAY_ONLY.Items.Add(new System.Web.UI.WebControls.ListItem("Working Day", "Y"));
            ddlBIZ_DAY_ONLY.Items.Add(new System.Web.UI.WebControls.ListItem("Calendar Day", "N"));
        }

        private void fnLoadSubmissionCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadSubmissionCode(Session["strUserId"].ToString());

            ddlSUBMISSION_MODE_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlSUBMISSION_MODE_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["SUBMISSION_MODE_DESC"].ToString(), dr["SUBMISSION_MODE_ID"].ToString()));
            }
        }

        private void fnLoadStatusCode()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadApprovalStatusCode(Session["strUserId"].ToString());

            ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            
            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlSTATUS_ID.Items.Add(new System.Web.UI.WebControls.ListItem(dr["STATUS_DESC"].ToString(), dr["STATUS_ID"].ToString()));
            }
        }

        private void ShowMessage(string sMsgId, string sFieldId)
        {
            StringBuilder strScript = new StringBuilder();
            strScript.Append("$(window).load(function(){");

            if (!string.IsNullOrEmpty(sMsgId))
                strScript.Append("alert('" + sMsgId + "');");

            if (!string.IsNullOrEmpty(sFieldId))
            {
                strScript.Append("try {");
                strScript.Append("document.getElementById('" + sFieldId + "').focus();");
                strScript.Append("} catch (err){ alert('err'); }");
            }

            strScript.Append("});");

            Page.ClientScript.RegisterStartupScript(this.GetType(), "Focus", strScript.ToString(), true);
        }

        //megatshamsul - 20170314 - SR1363674 - load ordinal day number
        private void fnLoadPositionDates()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnLoadOrdinalNumber(Session["strUserId"].ToString());

            ddlPOSITION_DATE.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlWeekly_POSITION_DATE_1.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlWeekly_POSITION_DATE_2.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlWeekly_POSITION_DATE_3.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));
            ddlWeekly_POSITION_DATE_4.Items.Add(new System.Web.UI.WebControls.ListItem("", ""));

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                ddlPOSITION_DATE.Items.Add(new System.Web.UI.WebControls.ListItem(dr[0].ToString(), dr[0].ToString()));
                ddlWeekly_POSITION_DATE_1.Items.Add(new System.Web.UI.WebControls.ListItem(dr[0].ToString(), dr[0].ToString()));
                ddlWeekly_POSITION_DATE_2.Items.Add(new System.Web.UI.WebControls.ListItem(dr[0].ToString(), dr[0].ToString()));
                ddlWeekly_POSITION_DATE_3.Items.Add(new System.Web.UI.WebControls.ListItem(dr[0].ToString(), dr[0].ToString()));
                ddlWeekly_POSITION_DATE_4.Items.Add(new System.Web.UI.WebControls.ListItem(dr[0].ToString(), dr[0].ToString()));
            }
        }

        #endregion

        #region Listing

        protected void grdvwListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            strRPT_ID = grdvwListing.SelectedRow.Cells[1].Text;
            strSTATUS_ID = grdvwListing.SelectedRow.Cells[8].Text;
            strROW_NUM = grdvwListing.SelectedRow.Cells[9].Text;

            txtHdnFromListing.Text = "L";

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListing_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListing_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListing.PageIndex = e.NewPageIndex;
            fnBindListing(false);
        }

        protected void grdvwListing_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[8].Visible = false;    //hide STATUS_ID
                e.Row.Cells[9].Visible = false;    //hide ROW_NUM
            }
        }

        protected void btnListRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListing(false);
        }

        private void fnBindListing(bool ifExport)
        {
            bool ifOK = false;

            if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ifOK = true;
            }
            else if (string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date From", txtFilterDateFrom.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                ShowMessage("Please select Date To", txtFilterDateTo.ClientID.ToString());
            }
            else if (!string.IsNullOrEmpty(txtFilterDateFrom.Text) && !string.IsNullOrEmpty(txtFilterDateTo.Text))
            {
                if (BusinessLogicClass.fnValidateDatesRange(txtFilterDateFrom.Text, txtFilterDateTo.Text))
                    ifOK = true;
                else
                    ShowMessage("Please select correct Date range", txtFilterDateFrom.ClientID.ToString());
            }

            if (ifOK)
            {
                if (!string.IsNullOrEmpty(txtFilterRPT_ID.Text))
                {
                    if (txtFilterRPT_ID.Text.Length < 9)
                    {
                        txtFilterRPT_ID.Text = txtFilterRPT_ID.Text.PadLeft(9, '0');
                    }
                }

                DataTable dtCodeDetails = BusinessLogicClass.fnListETemplates(txtFilterRPT_ID.Text, txtFilterRPT_NAME.Text, ddlFilterREGULATOR_ID.SelectedValue, ddlFilterSREF.SelectedValue, ddlFilterFREQUENCY_ID.SelectedValue, chkbxFilterStatusAll.Checked, chkbxFilterStatusDraft.Checked, chkbxFilterStatusNew.Checked, chkbxFilterStatusApproved.Checked, chkbxFilterStatusRejected.Checked, chkbxFilterStatusPendingApproval.Checked, txtFilterDateFrom.Text, txtFilterDateTo.Text, Session["strUserId"].ToString(), Session["strUnitId"].ToString(), Session["strRoleId"].ToString(), ifExport, false);
                grdvwListing.DataSource = dtCodeDetails;
                grdvwListing.DataBind();

                if (!ifExport)
                    lblTotalListing.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
            }
        }

        #endregion

        #region Listing Reject Bucket

        protected void grdvwListingRejectBucket_SelectedIndexChanged(object sender, EventArgs e)
        {
            strRPT_ID = grdvwListingRejectBucket.SelectedRow.Cells[1].Text;
            strSTATUS_ID = grdvwListingRejectBucket.SelectedRow.Cells[8].Text;
            strROW_NUM = grdvwListingRejectBucket.SelectedRow.Cells[9].Text;

            txtHdnFromListing.Text = "R";

            string strMessage = string.Empty;
            strMessage = fnShowSelectedData();

            if (strMessage != string.Empty)
                ShowMessage(strMessage, string.Empty);
        }

        protected void grdvwListingRejectBucket_RowCreated(object sender, GridViewRowEventArgs e)
        {
        }

        protected void grdvwListingRejectBucket_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdvwListingRejectBucket.PageIndex = e.NewPageIndex;
            fnBindListingReject();
        }

        protected void grdvwListingRejectBucket_OnRowDataBound(Object Sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header || e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[8].Visible = false;    //hide STATUS_ID
                e.Row.Cells[9].Visible = false;    //hide ROW_NUM
            }
        }

        protected void btnListRejectBucketRefresh_OnClick(object sender, EventArgs e)
        {
            fnBindListingReject();
        }

        private void fnBindListingReject()
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnListETemplates(string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, false, false, false, false, true, false, string.Empty, string.Empty, Session["strUserId"].ToString(), Session["strUnitId"].ToString(), Session["strRoleId"].ToString(), false, true);
            grdvwListingRejectBucket.DataSource = dtCodeDetails;
            grdvwListingRejectBucket.DataBind();

            lblTotalListingRejectBucket.Text = "Total: " + dtCodeDetails.Rows.Count.ToString();
        }

        #endregion

        #region Details

        private string fnShowSelectedData()
        {
            TabContainerETemplate.ActiveTab = TabPanelDetails;

            string strMessage = string.Empty;
            System.Web.UI.WebControls.ListItem oListItem;

            DataTable dtCodeDetails = BusinessLogicClass.fnGetETemplateDetails(strRPT_ID, strSTATUS_ID, strROW_NUM, Session["strUnitId"].ToString(), Session["strUserId"].ToString(), Session["strRoleId"].ToString());

            if (dtCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtCodeDetails.Rows)
                {
                    txtHdnROW_NUM.Text = strROW_NUM;

                    txtRPT_ID.Text = strRPT_ID;
                    txtRPT_NAME.Text = dr["RPT_NAME"].ToString();
                    txtHdnRPT_NAME.Text = txtRPT_NAME.Text;

                    oListItem = ddlUNIT_ID.Items.FindByValue(dr["UNIT_ID"].ToString());
                    if (oListItem != null)
                        ddlUNIT_ID.SelectedValue = oListItem.Value;

                    fnGetOrganizationDetails(dr["UNIT_ID"].ToString());

                    oListItem = ddlENTITY_ID.Items.FindByValue(dr["ENTITY_ID"].ToString());
                    if (oListItem != null)
                        ddlENTITY_ID.SelectedValue = oListItem.Value;

                    oListItem = ddlREGULATOR_ID.Items.FindByValue(dr["REGULATOR_ID"].ToString());
                    if (oListItem != null)
                        ddlREGULATOR_ID.SelectedValue = oListItem.Value;

                    txtREGULATOR_DEPT.Text = dr["REGULATOR_DEPT"].ToString();

                    oListItem = ddlSREF.Items.FindByValue(dr["SREF"].ToString());
                    if (oListItem != null)
                        ddlSREF.SelectedValue = oListItem.Value;

                    oListItem = ddlREMINDER_ID.Items.FindByValue(dr["REMINDER_ID"].ToString());
                    if (oListItem != null)
                        ddlREMINDER_ID.SelectedValue = oListItem.Value;

                    txtREMINDER_DAYS.Text = dr["REMINDER_DAYS"].ToString();

                    oListItem = ddlFREQUENCY_ID.Items.FindByValue(dr["FREQUENCY_ID"].ToString());
                    if (oListItem != null)
                        ddlFREQUENCY_ID.SelectedValue = oListItem.Value;

                    switch (ddlFREQUENCY_ID.SelectedValue)
                    {
                        case "2":   //weekly
                        case "4":   //monthly
                            TrEOMRemarks.Visible = true; break;
                        default:
                            TrEOMRemarks.Visible = false; break;
                    }

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly/monthly
                    oListItem = ddlBIZ_DAY_ONLY.Items.FindByValue(dr["BIZ_DAY_ONLY"].ToString());
                    if (oListItem != null)
                        ddlBIZ_DAY_ONLY.SelectedValue = oListItem.Value;

                    DataTable dtCodeDetailsAdHoc, dtCodeDetailsWeekly;
                    TextBox TextBox1 = null;
                    TextBox TextBox2 = null;
                    string ObjectId = string.Empty;
                    int y = 1;

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    DropDownList DropDownList1 = null;

                    fnResetFrequencyFields();

                    switch (ddlFREQUENCY_ID.SelectedValue)
                    {
                        case "9":   //6 times yearly
                        case "10":	//Adhoc

                            if (ddlFREQUENCY_ID.SelectedValue == "9")
                            {
                                //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                                //EnableFrequencyNormalFields(false, false);
                                EnableFrequencyNormalFields(false, false, false);

                                EnableFrequencyAdHocFields(false, false);
                                EnableFrequency6XYearlyFields(false, true);
                            }
                            else if (ddlFREQUENCY_ID.SelectedValue == "10")
                            {
                                //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                                //EnableFrequencyNormalFields(false, false);
                                EnableFrequencyNormalFields(false, false, false);

                                EnableFrequencyAdHocFields(false, true);
                                EnableFrequency6XYearlyFields(false, false);
                            }

                            //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                            EnableFrequencyWeeklyFields(false, false);

                            //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                            EnableFrequencyMonthlyFields(false, false);

                            dtCodeDetailsAdHoc = BusinessLogicClass.fnGetETemplateAdHocDetails(strROW_NUM, Session["strUserId"].ToString());

                            if (dtCodeDetailsAdHoc.Rows.Count > 0)
                            {
                                foreach (DataRow drAdHoc in dtCodeDetailsAdHoc.Rows)
                                {
                                    if (ddlFREQUENCY_ID.SelectedValue == "9")
                                    {
                                        ObjectId = "txt6XYearly_POSITION_DATE_" + y;
                                        TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                                        ObjectId = "txt6XYearly_TARGET_SUBMISSION_DATE_" + y;
                                        TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;
                                    }
                                    else if (ddlFREQUENCY_ID.SelectedValue == "10")
                                    {
                                        ObjectId = "txtAdHoc_POSITION_DATE_" + y;
                                        TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                                        ObjectId = "txtAdHoc_TARGET_SUBMISSION_DATE_" + y;
                                        TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;
                                    }

                                    if (TextBox1 != null && TextBox2 != null)
                                    {
                                        TextBox1.Text = drAdHoc["POSITION_DATE"].ToString();
                                        TextBox2.Text = drAdHoc["TARGET_SUBMISSION_DATE"].ToString();
                                    }

                                    y++;
                                }
                            }

                            break;

                        case "2": //megatshamsul - 20170314 - SR1363674 - update frequency weekly

                            y = 1;

                            EnableFrequencyNormalFields(false, false, true);
                            EnableFrequencyAdHocFields(false, false);
                            EnableFrequency6XYearlyFields(false, false);
                            EnableFrequencyWeeklyFields(false, true);
                            EnableFrequencyMonthlyFields(false, false);

                            dtCodeDetailsWeekly = BusinessLogicClass.fnGetETemplateWeeklyDetails(strROW_NUM, Session["strUserId"].ToString());

                            if (dtCodeDetailsWeekly.Rows.Count > 0)
                            {
                                foreach (DataRow drWeekly in dtCodeDetailsWeekly.Rows)
                                {
                                    ObjectId = "ddlWeekly_POSITION_DATE_" + y;
                                    DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                                    ObjectId = "txtWeekly_TPLUS_SUBMISSION_DAY_" + y;
                                    TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                                    if (DropDownList1 != null && TextBox1 != null)
                                    {
                                        oListItem = DropDownList1.Items.FindByValue(drWeekly["WEEKLY_POSITION_DATE"].ToString());
                                        if (oListItem != null)
                                            DropDownList1.SelectedValue = oListItem.Value;

                                        TextBox1.Text = drWeekly["TPLUS_WEEKLY_SUBMISSION_DATE"].ToString();
                                    }

                                    y++;
                                }
                            }

                            break;

                        case "4": //megatshamsul - 20170314 - SR1363674 - update frequency monthly

                            EnableFrequencyNormalFields(false, true, false);
                            EnableFrequencyAdHocFields(false, false);
                            EnableFrequency6XYearlyFields(false, false);
                            EnableFrequencyWeeklyFields(false, false);
                            EnableFrequencyMonthlyFields(false, true);

                            oListItem = ddlPOSITION_DATE.Items.FindByValue(dr["POSITION_DATE"].ToString());
                            if (oListItem != null)
                                ddlPOSITION_DATE.SelectedValue = oListItem.Value;

                            txtT_PLUS_SUBMISSION_DATE.Text = dr["T_PLUS_SUBMISSION_DATE"].ToString();

                           
                                
                            break;

                        default:

                            //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                            //EnableFrequencyNormalFields(false, true);
                            EnableFrequencyNormalFields(false, true, false);

                            EnableFrequencyAdHocFields(false, false);
                            EnableFrequency6XYearlyFields(false, false);

                            //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                            EnableFrequencyWeeklyFields(false, false);

                            //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                            EnableFrequencyMonthlyFields(false, false);

                            txtT_PLUS_SUBMISSION_DATE.Text = dr["T_PLUS_SUBMISSION_DATE"].ToString();

                            break;
                    }
                    
                    oListItem = ddlSUBMISSION_MODE_ID.Items.FindByValue(dr["SUBMISSION_MODE_ID"].ToString());
                    if (oListItem != null)
                        ddlSUBMISSION_MODE_ID.SelectedValue = oListItem.Value;

                    txtEFF_POSITION_DATE.Text = dr["EFF_POSITION_DATE"].ToString();
                    txtEXP_POSITION_DATE.Text = dr["EXP_POSITION_DATE"].ToString();

                    txtREPORT_CONSOLIDATER.Text = dr["REPORT_CONSOLIDATER"].ToString();
                    txtREPORT_CONTRIBUTOR1.Text = dr["REPORT_CONTRIBUTOR1"].ToString();
                    txtREPORT_CONTRIBUTOR2.Text = dr["REPORT_CONTRIBUTOR2"].ToString();
                    txtREPORT_CONTRIBUTOR3.Text = dr["REPORT_CONTRIBUTOR3"].ToString();
                    txtREPORT_CONTRIBUTOR4.Text = dr["REPORT_CONTRIBUTOR4"].ToString();

                    txtREMARKS.Text = dr["REMARKS"].ToString();

                    oListItem = ddlSTATUS_ID.Items.FindByValue(strSTATUS_ID);
                    if (oListItem != null)
                        ddlSTATUS_ID.SelectedValue = oListItem.Value;

                    txtCREATE_DATE.Text = dr["CREATE_DATE"].ToString();
                    txtPREPARER_ID.Text = dr["PREPARER_ID"].ToString();
                    txtPREPARER_DATE.Text = dr["PREPARER_DATE"].ToString();
                    txtAPPROVER_ID.Text = dr["APPROVER_ID"].ToString();
                    txtAPPROVER_DATE.Text = dr["APPROVER_DATE"].ToString();
                    txtAPPROVER_FGT_ID.Text = dr["APPROVER_FGT_ID"].ToString();
                    txtAPPROVER_FGT_DATE.Text = dr["APPROVER_FGT_DATE"].ToString();

                    txtREJECT_REASON.Text = dr["REJECT_REASON"].ToString();
                }

                txtREJECT_REASON.Enabled = false;
                btnApproval.Enabled = false;
                btnApproval.Visible = false;
                lblApprovalButtonSpace.Visible = false;
                btnReject.Enabled = false;
                btnReject.Visible = false;

                switch (Session["strRoleId"].ToString())
                {
                    case "Approver":
                        
                        switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "N":
                            case "U":
                            case "XR":
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = true;
                                btnApproval.Visible = true;
                                lblApprovalButtonSpace.Visible = true;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                        }

                        break;

                    case "FGTAppvr":

                    switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "AP1":
                            case "APX1":
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = true;
                                btnApproval.Visible = true;
                                lblApprovalButtonSpace.Visible = true;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                            case "AP2": //only FGT can reject an approved rec
                                txtREJECT_REASON.Enabled = true;
                                btnApproval.Enabled = false;
                                btnApproval.Visible = false;
                                lblApprovalButtonSpace.Visible = false;
                                btnReject.Enabled = true;
                                btnReject.Visible = true;
                                break;
                        }

                        break;

                    case "Preparer":

                        //disable updates button if already submitted
                        switch (ddlSTATUS_ID.SelectedValue)
                        {
                            case "D1":
                            case "D2":
                            case "D3":
                            case "RJ1":
                            case "RJ2":
                            case "RJX1":
                            case "RJX2":
                                EnableFieldsForAddEdit("U", true);
                                break;
                            default:
                                EnableFieldsForAddEdit("U", false);
                                break;
                        }

                        break;
                    
                }

            }
            else
                strMessage = "No record found";

            return strMessage;
        }

        private void fnGetOrganizationDetails(string strUnit_Id)
        {
            DataTable dtUnitCodeDetails = BusinessLogicClass.fnGetUnitDetails(strUnit_Id);

            if (dtUnitCodeDetails.Rows.Count > 0)
            {
                foreach (DataRow drUnit in dtUnitCodeDetails.Rows)
                {
                    txtDEPT_ID.Text = drUnit["DEPT_CODE_NM"].ToString();
                    txtLOB_ID.Text = drUnit["LOB_CODE_NM"].ToString();
                    txtHOD.Text = drUnit["HOD"].ToString();
                }
            }
            else
            {
                txtDEPT_ID.Text = "";
                txtLOB_ID.Text = "";
                txtHOD.Text = "";
            }
        }

        [WebMethod]
        public static object fnGetUnitDetails(string sUnitId)
        {
            DataTable dtCodeDetails = BusinessLogicClass.fnGetUnitDetails(sUnitId);

            string[] theListing = new string[3];

            foreach (DataRow dr in dtCodeDetails.Rows)
            {
                theListing[0] = dr["DEPT_CODE_NM"].ToString();
                theListing[1] = dr["LOB_CODE_NM"].ToString();
                theListing[2] = dr["HOD"].ToString();
            }

            return new { Listing = theListing };
        }

        protected void btnNew_OnClick(object sender, EventArgs e)
        {
            fnResetEditForm();
            EnableFieldsForAddEdit("I", true);
            txtEFF_POSITION_DATE.Text = BusinessLogicClass.GetDDMMYYYY(DateTime.Now);
            txtEXP_POSITION_DATE.Text = "31/12/9999";
            TabContainerETemplate.ActiveTab = TabPanelDetails;
        }

        protected void btnAddETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("I"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("I", ddlSTATUS_ID.SelectedValue, "D1", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    DataTable dtEmailCC = new DataTable();
                    string sEmailSubject = "New E-Template Created In Your Queue";
                    string sEmailBody = "E-Template report name " + sRptName + " has been saved in your queue by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ").";
                    
                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerETemplate.ActiveTab = TabPanelListing;
            }
        }

        protected void btnAddSubmitETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("I"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("I", ddlSTATUS_ID.SelectedValue, "N", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = "New E-Template Has Been Submitted For Approval";
                    string sEmailBody = "E-Template report name " + sRptName + " has been submitted by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is in Approvers queue. Please act accordingly.";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerETemplate.ActiveTab = TabPanelListing;
            }
        }

        protected void btnUpdateETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("U"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("U", ddlSTATUS_ID.SelectedValue, "D2", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    DataTable dtEmailCC = new DataTable();
                    string sEmailSubject = "Updated E-Template Created In Your Queue";
                    string sEmailBody = "E-Template report name " + sRptName + " has been saved in your queue by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ").";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerETemplate.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerETemplate.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnUpdateSubmitETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("U"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("U", ddlSTATUS_ID.SelectedValue, "U", ref ifSuccess), string.Empty);
                string sRptName = txtRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = "Updated E-Template Has Been Submitted For Approval";
                    string sEmailBody = "E-Template report name " + sRptName + " has been submitted by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is in Approvers queue. Please act accordingly.";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerETemplate.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerETemplate.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnDeleteETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("D"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("D", ddlSTATUS_ID.SelectedValue, "D3", ref ifSuccess), string.Empty);
                string sRptName = txtHdnRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    DataTable dtEmailCC = new DataTable();
                    string sEmailSubject = "Discontinue E-Template Created In Your Queue";
                    string sEmailBody = "E-Template report name " + sRptName + " has been saved in your queue by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ").";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerETemplate.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerETemplate.ActiveTab = TabPanelListingReject;
            }
        }

        protected void btnDeleteSubmitETemplate_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsAddEdit("D"))
            {
                bool ifSuccess = false;
                ShowMessage(fnUpdateETemplate("D", ddlSTATUS_ID.SelectedValue, "XR", ref ifSuccess), string.Empty);
                string sRptName = txtHdnRPT_NAME.Text;
                fnResetEditForm();
                fnBindListing(false);
                fnBindListingReject();

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(Session["strUnitId"].ToString(), "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = "Discontinue E-Template Has Been Submitted For Approval";
                    string sEmailBody = "E-Template report name " + sRptName + " has been submitted by by Preparer " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is in Approvers queue. Please act accordingly.";

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                if (txtHdnFromListing.Text == "L")
                    TabContainerETemplate.ActiveTab = TabPanelListing;
                else if (txtHdnFromListing.Text == "R")
                    TabContainerETemplate.ActiveTab = TabPanelListingReject;
            }
        }

        private string fnUpdateETemplate(string Update_Type, string Status_Id_Prev, string Status_Id_Next, ref bool ifSuccess)
        {
            DataTable dtCodeDetails = new DataTable("DataTypeUpdateETemplate");
            dtCodeDetails.Columns.Add("ROW_NUM", typeof(string));
            dtCodeDetails.Columns.Add("RPT_ID", typeof(string));
            dtCodeDetails.Columns.Add("RPT_NAME", typeof(string));
            dtCodeDetails.Columns.Add("UNIT_ID", typeof(string));
            dtCodeDetails.Columns.Add("ENTITY_ID", typeof(string));
            dtCodeDetails.Columns.Add("REGULATOR_ID", typeof(string));
            dtCodeDetails.Columns.Add("REGULATOR_DEPT", typeof(string));
            dtCodeDetails.Columns.Add("SREF", typeof(string));
            dtCodeDetails.Columns.Add("REMINDER_ID", typeof(string));
            dtCodeDetails.Columns.Add("REMINDER_DAYS", typeof(string));
            dtCodeDetails.Columns.Add("FREQUENCY_ID", typeof(string));
            dtCodeDetails.Columns.Add("T_PLUS_SUBMISSION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("BIZ_DAY_ONLY", typeof(string));
            dtCodeDetails.Columns.Add("SUBMISSION_MODE_ID", typeof(string));
            dtCodeDetails.Columns.Add("EFF_POSITION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("EXP_POSITION_DATE", typeof(string));
            dtCodeDetails.Columns.Add("REPORT_CONSOLIDATER", typeof(string));
            dtCodeDetails.Columns.Add("REPORT_CONTRIBUTOR1", typeof(string));
            dtCodeDetails.Columns.Add("REPORT_CONTRIBUTOR2", typeof(string));
            dtCodeDetails.Columns.Add("REPORT_CONTRIBUTOR3", typeof(string));
            dtCodeDetails.Columns.Add("REPORT_CONTRIBUTOR4", typeof(string));
            dtCodeDetails.Columns.Add("REMARKS", typeof(string));

            //megatshamsul - 20170314 - SR1363674 - update frequency monthly
            dtCodeDetails.Columns.Add("POSITION_DATE", typeof(string));

            DataRow drCodeDetails = dtCodeDetails.NewRow();

            drCodeDetails["ROW_NUM"] = txtHdnROW_NUM.Text.ToString();
            drCodeDetails["RPT_ID"] = txtRPT_ID.Text.ToString();
            drCodeDetails["RPT_NAME"] = txtRPT_NAME.Text.ToString();
            drCodeDetails["UNIT_ID"] = ddlUNIT_ID.SelectedValue.ToString();
            drCodeDetails["ENTITY_ID"] = ddlENTITY_ID.SelectedValue.ToString();
            drCodeDetails["REGULATOR_ID"] = ddlREGULATOR_ID.SelectedValue.ToString();
            drCodeDetails["REGULATOR_DEPT"] = txtREGULATOR_DEPT.Text.ToString();
            drCodeDetails["SREF"] = ddlSREF.SelectedValue.ToString();
            drCodeDetails["REMINDER_ID"] = ddlREMINDER_ID.SelectedValue.ToString();
            drCodeDetails["REMINDER_DAYS"] = txtREMINDER_DAYS.Text.ToString();
            drCodeDetails["FREQUENCY_ID"] = ddlFREQUENCY_ID.SelectedValue.ToString();
            drCodeDetails["T_PLUS_SUBMISSION_DATE"] = txtT_PLUS_SUBMISSION_DATE.Text.ToString();
            drCodeDetails["BIZ_DAY_ONLY"] = ddlBIZ_DAY_ONLY.SelectedValue.ToString();
            drCodeDetails["SUBMISSION_MODE_ID"] = ddlSUBMISSION_MODE_ID.SelectedValue.ToString();
            drCodeDetails["EFF_POSITION_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtEFF_POSITION_DATE.Text.ToString());
            drCodeDetails["EXP_POSITION_DATE"] = BusinessLogicClass.SetYYYYMMDD(txtEXP_POSITION_DATE.Text.ToString());
            drCodeDetails["REPORT_CONSOLIDATER"] = txtREPORT_CONSOLIDATER.Text.ToString();
            drCodeDetails["REPORT_CONTRIBUTOR1"] = txtREPORT_CONTRIBUTOR1.Text.ToString();
            drCodeDetails["REPORT_CONTRIBUTOR2"] = txtREPORT_CONTRIBUTOR2.Text.ToString();
            drCodeDetails["REPORT_CONTRIBUTOR3"] = txtREPORT_CONTRIBUTOR3.Text.ToString();
            drCodeDetails["REPORT_CONTRIBUTOR4"] = txtREPORT_CONTRIBUTOR4.Text.ToString();
            drCodeDetails["REMARKS"] = txtREMARKS.Text.ToString();

            //megatshamsul - 20170314 - SR1363674 - update frequency monthly
            drCodeDetails["POSITION_DATE"] = ddlPOSITION_DATE.SelectedValue.ToString(); ;

            dtCodeDetails.Rows.Add(drCodeDetails);

            DataTable dtCodeDetailsAdhoc = new DataTable("DataTypeUpdateETemplateAdHoc");
            
            dtCodeDetailsAdhoc.Columns.Add("REC_NO", typeof(string));
            dtCodeDetailsAdhoc.Columns.Add("POSITION_DATE", typeof(string));
            dtCodeDetailsAdhoc.Columns.Add("TARGET_SUBMISSION_DATE", typeof(string));

            DataRow drCodeDetailsAdHoc;
            TextBox TextBox1;
            TextBox TextBox2;
            string ObjectId = string.Empty;
            int x = 0;

            switch (ddlFREQUENCY_ID.SelectedValue)
            {
                case "9":   //6 times yearly

                    for (int y=1; y<=6; y++)
                    {
                        ObjectId = "txt6XYearly_POSITION_DATE_" + y;
                        TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                        ObjectId = "txt6XYearly_TARGET_SUBMISSION_DATE_" + y;
                        TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                        if (TextBox1 != null && TextBox2 != null)
                        {
                            if (BusinessLogicClass.fnValidateDatesRange(TextBox1.Text, TextBox2.Text))
                            {
                                drCodeDetailsAdHoc = dtCodeDetailsAdhoc.NewRow();

                                x = x + 1;
                                drCodeDetailsAdHoc["REC_NO"] = x.ToString();
                                drCodeDetailsAdHoc["POSITION_DATE"] = BusinessLogicClass.SetYYYYMMDD(TextBox1.Text.ToString());
                                drCodeDetailsAdHoc["TARGET_SUBMISSION_DATE"] = BusinessLogicClass.SetYYYYMMDD(TextBox2.Text.ToString());
        
                                dtCodeDetailsAdhoc.Rows.Add(drCodeDetailsAdHoc);
                            }
                        }
                    }

                    break;

                case "10":	//Adhoc

                    for (int y = 1; y <= 12; y++)
                    {
                        ObjectId = "txtAdHoc_POSITION_DATE_" + y;
                        TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                        ObjectId = "txtAdHoc_TARGET_SUBMISSION_DATE_" + y;
                        TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                        if (TextBox1 != null && TextBox2 != null)
                        {
                            if (BusinessLogicClass.fnValidateDatesRange(TextBox1.Text, TextBox2.Text))
                            {
                                drCodeDetailsAdHoc = dtCodeDetailsAdhoc.NewRow();

                                x = x + 1;
                                drCodeDetailsAdHoc["REC_NO"] = x.ToString();
                                drCodeDetailsAdHoc["POSITION_DATE"] = BusinessLogicClass.SetYYYYMMDD(TextBox1.Text.ToString());
                                drCodeDetailsAdHoc["TARGET_SUBMISSION_DATE"] = BusinessLogicClass.SetYYYYMMDD(TextBox2.Text.ToString());

                                dtCodeDetailsAdhoc.Rows.Add(drCodeDetailsAdHoc);
                            }
                        }
                    }

                    break;
            }

            //megatshamsul - 20170314 - SR1363674 - START update frequency weekly

            DataTable dtCodeDetailsWeekly = new DataTable("DataTypeUpdateETemplateWeekly");

            dtCodeDetailsWeekly.Columns.Add("WEEK_NO", typeof(string));
            dtCodeDetailsWeekly.Columns.Add("WEEKLY_POSITION_DATE", typeof(string));
            dtCodeDetailsWeekly.Columns.Add("TPLUS_WEEKLY_SUBMISSION_DATE", typeof(string));

            DataRow drCodeDetailsWeekly;
            DropDownList DropDownList1;
            
            if (ddlFREQUENCY_ID.SelectedValue == "2")   //weekly
            {
                for (int y = 1; y <= 4; y++)
                {
                    ObjectId = "ddlWeekly_POSITION_DATE_" + y;
                    DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                    ObjectId = "txtWeekly_TPLUS_SUBMISSION_DAY_" + y;
                    TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                    if (DropDownList1 != null && TextBox1 != null)
                    {
                        drCodeDetailsWeekly = dtCodeDetailsWeekly.NewRow();

                        drCodeDetailsWeekly["WEEK_NO"] = y.ToString();
                        drCodeDetailsWeekly["WEEKLY_POSITION_DATE"] = DropDownList1.SelectedValue.ToString();
                        drCodeDetailsWeekly["TPLUS_WEEKLY_SUBMISSION_DATE"] = TextBox1.Text.ToString();

                        dtCodeDetailsWeekly.Rows.Add(drCodeDetailsWeekly);
                    }
                }
            }

            //megatshamsul - 20170314 - SR1363674 - END update frequency monthly 

            //megatshamsul - 20170314 - SR1363674 - update frequency weekly
            //string strMessage = BusinessLogicClass.fnUpdateETemplateDetails(Update_Type, Status_Id_Prev, Status_Id_Next, dtCodeDetails, dtCodeDetailsAdhoc, Session["strUserId"].ToString(), ref ifSuccess);
            string strMessage = BusinessLogicClass.fnUpdateETemplateDetails(Update_Type, Status_Id_Prev, Status_Id_Next, dtCodeDetails, dtCodeDetailsAdhoc, dtCodeDetailsWeekly, Session["strUserId"].ToString(), ref ifSuccess);

            return strMessage;
        }

        protected void ddlFREQUENCY_ID_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (ddlFREQUENCY_ID.SelectedValue)
            {
                case "9":   //6 times yearly

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(false, false);
                    EnableFrequencyNormalFields(false, false, true);

                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(true, true);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    TrEOMRemarks.Visible = false;

                    break;

                case "10":	//Adhoc

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(false, false);
                    EnableFrequencyNormalFields(false, false, true);

                    EnableFrequencyAdHocFields(true, true);
                    EnableFrequency6XYearlyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    TrEOMRemarks.Visible = false;

                    break;

                case "2":   //megatshamsul - 20170314 - SR1363674 - updated frequency weekly

                    EnableFrequencyNormalFields(false, false, true);
                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);
                    EnableFrequencyWeeklyFields(true, true);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    TrEOMRemarks.Visible = true;

                    break;

                case "4":   //megatshamsul - 20170314 - SR1363674 - updated frequency monthly

                    EnableFrequencyNormalFields(true, true, false);
                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);
                    EnableFrequencyWeeklyFields(false, false);
                    EnableFrequencyMonthlyFields(true, true);

                    TrEOMRemarks.Visible = true;

                    break;

                default:

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(true, true);
                    EnableFrequencyNormalFields(true, true, false);

                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    TrEOMRemarks.Visible = false;

                    break;

            }
        }

        private void fnResetEditForm()
        {
            txtRPT_ID.Text = "";
            txtRPT_ID.Enabled = false;

            txtRPT_NAME.Text = "";
            txtRPT_NAME.Enabled = false;

            ddlUNIT_ID.SelectedIndex = -1;
            ddlUNIT_ID.Enabled = false;

            txtDEPT_ID.Text = "";
            txtDEPT_ID.Enabled = false;

            txtLOB_ID.Text = "";
            txtLOB_ID.Enabled = false;

            txtHOD.Text = "";
            txtHOD.Enabled = false;

            ddlENTITY_ID.SelectedIndex = -1;
            ddlENTITY_ID.Enabled = false;

            ddlREGULATOR_ID.SelectedIndex = -1;
            ddlREGULATOR_ID.Enabled = false;

            txtREGULATOR_DEPT.Text = "";
            txtREGULATOR_DEPT.Enabled = false;

            ddlSREF.SelectedIndex = -1;
            ddlSREF.Enabled = false;

            ddlREMINDER_ID.SelectedIndex = -1;
            ddlREMINDER_ID.Enabled = false;

            lblMandatoryREMINDER_DAYS.Style.Remove("display");
            lblMandatoryREMINDER_DAYS.Attributes.Add("style", "display:none");

            txtREMINDER_DAYS.Text = "";
            txtREMINDER_DAYS.Enabled = false;

            ddlFREQUENCY_ID.SelectedIndex = -1;
            ddlFREQUENCY_ID.Enabled = false;

            //megatshamsul - 20170314 - SR1363674 - updated frequency monthly/weekly
            ddlBIZ_DAY_ONLY.SelectedIndex = -1;
            ddlBIZ_DAY_ONLY.Enabled = false;

            //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
            //EnableFrequencyNormalFields(false, true);
            EnableFrequencyNormalFields(false, true, false);

            EnableFrequencyAdHocFields(false, false);
            EnableFrequency6XYearlyFields(false, false);

            //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
            EnableFrequencyWeeklyFields(false, false);

            //megatshamsul - 20170314 - SR1363674 - update frequency monthly
            EnableFrequencyMonthlyFields(false, false);

            fnResetFrequencyFields();
            
            ddlSUBMISSION_MODE_ID.SelectedIndex = -1;
            ddlSUBMISSION_MODE_ID.Enabled = false;

            txtEFF_POSITION_DATE.Text = "";
            txtEFF_POSITION_DATE.Enabled = false;

            txtEXP_POSITION_DATE.Text = "";
            txtEXP_POSITION_DATE.Enabled = false;

            txtREPORT_CONSOLIDATER.Text = "";
            txtREPORT_CONSOLIDATER.Enabled = false;

            txtREPORT_CONTRIBUTOR1.Text = "";
            txtREPORT_CONTRIBUTOR1.Enabled = false;

            txtREPORT_CONTRIBUTOR2.Text = "";
            txtREPORT_CONTRIBUTOR2.Enabled = false;

            txtREPORT_CONTRIBUTOR3.Text = "";
            txtREPORT_CONTRIBUTOR3.Enabled = false;

            txtREPORT_CONTRIBUTOR4.Text = "";
            txtREPORT_CONTRIBUTOR4.Enabled = false;

            txtREMARKS.Text = "";
            txtREMARKS.Enabled = false;

            ddlSTATUS_ID.SelectedIndex = -1;
            ddlSTATUS_ID.Enabled = false;

            txtCREATE_DATE.Text = "";
            txtCREATE_DATE.Enabled = false;

            txtPREPARER_ID.Text = "";
            txtPREPARER_ID.Enabled = false;

            txtPREPARER_DATE.Text = "";
            txtPREPARER_DATE.Enabled = false;

            txtAPPROVER_ID.Text = "";
            txtAPPROVER_ID.Enabled = false;

            txtAPPROVER_DATE.Text = "";
            txtAPPROVER_DATE.Enabled = false;

            txtAPPROVER_FGT_ID.Text = "";
            txtAPPROVER_FGT_ID.Enabled = false;

            txtAPPROVER_FGT_DATE.Text = "";
            txtAPPROVER_FGT_DATE.Enabled = false;

            txtREJECT_REASON.Text = "";
            txtREJECT_REASON.Enabled = false;

            switch (Session["strRoleId"].ToString())
            {
                case "Approver":
                case "FGTAppvr":
                case "Viewer":
                case "Admin":
                    btnNew.Enabled = false;
                    btnNew.Visible = false;
                    break;
                case "Preparer":
                    btnNew.Enabled = true;
                    btnNew.Visible = true;
                    break;
            }

            btnAddETemplate.Enabled = false;
            btnAddETemplate.Visible = false;
            lblAddButtonSpace.Visible = false;
            btnAddSubmitETemplate.Enabled = false;
            btnAddSubmitETemplate.Visible = false;
            lblAddSubmitButtonSpace.Visible = false;

            btnUpdateETemplate.Enabled = false;
            btnUpdateETemplate.Visible = false;
            lblUpdateButtonSpace.Visible = false;
            btnUpdateSubmitETemplate.Enabled = false;
            btnUpdateSubmitETemplate.Visible = false;
            lblUpdateSubmitButtonSpace.Visible = false;
            
            btnDeleteETemplate.Enabled = false;
            btnDeleteETemplate.Visible = false;
            lblDeleteButtonSpace.Visible = false;
            btnDeleteSubmitETemplate.Enabled = false;
            btnDeleteSubmitETemplate.Visible = false;
            lblDeleteSubmitButtonSpace.Visible = false;

            btnApproval.Enabled = false;
            btnApproval.Visible = false;
            lblApprovalButtonSpace.Visible = false;
            btnReject.Enabled = false;
            btnReject.Visible = false;
        }

        private void fnResetFrequencyFields()
        {
            TextBox TextBox1 = null;
            TextBox TextBox2 = null;
            string ObjectId = string.Empty;

            //megatshamsul - 20170314 - SR1363674 - updated frequency Weekly/Monthly
            DropDownList DropDownList1 = null;

            #region Frequency Normal Fields

            txtT_PLUS_SUBMISSION_DATE.Text = "";
            
            #endregion

            #region Frequency Adhoc Fields

            for (int y = 1; y <= 12; y++)
            {
                ObjectId = "txtAdHoc_POSITION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtAdHoc_TARGET_SUBMISSION_DATE_" + y;
                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null && TextBox2 != null)
                {
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                }
            }

            #endregion

            #region Frequency 6 Times Yearly Fields

            for (int y = 1; y <= 6; y++)
            {
                ObjectId = "txt6XYearly_POSITION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txt6XYearly_TARGET_SUBMISSION_DATE_" + y;
                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null && TextBox2 != null)
                {
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                }
            }

            #endregion

            //megatshamsul - 20170314 - SR1363674 - updated frequency Weekly
            #region Frequency Weekly 

            for (int y = 1; y <= 4; y++)
            {
                ObjectId = "ddlWeekly_POSITION_DATE_" + y;
                DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                ObjectId = "txtWeekly_TPLUS_SUBMISSION_DAY_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (DropDownList1 != null && TextBox1 != null)
                {
                    DropDownList1.SelectedIndex = -1;
                    TextBox1.Text = "";
                }
            }

            #endregion

            //megatshamsul - 20170314 - SR1363674 - updated frequency Monthly
            #region Frequency Monthly 

            ddlPOSITION_DATE.SelectedIndex = -1;

            #endregion
        }

        private void EnableFieldsForAddEdit(string Update_Type, bool ifEnable)
        {
            txtRPT_ID.Enabled = false;
            txtRPT_NAME.Enabled = ifEnable;

            System.Web.UI.WebControls.ListItem oListItem;

            if (Update_Type == "I")
            {
                oListItem = ddlUNIT_ID.Items.FindByValue(Session["strUnitId"].ToString());
                if (oListItem != null)
                    ddlUNIT_ID.SelectedValue = oListItem.Value;

                fnGetOrganizationDetails(Session["strUnitId"].ToString());
            }

            ddlUNIT_ID.Enabled = false;

            ddlENTITY_ID.Enabled = ifEnable;
            ddlREGULATOR_ID.Enabled = ifEnable;
            txtREGULATOR_DEPT.Enabled = ifEnable;
            ddlSREF.Enabled = ifEnable;
            
            if (ifEnable)
            {
                if (ConfigurationManager.AppSettings["REMINDER_EDITABLE_FLAG"].ToString() == "1")
                {
                    ddlREMINDER_ID.Enabled = true;
                    txtREMINDER_DAYS.Enabled = true;
                    lblMandatoryREMINDER_DAYS.Style.Remove("display");
                    lblMandatoryREMINDER_DAYS.Attributes.Add("style", "display:inline");
                }
                else
                {
                    ddlREMINDER_ID.SelectedValue = "Y";
                    ddlREMINDER_ID.Enabled = false;
                    if (txtREMINDER_DAYS.Text.Length == 0)
                        txtREMINDER_DAYS.Text = ConfigurationManager.AppSettings["REMINDER_DAYS_DEFAULT"].ToString();
                    txtREMINDER_DAYS.Enabled = false;
                }
            }
            else
            {
                ddlREMINDER_ID.Enabled = false;
                txtREMINDER_DAYS.Enabled = false;
                lblMandatoryREMINDER_DAYS.Style.Remove("display");
                lblMandatoryREMINDER_DAYS.Attributes.Add("style", "display:none");
            }

            ddlFREQUENCY_ID.Enabled = ifEnable;
            ddlBIZ_DAY_ONLY.Enabled = ifEnable;

            switch (ddlFREQUENCY_ID.SelectedValue)
            {
                case "9":   //6 times yearly

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(false, false);
                    EnableFrequencyNormalFields(false, false, true);

                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(ifEnable, true);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    break;

                case "10":	//Adhoc

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(false, false);
                    EnableFrequencyNormalFields(false, false, true);

                    EnableFrequencyAdHocFields(ifEnable, true);
                    EnableFrequency6XYearlyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    break;

                case "2": //megatshamsul - 20170314 - SR1363674 - update frequency weekly

                    EnableFrequencyNormalFields(false, false, true);
                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);
                    EnableFrequencyWeeklyFields(ifEnable, true);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    break;

                case "4": //megatshamsul - 20170314 - SR1363674 - update frequency monthly

                    EnableFrequencyNormalFields(ifEnable, true, false);
                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);
                    EnableFrequencyWeeklyFields(false, false);
                    EnableFrequencyMonthlyFields(ifEnable, true);

                    break;

                default:

                    //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
                    //EnableFrequencyNormalFields(ifEnable, true);
                    EnableFrequencyNormalFields(ifEnable, true, false);

                    EnableFrequencyAdHocFields(false, false);
                    EnableFrequency6XYearlyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
                    EnableFrequencyWeeklyFields(false, false);

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    EnableFrequencyMonthlyFields(false, false);

                    break;

            }

            ddlSUBMISSION_MODE_ID.Enabled = ifEnable;
            txtEFF_POSITION_DATE.Enabled = ifEnable;
            txtEXP_POSITION_DATE.Enabled = ifEnable;
            txtREPORT_CONSOLIDATER.Enabled = ifEnable;
            txtREPORT_CONTRIBUTOR1.Enabled = ifEnable;
            txtREPORT_CONTRIBUTOR2.Enabled = ifEnable;
            txtREPORT_CONTRIBUTOR3.Enabled = ifEnable;
            txtREPORT_CONTRIBUTOR4.Enabled = ifEnable;
            txtREMARKS.Enabled = ifEnable;
            
            ddlSTATUS_ID.Enabled = false;

            txtCREATE_DATE.Enabled = false;
            txtPREPARER_ID.Enabled = false;
            txtPREPARER_DATE.Enabled = false;
            txtAPPROVER_ID.Enabled = false;
            txtAPPROVER_DATE.Enabled = false;
            txtAPPROVER_FGT_ID.Enabled = false;
            txtAPPROVER_FGT_DATE.Enabled = false;
            txtREJECT_REASON.Enabled = false;

            switch (Update_Type)
            {
                case "I":

                    btnAddETemplate.Enabled = true;
                    btnAddETemplate.Visible = true;
                    lblAddButtonSpace.Visible = true;
                    btnAddSubmitETemplate.Enabled = true;
                    btnAddSubmitETemplate.Visible = true;
                    lblAddSubmitButtonSpace.Visible = true;

                    btnUpdateETemplate.Enabled = false;
                    btnUpdateETemplate.Visible = false;
                    lblUpdateButtonSpace.Visible = false;
                    btnUpdateSubmitETemplate.Enabled = false;
                    btnUpdateSubmitETemplate.Visible = false;
                    lblUpdateSubmitButtonSpace.Visible = false;
            
                    btnDeleteETemplate.Enabled = false;
                    btnDeleteETemplate.Visible = false;
                    lblDeleteButtonSpace.Visible = false;
                    btnDeleteSubmitETemplate.Enabled = false;
                    btnDeleteSubmitETemplate.Visible = false;
                    lblDeleteSubmitButtonSpace.Visible = false;

                    break;

                default:

                    btnAddETemplate.Enabled = false;
                    btnAddETemplate.Visible = false;
                    lblAddButtonSpace.Visible = false;
                    btnAddSubmitETemplate.Enabled = false;
                    btnAddSubmitETemplate.Visible = false;
                    lblAddSubmitButtonSpace.Visible = false;

                    btnUpdateETemplate.Enabled = ifEnable;
                    btnUpdateETemplate.Visible = ifEnable;
                    lblUpdateButtonSpace.Visible = ifEnable;
                    btnUpdateSubmitETemplate.Enabled = ifEnable;
                    btnUpdateSubmitETemplate.Visible = ifEnable;
                    lblUpdateSubmitButtonSpace.Visible = ifEnable;

                    btnDeleteETemplate.Enabled = ifEnable;
                    btnDeleteETemplate.Visible = ifEnable;
                    lblDeleteButtonSpace.Visible = ifEnable;
                    btnDeleteSubmitETemplate.Enabled = ifEnable;
                    btnDeleteSubmitETemplate.Visible = ifEnable;
                    lblDeleteSubmitButtonSpace.Visible = ifEnable;

                    break;
            }

            btnApproval.Enabled = false;
            btnApproval.Visible = false;
            lblApprovalButtonSpace.Visible = false;
            btnReject.Enabled = false;
            btnReject.Visible = false;
        }

        private void EnableFrequencyNormalFields(bool ifEnable, bool ifVisibleTR, bool ifVisibleTRHR)
        {
            trFrequencyNormal.Visible = ifVisibleTR;
            
            txtT_PLUS_SUBMISSION_DATE.Enabled = ifEnable;
            
            trFrequencyAdHoc_LineTop.Visible = ifVisibleTRHR;
            trFrequencyAdHoc_LineBottom.Visible = ifVisibleTRHR;
        }

        private void EnableFrequencyAdHocFields(bool ifEnable, bool ifVisibleTR)
        {
            TextBox TextBox1 = null;
            TextBox TextBox2 = null;
            string ObjectId = string.Empty;

            trFrequencyAdHoc.Visible = ifVisibleTR;

            for (int y = 1; y <= 12; y++)
            {
                ObjectId = "txtAdHoc_POSITION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txtAdHoc_TARGET_SUBMISSION_DATE_" + y;
                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null && TextBox2 != null)
                {
                    TextBox1.Enabled = ifEnable;
                    TextBox2.Enabled = ifEnable;
                }
            }
        }

        private void EnableFrequency6XYearlyFields(bool ifEnable, bool ifVisibleTR)
        {
            TextBox TextBox1 = null;
            TextBox TextBox2 = null;
            string ObjectId = string.Empty;

            trFrequency6XYearly.Visible = ifVisibleTR;

            for (int y = 1; y <= 6; y++)
            {
                ObjectId = "txt6XYearly_POSITION_DATE_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                ObjectId = "txt6XYearly_TARGET_SUBMISSION_DATE_" + y;
                TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (TextBox1 != null && TextBox2 != null)
                {
                    TextBox1.Enabled = ifEnable;
                    TextBox2.Enabled = ifEnable;
                }
            }
        }

        //megatshamsul - 20170314 - SR1363674 - updated frequency weekly
        private void EnableFrequencyWeeklyFields(bool ifEnable, bool ifVisibleTR)
        {
            DropDownList DropDownList1 = null;
            TextBox TextBox1 = null;
            string ObjectId = string.Empty;

            trFrequencyWeekly.Visible = ifVisibleTR;

            for (int y = 1; y <= 4; y++)
            {
                ObjectId = "ddlWeekly_POSITION_DATE_" + y;
                DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                ObjectId = "txtWeekly_TPLUS_SUBMISSION_DAY_" + y;
                TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                if (DropDownList1 != null && TextBox1 != null)
                {
                    DropDownList1.Enabled = ifEnable;
                    TextBox1.Enabled = ifEnable;
                }
            }
        }

        //megatshamsul - 20170314 - SR1363674 - updated frequency monthly
        private void EnableFrequencyMonthlyFields(bool ifEnable, bool ifVisibleTR)
        {
            TrPositionDate.Visible = ifVisibleTR;
            ddlPOSITION_DATE.Enabled = ifEnable;
        }

        private bool ValidateFieldsAddEdit(string Update_Type)
        {
            if (Update_Type != "I")
            {
                if (string.IsNullOrEmpty(txtRPT_ID.Text))
                {
                    ShowMessage("Missing RPT_ID", txtRPT_ID.ClientID.ToString());
                    return false;
                }
            }

            if (string.IsNullOrEmpty(txtRPT_NAME.Text))
            {
                ShowMessage("This is mandatory field, input is required - RPT NAME", txtRPT_NAME.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlUNIT_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - UNIT", ddlUNIT_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlENTITY_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - ENTITY", ddlENTITY_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlREGULATOR_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - REGULATOR", ddlREGULATOR_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlSREF.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - SREF", ddlSREF.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlREMINDER_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - SEND REMINDER?", ddlREMINDER_ID.ClientID.ToString());
                return false;
            }
            else
            {
                if (ddlREMINDER_ID.SelectedValue=="Y" && string.IsNullOrEmpty(txtREMINDER_DAYS.Text))
                {
                    ShowMessage("This is mandatory field, input is required - REMINDER IN DAYS", txtREMINDER_DAYS.ClientID.ToString());
                    return false;
                }
            }

            //megatshamsul - 20170314 - SR1363674 - update frequency weekly/monthly
            if (string.IsNullOrEmpty(ddlBIZ_DAY_ONLY.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - Calendar Day Or Working Day?", ddlBIZ_DAY_ONLY.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlFREQUENCY_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - SUBMISSION FREQUENCY", ddlFREQUENCY_ID.ClientID.ToString());
                return false;
            }
            else
            {
                TextBox TextBox1;
                TextBox TextBox2;
                string ObjectId = string.Empty;
                bool ifOK = false;

                //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                DropDownList DropDownList1;

                switch (ddlFREQUENCY_ID.SelectedValue)
                {
                    case "1":	//Daily

                    //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                    //case "2":	//Weekly

                    case "3":	//Bi_Monthly

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    //case "4":	//Monthly

                    case "5":	//Quarterly
                    case "6":	//Half Yearly_Calendar Year End
                    case "7":	//Yearly_Calendar Year End
                    case "8":	//Yearly_Financial Year End
                    case "11":  //megatshamsul - 20170314 - SR1363674 - new frequency Half Yearly_Financial Year End
                        
                        if (string.IsNullOrEmpty(txtT_PLUS_SUBMISSION_DATE.Text))
                        {
                            ShowMessage("This is mandatory field, input is required - TPLUS SUBMISSION IN DAYS", txtT_PLUS_SUBMISSION_DATE.ClientID.ToString());
                            return false;
                        }
                        
                        break;

                    case "9":   //6 times yearly

                        for (int y = 1; y <= 6; y++)
                        {
                            ObjectId = "txt6XYearly_POSITION_DATE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            ObjectId = "txt6XYearly_TARGET_SUBMISSION_DATE_" + y;
                            TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (TextBox1 != null && TextBox2 != null)
                            {
                                if (!string.IsNullOrEmpty(TextBox1.Text) && !string.IsNullOrEmpty(TextBox2.Text))
                                {
                                    if (!BusinessLogicClass.fnValidateDatesRange(TextBox1.Text, TextBox2.Text))
                                    {
                                        ShowMessage("Please enter DATES in correct range", TextBox1.ClientID.ToString());
                                        return false;
                                    }
                                    else
                                        ifOK = true;
                                }
                                else if (string.IsNullOrEmpty(TextBox1.Text) && !string.IsNullOrEmpty(TextBox2.Text))
                                {
                                    ShowMessage("This is mandatory field, input is required - POSITION DATE", TextBox1.ClientID.ToString());
                                    return false;
                                }
                                else if (!string.IsNullOrEmpty(TextBox1.Text) && string.IsNullOrEmpty(TextBox2.Text))
                                {
                                    ShowMessage("This is mandatory field, input is required - TARGET SUBMISSION DATE", TextBox2.ClientID.ToString());
                                    return false;
                                }
                            }
                        }

                        if (!ifOK)
                        {
                            ShowMessage("Please enter POSITION_DATE in correct format", txt6XYearly_POSITION_DATE_1.ClientID.ToString());
                            return false;
                        }

                        break;

                    case "10":	//Adhoc
                        
                        for (int y = 1; y <= 12; y++)
                        {
                            ObjectId = "txtAdHoc_POSITION_DATE_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            ObjectId = "txtAdHoc_TARGET_SUBMISSION_DATE_" + y;
                            TextBox2 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (!ifOK)
                            {
                                if (TextBox1 != null && TextBox2 != null)
                                {
                                    if (BusinessLogicClass.fnValidateDatesRange(TextBox1.Text, TextBox2.Text))
                                        ifOK = true;
                                }
                            }
                        }

                        if (!ifOK)
                        {
                            ShowMessage("Please enter POSITION DATE in correct format", txtAdHoc_POSITION_DATE_1.ClientID.ToString());
                            return false;
                        }
                        
                        break;

                    //megatshamsul - 20170314 - SR1363674 - update frequency weekly
                    case "2":	//Weekly

                        int totalRows = 0;
                        int weekly_PosDate = -1;
                        var numericPart = "0";

                        for (int y = 1; y <= 4; y++)
                        {
                            ObjectId = "ddlWeekly_POSITION_DATE_" + y;
                            DropDownList1 = FindControlRecursive(Page, ObjectId) as DropDownList;

                            ObjectId = "txtWeekly_TPLUS_SUBMISSION_DAY_" + y;
                            TextBox1 = FindControlRecursive(Page, ObjectId) as TextBox;

                            if (DropDownList1 != null && TextBox1 != null)
                            {
                                if (string.IsNullOrEmpty(DropDownList1.SelectedValue) && string.IsNullOrEmpty(TextBox1.Text))
                                {
                                    ShowMessage("This is mandatory field, input is required - POSITION DATE", DropDownList1.ClientID.ToString());
                                    return false;
                                }
                                else if (string.IsNullOrEmpty(DropDownList1.SelectedValue) && !string.IsNullOrEmpty(TextBox1.Text))
                                {
                                    ShowMessage("This is mandatory field, input is required - POSITION DATE", DropDownList1.ClientID.ToString());
                                    return false;
                                }
                                else if (!string.IsNullOrEmpty(DropDownList1.SelectedValue) && string.IsNullOrEmpty(TextBox1.Text))
                                {
                                    ShowMessage("This is mandatory field, input is required - TPLUS SUBMISSION DAY", TextBox1.ClientID.ToString());
                                    return false;
                                }
                                else
                                {
                                    if (weekly_PosDate == -1)
                                    {
                                        if (DropDownList1.SelectedValue == "EOM")
                                            weekly_PosDate = 32;
                                        else
                                        {
                                            numericPart = Regex.Match(DropDownList1.SelectedValue, "\\d+").Value;
                                            weekly_PosDate = Convert.ToInt32(numericPart);
                                        }
                                    }
                                    else
                                    {
                                        if (DropDownList1.SelectedValue == "EOM")
                                        {
                                            if (weekly_PosDate >= 32)
                                            {
                                                ShowMessage("Please enter current week POSITION DATE greater than previous week POSITION DATE", DropDownList1.ClientID.ToString());
                                                return false;
                                            }
                                            else
                                                weekly_PosDate = 32;
                                        }
                                        else
                                        {
                                            numericPart = Regex.Match(DropDownList1.SelectedValue, "\\d+").Value;
                                            int Iweekly_PosDate = Convert.ToInt32(numericPart);

                                            if (weekly_PosDate >= Iweekly_PosDate)
                                            {
                                                ShowMessage("Please enter current week POSITION DATE greater than previous week POSITION DATE", DropDownList1.ClientID.ToString());
                                                return false;
                                            }
                                            else
                                                weekly_PosDate = Iweekly_PosDate;
                                        }
                                    }

                                    totalRows = totalRows + 1;
                                }
                            }
                        }

                        if (totalRows != 4)
                        {
                            ShowMessage("Please enter all WEEKLY details", ddlWeekly_POSITION_DATE_1.ClientID.ToString());
                            return false;
                        }

                        break;

                    //megatshamsul - 20170314 - SR1363674 - update frequency monthly
                    case "4":	//Monthly

                        if (string.IsNullOrEmpty(ddlPOSITION_DATE.SelectedValue))
                        {
                            ShowMessage("This is mandatory field, input is required - POSITION DATE", ddlPOSITION_DATE.ClientID.ToString());
                            return false;
                        }

                        if (string.IsNullOrEmpty(txtT_PLUS_SUBMISSION_DATE.Text))
                        {
                            ShowMessage("This is mandatory field, input is required - TPLUS SUBMISSION IN DAYS", txtT_PLUS_SUBMISSION_DATE.ClientID.ToString());
                            return false;
                        }

                        break;

                }
            }

            if (string.IsNullOrEmpty(ddlSUBMISSION_MODE_ID.SelectedValue))
            {
                ShowMessage("This is mandatory field, input is required - SUBMISSION MODE", ddlSUBMISSION_MODE_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtEFF_POSITION_DATE.Text))
            {
                ShowMessage("This is mandatory field, input is required - EFFECTIVE START POSITION DATE", txtEFF_POSITION_DATE.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(txtEXP_POSITION_DATE.Text))
            {
                ShowMessage("This is mandatory field, input is required - EFFECTIVE END POSITION DATE", txtEXP_POSITION_DATE.ClientID.ToString());
                return false;
            }

            if (!BusinessLogicClass.fnValidateDatesRange(txtEFF_POSITION_DATE.Text, txtEXP_POSITION_DATE.Text))
            {
                ShowMessage("Please enter DATES in correct range", txtEFF_POSITION_DATE.ClientID.ToString());
                return false;
            }

            if (Update_Type != "I")
            {
                if (string.IsNullOrEmpty(ddlSTATUS_ID.SelectedValue))
                {
                    ShowMessage("Missing STATUS ID", ddlSTATUS_ID.ClientID.ToString());
                    return false;
                }
            }

            return true;
        }

        private Control FindControlRecursive(Control root, string id)
        {
            if (root.ID == id) return root;
            foreach (Control c in root.Controls)
            {
                Control t = FindControlRecursive(c, id);
                if (t != null) return t;
            }
            return null;
        }

        #endregion

        #region Approval

        protected void btnApproval_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsApproval("A"))
            {
                bool ifSuccess = false;
                ShowMessage(BusinessLogicClass.fnApproveETemplate("A", txtRPT_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);

                string sRptName = txtRPT_NAME.Text;
                string sStatusId = ddlSTATUS_ID.SelectedValue;
                string sRptId = txtRPT_ID.Text;
                string sEFF_POSITION_DATE = txtEFF_POSITION_DATE.Text;
                string sEXP_POSITION_DATE = txtEXP_POSITION_DATE.Text;

                string sUnitId = string.Empty;

                if (Session["strRoleId"].ToString() == "Approver")
                    sUnitId = Session["strUnitId"].ToString();
                else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    sUnitId = ddlUNIT_ID.SelectedValue.ToString();

                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    if (Session["strRoleId"].ToString() == "FGTAppvr" && sStatusId == "AP1")
                        BusinessLogicClass.fnRegenESubmissions("1", txtHdnROW_NUM.Text, sRptId, Session["strUserId"].ToString(), sEFF_POSITION_DATE, sEXP_POSITION_DATE);    //to set status as removed for completed e-submission + regen
                    else if (Session["strRoleId"].ToString() == "FGTAppvr" && sStatusId == "APX1")
                        BusinessLogicClass.fnRegenESubmissions("0", txtHdnROW_NUM.Text, sRptId, Session["strUserId"].ToString(), sEFF_POSITION_DATE, sEXP_POSITION_DATE);    //to set status as removed for completed e-submission only

                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = string.Empty;
                    string sEmailBody = string.Empty;

                    if (Session["strRoleId"].ToString() == "Approver")
                    {
                        sEmailSubject = "E-Template Has Been Submitted For FG’s Approval";
                        sEmailBody = "E-Template Report Name " + sRptName + " has been approved by Approver " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and is now in Finance Governance’s queue. Please act accordingly.";
                    }
                    else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    {
                        sEmailSubject = "E-Template Has Been Successfully Approved by FG";
                        sEmailBody = "E-Template Report Name " + sRptName + " has been approved by Finance Governance " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + ") and will be consolidated into Master Inventory Listing.";
                    }

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerETemplate.ActiveTab = TabPanelListing;
            }
        }

        protected void btnReject_OnClick(object sender, EventArgs e)
        {
            if (ValidateFieldsApproval("R"))
            {
                bool ifSuccess = false;
                ShowMessage(BusinessLogicClass.fnApproveETemplate("R", txtRPT_ID.Text, ddlSTATUS_ID.SelectedValue, txtHdnROW_NUM.Text, txtREJECT_REASON.Text, Session["strUserId"].ToString(), Session["strRoleId"].ToString(), ref ifSuccess), string.Empty);
                
                string sRptName = txtRPT_NAME.Text;
                string sUnitId = string.Empty;

                if (Session["strRoleId"].ToString() == "Approver")
                    sUnitId = Session["strUnitId"].ToString();
                else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    sUnitId = ddlUNIT_ID.SelectedValue.ToString();

                fnResetEditForm();
                fnBindListing(false);

                if (ifSuccess)
                {
                    DataTable dtEmailTo = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Approver", Session["strUserId"].ToString());
                    DataTable dtEmailCC = BusinessLogicClass.fnGetEmailRecipients(sUnitId, "Preparer", Session["strUserId"].ToString());
                    string sEmailSubject = string.Empty;
                    string sEmailBody = string.Empty;

                    if (Session["strRoleId"].ToString() == "Approver")
                    {
                        sEmailSubject = "E-Template Has Been Rejected by Approver and Now Available at Preparer’s REJECT BUCKET";
                        sEmailBody = "E-Template Report Name " + sRptName + " has been rejected by Approver " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + "). Please act accordingly.";
                    }
                    else if (Session["strRoleId"].ToString() == "FGTAppvr")
                    {
                        sEmailSubject = "E-Template Has Been Rejected by FG and Now Available at Preparer’s REJECT BUCKET";
                        sEmailBody = "E-Template Report Name " + sRptName + " has been rejected by Finance Governance " + Session["strUserName"].ToString() + " (" + Session["strUserId"].ToString() + "). Please act accordingly.";
                    }

                    BusinessLogicClass.fnSendEmail(dtEmailTo, dtEmailCC, sEmailSubject, sEmailBody, Session["strUserId"].ToString());
                }

                TabContainerETemplate.ActiveTab = TabPanelListing;
            }
        }

        private bool ValidateFieldsApproval(string Action_Type)
        {
            if (string.IsNullOrEmpty(txtRPT_ID.Text))
            {
                ShowMessage("Missing RPT ID", txtRPT_ID.ClientID.ToString());
                return false;
            }

            if (string.IsNullOrEmpty(ddlSTATUS_ID.SelectedValue))
            {
                ShowMessage("Missing STATUS ID", ddlSTATUS_ID.ClientID.ToString());
                return false;
            }

            if (Action_Type == "R" && string.IsNullOrEmpty(txtREJECT_REASON.Text))
            {
                ShowMessage("This is mandatory field, input is required - REJECT REASON", txtREJECT_REASON.ClientID.ToString());
                return false;
            }

            return true;
        }

        #endregion

        #region Print & Export

        protected void btnPrint_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    string strPrintRptId = "";
                    string strPrintRptName = "";
                    string strPrintRegulatorId = "";
                    string strPrintSREF = "";
                    string strPrintFrequencyId = "";
                    string strPrintStatusId = "";
                    string strPrintCreateDate = "";

                    using (StringWriter sw = new StringWriter())
                    {
                        using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                        {
                            //To Export all pages
                            grdvwListing.AllowPaging = false;
                            grdvwListing.AutoGenerateSelectButton = false;

                            // get data from gridview
                            this.fnBindListing(true);

                            if (txtFilterRPT_ID.Text.Length > 0)
                                strPrintRptId = txtFilterRPT_ID.Text;
                            else
                                strPrintRptId = "All Report Ids";

                            if (txtFilterRPT_NAME.Text.Length > 0)
                                strPrintRptName = txtFilterRPT_NAME.Text;
                            else
                                strPrintRptName = "All Report Names";

                            if (ddlFilterREGULATOR_ID.SelectedValue.Length > 0)
                                strPrintRegulatorId = ddlFilterREGULATOR_ID.SelectedItem.Text;
                            else
                                strPrintRegulatorId = "All Regulators";

                            if (ddlFilterSREF.SelectedValue.Length > 0)
                                strPrintSREF = ddlFilterSREF.SelectedItem.Text;
                            else
                                strPrintSREF = "All SREF";

                            if (ddlFilterFREQUENCY_ID.SelectedValue.Length > 0)
                                strPrintFrequencyId = ddlFilterFREQUENCY_ID.SelectedItem.Text;
                            else
                                strPrintFrequencyId = "All Frequencies";

                            if (!chkbxFilterStatusAll.Checked)
                            {
                                strPrintStatusId = string.Empty;

                                if (chkbxFilterStatusDraft.Checked)
                                    strPrintStatusId = "Draft";

                                if (chkbxFilterStatusNew.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/New/Update/Request For Discontinue";
                                    else
                                        strPrintStatusId = "New/Update/Request For Discontinue";
                                }

                                if (chkbxFilterStatusApproved.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Approved";
                                    else
                                        strPrintStatusId = "Approved";
                                }

                                if (chkbxFilterStatusRejected.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Rejected";
                                    else
                                        strPrintStatusId = "Rejected";
                                }

                                if (chkbxFilterStatusPendingApproval.Checked)
                                {
                                    if (strPrintStatusId.Length > 0)
                                        strPrintStatusId = strPrintStatusId + "/Pending Approval";
                                    else
                                        strPrintStatusId = "Pending Approval";
                                }
                            }
                            else
                                strPrintStatusId = "All Status";

                            if (txtFilterDateFrom.Text.Length > 0 && txtFilterDateTo.Text.Length > 0)
                                strPrintCreateDate = "Between " + txtFilterDateFrom.Text + " And " + txtFilterDateTo.Text;
                            else
                                strPrintCreateDate = "All Dates";

                            // gridview css
                            grdvwListing.HeaderRow.Style.Add("background-color", "Gray");
                            grdvwListing.HeaderRow.Style.Add("font-family", "Arial");
                            grdvwListing.HeaderRow.Style.Add("font-weight", "bold");
                            //grdvwListing.HeaderRow.Style.Add("font-size", "7px");
                            grdvwListing.HeaderRow.Style.Add("color", "White");
                            grdvwListing.HeaderRow.Style.Add("text-align", "center");
                            grdvwListing.Attributes.CssStyle.Add("font-size", "7px");
                            grdvwListing.RenderControl(hw);

                            StringReader sr = new StringReader(sw.ToString());
                            Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                            PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
                            pdfDoc.Open();

                            // create table to pdf
                            PdfPTable table = new PdfPTable(3);
                            table.TotalWidth = 1000f;
                            table.LockedWidth = true;
                            table.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cell = new PdfPCell(new Phrase("LIST OF E-TEMPLATES", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.UNDERLINE, iTextSharp.text.Color.BLACK)));
                            cell.Border = 0;
                            cell.Colspan = 3;
                            cell.HorizontalAlignment = 0;
                            table.AddCell(cell);

                            PdfPCell cell2 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell2.Border = 0;
                            cell2.Colspan = 3;
                            cell2.HorizontalAlignment = 0;
                            table.AddCell(cell2);

                            PdfPCell cell5 = new PdfPCell(new Phrase("RPT_ID : " + strPrintRptId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell5.Border = 0;
                            cell5.Colspan = 3;
                            cell5.HorizontalAlignment = 0;
                            table.AddCell(cell5);

                            PdfPCell cell6 = new PdfPCell(new Phrase("RPT_NAME : " + strPrintRptName, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell6.Border = 0;
                            cell6.Colspan = 3;
                            cell6.HorizontalAlignment = 0;
                            table.AddCell(cell6);

                            PdfPCell cell7 = new PdfPCell(new Phrase("REGULATOR_ID : " + strPrintRegulatorId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell7.Border = 0;
                            cell7.Colspan = 3;
                            cell7.HorizontalAlignment = 0;
                            table.AddCell(cell7);

                            PdfPCell cell8 = new PdfPCell(new Phrase("SREF : " + strPrintSREF, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell8.Border = 0;
                            cell8.Colspan = 3;
                            cell8.HorizontalAlignment = 0;
                            table.AddCell(cell8);

                            PdfPCell cell9 = new PdfPCell(new Phrase("FREQUENCY_ID : " + strPrintFrequencyId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell9.Border = 0;
                            cell9.Colspan = 3;
                            cell9.HorizontalAlignment = 0;
                            table.AddCell(cell9);

                            PdfPCell cell10 = new PdfPCell(new Phrase("STATUS_ID : " + strPrintStatusId, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell10.Border = 0;
                            cell10.Colspan = 3;
                            cell10.HorizontalAlignment = 0;
                            table.AddCell(cell10);

                            PdfPCell cell11 = new PdfPCell(new Phrase("DATE : " + strPrintCreateDate, new iTextSharp.text.Font
                                    (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.BLACK)));
                            cell11.Border = 0;
                            cell11.Colspan = 3;
                            cell11.HorizontalAlignment = 0;
                            table.AddCell(cell11);

                            PdfPCell cell3 = new PdfPCell(new Phrase("SPACE", new iTextSharp.text.Font
                                (iTextSharp.text.Font.HELVETICA, 10f, iTextSharp.text.Font.NORMAL, iTextSharp.text.Color.WHITE)));
                            cell3.Border = 0;
                            cell3.Colspan = 3;
                            cell3.HorizontalAlignment = 0;
                            table.AddCell(cell3);
                            pdfDoc.Add(table);

                            htmlparser.Parse(sr);
                            pdfDoc.Close();

                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "attachment;filename=ListOfETemplates.pdf");
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.Write(pdfDoc);
                            Response.End();
                        }
                    }
                }
                else
                {
                    ShowMessage("There is no data to print", string.Empty);
                }
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "ETemplate.btnPrint_OnClick.ThreadAbortException", ex3.Message, Session["strUserId"].ToString());
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to print the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "ETemplate.btnPrint_OnClick.Exception", ex2.Message, Session["strUserId"].ToString());
            }
        }

        protected void btnExport_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (grdvwListing.Rows.Count > 0)
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=ListOfETemplates.CSV");
                    Response.Charset = "";
                    Response.ContentType = "application/text";
                    Response.ContentEncoding = Encoding.UTF8;

                    //To Export all pages
                    grdvwListing.AllowPaging = false;
                    grdvwListing.AutoGenerateSelectButton = false;

                    // get data from gridview
                    this.fnBindListing(true);

                    StringBuilder sb = new StringBuilder();

                    for (int k = 0; k < grdvwListing.HeaderRow.Cells.Count; k++)
                    {
                        //add separator
                        sb.Append('"' + grdvwListing.HeaderRow.Cells[k].Text + '"' + ',');
                    }

                    //append new line
                    sb.Append("\r\n");

                    string val = string.Empty;

                    for (int i = 0; i < grdvwListing.Rows.Count; i++)
                    {
                        for (int k = 0; k < grdvwListing.Rows[i].Cells.Count; k++)  //skip "select"/row_id
                        {
                            val = HttpUtility.HtmlDecode(grdvwListing.Rows[i].Cells[k].Text);
                            val = BusinessLogicClass.fnRemoveIllegalCharFromGrid(val);

                            if (val == "&nbsp;")
                                val = "";

                            if (val.Contains("&#"))
                                val = BusinessLogicClass.fnRemoveIllegalNonHTMLCharFromGrid(val);

                            //to avoid Â
                            if (val.Trim() == "")
                                sb.Append(',');
                            else
                            {
                                val = "\t" + val;   //to maintain leading zeros
                                sb.Append('"' + val + '"' + ',');
                            }
                        }

                        //append new line
                        sb.Append("\r\n");
                    }

                    Response.Output.Write(sb.ToString());
                    
                    //Response.Flush();
                    //Response.End();

                    HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                    HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                    HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                }
                else
                {
                    ShowMessage("There is no data to export", string.Empty);
                }
            }
            catch (System.OutOfMemoryException ex4)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex4.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Threading.ThreadAbortException ex3)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex3.Message, Session["strUserId"].ToString());    //12 as default err code
            }
            catch (System.Exception ex2)
            {
                ShowMessage("Fail to export the listing!", string.Empty);
                BusinessLogicClass.fnLogErrorInFile(12, "btnExport_OnClick", ex2.Message, Session["strUserId"].ToString());    //12 as default err code
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }

        #endregion
    }
}